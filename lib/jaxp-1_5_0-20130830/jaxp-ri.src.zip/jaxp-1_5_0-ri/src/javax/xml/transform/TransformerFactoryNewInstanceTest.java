/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * TransformerFactoryNewInstanceTest.java
 *
 * This class tests new overloaded newInstance() added in all factories.
 * New function allows application to specify factoryClassName and ClassLoader.
 * This gives more control to the application.
 *
 * JUnit based test
 *
 *
 */

package javax.xml.transform;

import junit.framework.*;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import junit.textui.TestRunner;

/**
 *
 * @author Neeraj Bajaj
 */
public class TransformerFactoryNewInstanceTest extends TestCase {

    public TransformerFactoryNewInstanceTest(String testName) {
        super(testName);
    }


    public static void main(String[] args) {
        TestRunner.run(TransformerFactoryNewInstanceTest.class);
    }

    protected void setUp() throws java.lang.Exception {
    }

    protected void tearDown() throws java.lang.Exception {
    }

    // TODO add test methods here. The name must begin with 'test'. For example:
    // public void testHello() {}

    public void test1(){
        try{
            //pass 'null' factoryClassName as parameter
            TransformerFactory sf = TransformerFactory.newInstance(null, null);
        }catch(TransformerFactoryConfigurationError fce){
            //as expected
            return ;
        }catch(Exception e){
            e.printStackTrace();
            fail("should fail with TransformerConfigurationException");
            return ;
        }
        fail("Shouldn't reach here, test should fail with TransformerConfigurationException");
    }

    public void test2(){
        try{
            //pass arbitrary factoryClassName as parameter
            TransformerFactory sf = TransformerFactory.newInstance("foo", null);
        }catch(TransformerFactoryConfigurationError fce){
            //as expected
            return;
        }catch(Exception e){
            e.printStackTrace();
            fail("should fail with TransformerConfigurationException");
            return;
        }

        fail("Shouldn't reach here, test should fail with TransformerConfigurationException");
    }

    public void test3(){
        try{
            TransformerFactory sf = TransformerFactory.newInstance();
            //get the class name from the old newInstance() function
            //this way it will work if the sources are renamed.
            String className = sf.getClass().getName();
            System.out.println("factory class name is = " + className);
            //now try to load the factory using new newInstance() signature className
            TransformerFactory s = TransformerFactory.newInstance(className, null);
            System.out.println("s = " + s);
            if(s != null){
                return ;
            }
        }catch(TransformerFactoryConfigurationError fce){
            fce.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
        fail("test routine shouldn't reach here");
    }

}
