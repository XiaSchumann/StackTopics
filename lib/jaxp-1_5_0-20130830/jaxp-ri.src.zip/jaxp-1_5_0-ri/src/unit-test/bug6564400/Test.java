/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * Test.java
 *
 * Created on June 8, 2007, 3:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6564400;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import junit.framework.*;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Unit test for CR 6564400. Check to see if whitespace can be ignored with schema validation.
 *
 * @author Norman.Walsh@Sun.COM
 */
public class Test extends TestCase {
    private boolean sawIgnorable = false;
    Schema schema = null;

    public Test(String name) {
        super(name);

        String xsdFile = "test.xsd";
        File schemaFile = new File(xsdFile);

        // Now attempt to load up the schema
        try {
            SchemaFactory schFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schema = schFactory.newSchema(new StreamSource(getClass().getResourceAsStream(xsdFile)));
        } catch (Exception e) {
            // Nevermind, bad things will happen later
        }
    }

    public static void main(String[] args) {
        TestRunner.run(Test.class);
    }

    public void testDOM() throws ParserConfigurationException, SAXException, IOException {
        InputStream xmlFile = getClass().getResourceAsStream("test.xml");

        // Set the options on the DocumentFactory to remove comments, remove whitespace
        // and validate against the schema.
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        docFactory.setIgnoringComments(true);
        docFactory.setIgnoringElementContentWhitespace(true);
        docFactory.setSchema(schema);

        DocumentBuilder parser = docFactory.newDocumentBuilder();
        Document xmlDoc = parser.parse(xmlFile);

        boolean ok = dump(xmlDoc, true);
        assertEquals(true, ok);
    }

    public void testSAX() throws ParserConfigurationException, SAXException, IOException {
        InputStream xmlFile = getClass().getResourceAsStream("test.xml");

        // Parse with SAX
        SAXParserFactory saxFactory = SAXParserFactory.newInstance();
        saxFactory.setSchema(schema);

        SAXParser saxparser = saxFactory.newSAXParser();

        sawIgnorable = false;
        saxparser.parse(xmlFile, new MyHandler());
        assertEquals(true, sawIgnorable);
    }

    public void testConformantDOM() throws ParserConfigurationException, SAXException, IOException {
        InputStream xmlFile = getClass().getResourceAsStream("test.xml");

        // Set the options on the DocumentFactory to remove comments, remove whitespace
        // and validate against the schema.
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        docFactory.setIgnoringComments(true);
        docFactory.setIgnoringElementContentWhitespace(true);
        docFactory.setSchema(schema);
        docFactory.setFeature("http://java.sun.com/xml/schema/features/report-ignored-element-content-whitespace", true);

        DocumentBuilder parser = docFactory.newDocumentBuilder();
        Document xmlDoc = parser.parse(xmlFile);

        boolean ok = dump(xmlDoc, true);
        assertEquals(false, ok);
    }

    public void testConformantSAX() throws ParserConfigurationException, SAXException, IOException {
        InputStream xmlFile = getClass().getResourceAsStream("test.xml");

        // Parse with SAX
        SAXParserFactory saxFactory = SAXParserFactory.newInstance();
        saxFactory.setSchema(schema);
        saxFactory.setFeature("http://java.sun.com/xml/schema/features/report-ignored-element-content-whitespace", true);

        SAXParser saxparser = saxFactory.newSAXParser();

        sawIgnorable = false;
        saxparser.parse(xmlFile, new MyHandler());
        assertEquals(false, sawIgnorable);
    }

    private boolean dump(Node node) {
        return dump(node, false);
    }

    private boolean dump(Node node, boolean silent) {
        return dump(node, silent, 0);
    }

    private boolean dump(Node node, boolean silent, int depth) {
        boolean ok = true;
        if (!silent) {
            for (int i = 0; i < depth; i++) {
                System.out.print("  ");
            }
            System.out.println(node);
        }

        if (node.getNodeType() == Node.TEXT_NODE) {
            String text = ((Text) node).getData();
            ok = ok && text.trim().length() > 0;
        }

        if (node.getNodeType() == Node.ELEMENT_NODE || node.getNodeType() == Node.DOCUMENT_NODE) {
            Node child = node.getFirstChild();
            while (child != null) {
                ok = ok && dump(child, silent, depth+1);
                child = child.getNextSibling();
            }
        }
        return ok;
    }

    public class MyHandler extends DefaultHandler {
        public void ignorableWhitespace(char[] ch, int start, int length) {
            sawIgnorable = true;
        }
    }
}
