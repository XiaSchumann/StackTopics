/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


package bug6505031;

import common.SimplePolicy;
import java.io.FilePermission;
import java.io.StringWriter;
import java.security.Policy;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Unit test for CR 6505031. This is a multi-document test in which
 * keys and their values come from different DTMs.
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    private boolean hasSM;
    private Policy _orig;
    private String _tmpdir;
    private String _filePath;

    private String getResource(String s) {
        return getClass().getResource(s).toString();
    }
    
    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }
        _orig = Policy.getPolicy();
        
        String path = this.getClass().getResource("config.xml").getPath();
        _filePath = path.substring(0, path.lastIndexOf("/"));
        String _tmpdir = System.getProperty("java.io.tmpdir");
        if (hasSM) {
            Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new FilePermission(_tmpdir + "*", "read,write"),
                    new FilePermission(_filePath + "/*", "read,write"));
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void test() {
        Map params = new HashMap();

        params.put("config", getResource("config.xml"));
        params.put("mapsFile", getResource("maps.xml"));
        generate(getResource("template.xml"), getResource("transform.xsl"), params);
    }

    private void generate(String in, String xsl, Map params) {
        try {
            Transformer transformer = getTransformer(xsl);

            for( Iterator i=params.entrySet().iterator() ; i.hasNext() ; ) {
                Map.Entry entry = (Map.Entry)i.next();

                transformer.setParameter((String)entry.getKey(),entry.getValue());
            }
            transform(in, transformer);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    private Transformer getTransformer( String transform ) throws Exception {
        TransformerFactory tfactory = TransformerFactory.newInstance();

        try {
            // set the translet name
            tfactory.setAttribute("translet-name", "myTranslet");

            // set the destination directory
            tfactory.setAttribute("destination-directory", _tmpdir);
            tfactory.setAttribute("generate-translet", Boolean.TRUE);
        } catch (Exception e) {
            // Ignore
        }

        Transformer transformer = tfactory.newTransformer(new StreamSource(transform));
        return (transformer);
    }

    private void transform( String in, Transformer transformer )
        throws Exception
    {
        StringWriter sw = new StringWriter();
        transformer.transform(new StreamSource(in),
                new StreamResult(sw));
        String s = sw.toString();
        assertTrue(s.contains("map1key1value") && s.contains("map2key1value"));
    }

}
