/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * Test.java
 *
 * Created on February 20, 2007, 10:42 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bug6607339;


import com.sun.org.apache.xml.internal.dtm.ref.DTMManagerDefault;
import common.SimplePolicy;
import java.io.File;
import java.io.FilePermission;
import java.security.Policy;

/**
 * Test for CR 6607339. Note that this isn't a unit test, but a
 * standalone test instead. Correct termination is based on the
 * exact number of remaining threads and requires calling System.exit().
 * Thus, it cannot be executed as a unit test
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test {

    public static void main(String[] args) throws Exception {
        Test test = new Test();
        test.setUp();
        test.test();
        test.tearDown();
    }
    private String _filepath;
    private boolean hasSM;
    private String _curdir;
    private Policy _orig;

    public void setUp() {
        String temp = Test.class.getResource("target.xml").getPath();
        _filepath = temp.substring(0, temp.lastIndexOf('/'));
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length() - 1);
        _orig = Policy.getPolicy();

    }

    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void test() throws Exception {
        // The GNOME Accessibility JavaBridge will not initialise
        // from an untrusted context.
        // So we need to load the toolkit before the security manager is set.
        java.awt.Toolkit.getDefaultToolkit();

        // Target XML filewe should not be able to access.
        // Requires full path name.
        java.io.File target =
                new File(getClass().getResource("target.xml").getFile());
        String systemID = target.toURI().toURL().toString();
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new FilePermission(_filepath + "/-", "read,write,delete"),
                    new FilePermission(_curdir + "/-", "read,write,delete"),
                new java.awt.AWTPermission("listenToAllAWTEvents"),
                new RuntimePermission("accessClassInPackage.com.sun.org.apache.xml.internal.dtm"),
                new RuntimePermission("accessClassInPackage.com.sun.org.apache.xerces.internal.parsers")
                );
        Policy.setPolicy(p);
        System.setSecurityManager(new SecurityManager());

        DTMManagerDefault manager = new DTMManagerDefault() {
            // We need a SAXParser that does the job of SAXParser
            //   without quite being SAXParser itself.
            // So we return an instance of an (anonymous) subclass.
            public org.xml.sax.XMLReader getXMLReader(
                javax.xml.transform.Source inputSource
            ) {
                org.xml.sax.XMLReader reader =
                    super.getXMLReader(inputSource);
                return
                   new
                       com.sun.org.apache.xerces.internal.parsers.
                       SAXParser() { };
            }
        };
        // Enable incremental parsing.
        manager.setIncremental(true);

        // Grab old threads, so we can detect the new one.
        java.util.Set oldThreads = getThreads();

        com.sun.org.apache.xml.internal.dtm.DTM dtm =
            manager.getDTM(
                new javax.xml.transform.stream.StreamSource(systemID),
                true, // unique
                null, // DTMWSFilter
                true, // incremental
                false // doIndexing
            );

        // Should be exactly one new thread.
        java.util.Set threads = getThreads();
        threads.removeAll(oldThreads);
        if (threads.size() != 1) {
            throw new Error(threads.toString());
        }
        Thread thread = (Thread) threads.iterator().next();
        // Suspend the thread.
        thread.suspend();
        // Run the Thread as a Runnable
        //   without user code on the stack.
        java.awt.EventQueue.invokeLater(thread);

        // Ensure correct termination by counting number of threads
        Thread.sleep(100);
        assert getThreads().size() == 5;

        // Call exit to kill all remaining threads
        System.exit(0);
    }

    private static java.util.Set getThreads() {
        Thread[] threads = new Thread[Thread.activeCount()*2+10];
        Thread.enumerate(threads);
        return new java.util.HashSet(
            java.util.Arrays.asList(threads)
        );
    }
}
