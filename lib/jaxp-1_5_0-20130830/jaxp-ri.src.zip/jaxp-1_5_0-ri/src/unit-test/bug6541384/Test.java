/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * Test.java
 *
 * Created on March 23, 2007, 10:59 AM
 *
 * Ensure that methods on Type are not publicly accessible
 */

package bug6541384;

import common.SimplePolicy;
import java.io.*;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.security.Policy;
import java.security.ProtectionDomain;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Unit test for 6541384
 * XSLTC should stop compiling if exception is thrown by an URIResolver
 *
 * @author joe.wang@sun.com
 */
public class Test extends TestCase {
    String _cache = "";
    private boolean hasSM;
    private Policy _orig;

    public static void main(String [] args){
        TestRunner.run(Test.class);
    }

    public Test() {

    }
    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }
        _orig = Policy.getPolicy();
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                new RuntimePermission("setIO"));
        if (hasSM) {
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void test() throws Exception {
        final String XSL = ""
                        +"<?xml version='1.0'?>"
                        +"<xsl:stylesheet "
                        +"    xmlns:xsl='http://www.w3.org/1999/XSL/Transform' "
                        +"    version='1.0'   "
                        +"    xmlns:java='http://xml.apache.org/xalan/java'"
                        +"    exclude-result-prefixes='java'>"

                        // Both include and import show the issue.
                        /**/
                        +"  <xsl:include href='../target.xsl'/>"

                        +"  <xsl:import href='../target.xsl'/>"


                        // document('...') obeys URIResolver.
                        /*
                        +"  <xsl:template match='/'>"
                        +"    <xsl:value-of select='document(\"../target.xsl\")'/>"
                        +"  </xsl:template>"
                        */
                        +"</xsl:stylesheet> ";
        final String SRC = ""
                        +"<?xml version='1.0'?>"
                        +"<doc/>";

        PrintStream printStream  = new PrintStream(new FilteredStream(new ByteArrayOutputStream()));
        System.setErr(printStream);

        javax.xml.parsers.SAXParserFactory saxFactory =
            javax.xml.parsers.SAXParserFactory.newInstance();

        saxFactory.setFeature(
            javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING,
            true
        );

        javax.xml.parsers.SAXParser parser = saxFactory.newSAXParser();
        org.xml.sax.XMLReader xmlReader = parser.getXMLReader();
        xmlReader.setEntityResolver(new org.xml.sax.EntityResolver() {
                public org.xml.sax.InputSource resolveEntity(
                    String publicId, String systemId
                ) throws org.xml.sax.SAXException, java.io.IOException {
                    throw new org.xml.sax.SAXException(
                        "Will not resolve entities (for stylesheet)"
                    );
                }
        });

        javax.xml.transform.TransformerFactory factory =
            javax.xml.transform.TransformerFactory.newInstance();

        factory.setURIResolver(new javax.xml.transform.URIResolver() {
                public javax.xml.transform.Source resolve(
                    String href, String base
                ) throws javax.xml.transform.TransformerException {
                    throw new
                        //RuntimeException
                        javax.xml.transform.TransformerException
                        (
                            "URIResolver Exception!"
                        );
                }
        });

        factory.setFeature(
            javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING,
            true
        );

        try {
            javax.xml.transform.Transformer transformer = factory.newTransformer(
                new javax.xml.transform.sax.SAXSource(xmlReader,
                    new org.xml.sax.InputSource(new java.io.StringReader(XSL))
            ));
            transformer.transform(
                new javax.xml.transform.stream.StreamSource(
                    new java.io.StringReader(SRC)
                ),
                new javax.xml.transform.stream.StreamResult(
                    System.out
                )
            );
        } catch (Exception e) {
            if (_cache.indexOf("URIResolver Exception!") < 0) {
                fail("Should not continue after URIResolver exception: " + _cache);
            }
        }

    }
    class FilteredStream extends FilterOutputStream {
        public FilteredStream(OutputStream aStream) {
            super(aStream);
          }

        public void write(byte b[]) throws IOException {
            _cache += new String(b);
        }

        public void write(byte b[], int off, int len) throws IOException {
            _cache += new String(b , off , len);
            }
    }
}
