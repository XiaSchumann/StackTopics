/*
 * Test.java
 *
 * Created on Sep 26, 2007, 7:26:16 AM
 *
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package bug6608841;

import java.io.IOException;
import java.io.InputStream;
import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import junit.framework.*;
import junit.textui.TestRunner;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Unit test for CR 6564400. Check to see if whitespace can be ignored with schema validation.
 *
 * @author Norman.Walsh@Sun.COM
 */
public class Test extends TestCase {
    public Test(String name) {
        super (name);
    }

    public void testParse() throws ParserConfigurationException, SAXException, IOException {
        InputStream xmlFile = getClass().getResourceAsStream("test.xml");
        SAXParserFactory spf = SAXParserFactory.newInstance();
        SAXParser parser = spf.newSAXParser();
        parser.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");
        parser.parse(xmlFile, new MyHandler());
    }

    public static void main(String[] args) {
        TestRunner.run(Test.class);
    }

    public class MyHandler extends DefaultHandler {
    }
}
