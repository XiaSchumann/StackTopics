/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


package bug6206491;

import common.SimplePolicy;
import java.io.File;
import java.io.FilePermission;
import java.io.IOException;
import java.io.StringWriter;
import java.security.Policy;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Unit test for CR 6206491. This is a multi-document test
 * that involves key searches over more than one document.
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    private String _filePath;
    private Policy _orig;
    private boolean hasSM;

    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }
        _orig = Policy.getPolicy();

        String path = this.getClass().getResource("test.xml").getPath();
        _filePath = path.substring(0, path.lastIndexOf("/"));
        if (hasSM) {
            Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new FilePermission(_filePath + "/-", "read"));
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void test() {
        try {
            Document document = getNewXmlDoc(new File(_filePath + "/test.xml"));

            xmlxsl2html(TransformerFactory.newInstance(),
                    new File(_filePath + "/test.xsl"),
                    document);
        }
        catch (Exception ex) {
            fail(ex.getMessage());
        }
    }

    void xmlxsl2html(TransformerFactory tFactory, File xslFile,
            Document document)
            throws Exception
    {
        try {
            // tFactory.setAttribute("generate-translet", Boolean.TRUE);
        } catch (Exception e) {
            // Ignore
        }

        try {
            StreamSource stylesource = new StreamSource(xslFile);
            Transformer transformer = tFactory.newTransformer(stylesource);

            transformer.clearParameters();

            DOMSource source = new DOMSource(document);

            StringWriter sw = new StringWriter();
            StreamResult result = new StreamResult(sw);
            transformer.transform(source, result);
            String s = sw.toString();
            assertFalse(s.contains("<must-be-one>0</must-be-one>"));
        }
        catch (TransformerConfigurationException ex) {
            throw ex;

        } catch (TransformerException ex) {
            throw ex;
        }
    }

    Document getNewXmlDoc(File xmlFile) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setValidating(true);

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setErrorHandler(new org.xml.sax.helpers.DefaultHandler() {
                public void fatalError(SAXParseException e) throws SAXParseException {
                    throw e;
                }
                public void error(SAXParseException e) throws SAXParseException {
                    throw e;
                }
                public void warning(SAXParseException e) throws SAXParseException {
                    throw e;
                }
            });
            return builder.parse(xmlFile);

        } catch (SAXException ex) {
            throw ex;
        } catch (ParserConfigurationException ex) {
            throw ex;
        } catch (IOException ex) {
            throw ex;
        }
    }

}
