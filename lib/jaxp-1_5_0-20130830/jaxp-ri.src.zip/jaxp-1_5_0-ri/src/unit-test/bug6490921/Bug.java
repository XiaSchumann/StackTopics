/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package bug6490921;

import common.SimplePolicy;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.security.Policy;
import java.util.PropertyPermission;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.stream.StreamResult;
import junit.framework.Assert;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {
    private boolean hasSM;
    private Policy _orig;

    public static class ReaderStub extends XMLFilterImpl {
        static boolean used = false;

        public ReaderStub() throws ParserConfigurationException, SAXException {
            super();
            super.setParent(SAXParserFactory.newInstance().newSAXParser().getXMLReader());
        }

        public void parse(InputSource input)
            throws SAXException, IOException {
            used = true;
            super.parse(input);
        }

        public void parse(String systemId)
            throws SAXException, IOException {
            used = true;
            super.parse(systemId);
        }
    }

    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }
    
    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }
        _orig = Policy.getPolicy();

        if (hasSM) {
            Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new PropertyPermission("org.xml.sax.driver", "write"));
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void test01() {
        String xml = "<?xml version='1.0'?><root/>";
        ReaderStub.used = false;
        System.setProperty("org.xml.sax.driver", "");

        // Don't set 'org.xml.sax.driver' here, just use default
        try {
            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            InputSource in = new InputSource(new StringReader(xml));
            SAXSource source = new SAXSource(in);
            StreamResult result = new StreamResult(new StringWriter());
            transformer.transform(source, result);
            Assert.assertTrue(!printWasReaderStubCreated());
        } catch (Exception ex) {
            fail(ex.getMessage());
        } finally {
            System.clearProperty("org.xml.sax.driver");
        }
    }

    public void test02() {
        String xml = "<?xml version='1.0'?><root/>";
        ReaderStub.used = false;

        System.setProperty("org.xml.sax.driver", ReaderStub.class.getName());

        try {
            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            InputSource in = new InputSource(new StringReader(xml));
            SAXSource source = new SAXSource(in);
            StreamResult result = new StreamResult(new StringWriter());
            transformer.transform(source, result);
            Assert.assertTrue(printWasReaderStubCreated());
        } catch (Exception ex) {
            fail(ex.getMessage());
        } finally {
            System.clearProperty("org.xml.sax.driver");
        }
    }

    public void test03() {
        String xsl = "<?xml version='1.0'?>\n"
                + "<xsl:stylesheet"
                + " xmlns:xsl='http://www.w3.org/1999/XSL/Transform'"
                + " version='1.0'>\n"
                + "   <xsl:template match='/'>Hello World!</xsl:template>\n"
                + "</xsl:stylesheet>\n";

        ReaderStub.used = false;
        System.setProperty("org.xml.sax.driver", ReaderStub.class.getName());

        try {
            TransformerFactory transFactory = TransformerFactory.newInstance();
            if (transFactory.getFeature(SAXTransformerFactory.FEATURE) == false) {
                System.out.println("SAXTransformerFactory not supported");
            }
            InputSource in = new InputSource(new StringReader(xsl));
            SAXSource source = new SAXSource(in);

            transFactory.newTransformer(source);
            Assert.assertTrue(printWasReaderStubCreated());
        } catch (TransformerException e) {
            fail(e.getMessage());
        } finally {
            System.clearProperty("org.xml.sax.driver");
        }
    }

    private static boolean printWasReaderStubCreated() {
        if (ReaderStub.used) {
            System.out.println("\tReaderStub is used.");
            return ReaderStub.used;
        } else {
            System.out.println("\tReaderStub is not used.");
            return ReaderStub.used;
        }
    }
}
