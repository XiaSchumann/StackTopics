/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


package bug6489502;

import java.io.File;
import javax.xml.stream.*;

import junit.framework.TestCase;
import junit.framework.Assert;
import junit.textui.TestRunner;

import java.io.FileWriter;

/**
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {

    public java.io.File input;
    public final String filesDir = "./";
    protected XMLInputFactory inputFactory = XMLInputFactory.newInstance();
    protected XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();

    private static String xml = "<?xml version=\"1.0\"?><PLAY><TITLE>The Tragedy of Hamlet, Prince of Denmark</TITLE></PLAY>";

    public static void main(String [] args) {
        TestRunner.run(Test.class);
    }

    public void testEventReader1() {
        try {
            // Check if event reader returns the correct event
            XMLEventReader e1 =
                    inputFactory.createXMLEventReader(
                        inputFactory.createXMLStreamReader(new java.io.StringReader(xml)));
            Assert.assertEquals(e1.peek().getEventType(),
                                XMLStreamConstants.START_DOCUMENT);

            // Repeat same steps to test factory state
            XMLEventReader e2 =
                    inputFactory.createXMLEventReader(
                        inputFactory.createXMLStreamReader(new java.io.StringReader(xml)));
            Assert.assertEquals(e2.peek().getEventType(),
                                XMLStreamConstants.START_DOCUMENT);
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }

    public void testEventReader2() {
        try {
            // Now advance underlying reader and then call peek on event reader
            XMLStreamReader s1 =
                    inputFactory.createXMLStreamReader(new java.io.StringReader(xml));
            Assert.assertEquals(s1.getEventType(),
                                XMLStreamConstants.START_DOCUMENT);
            s1.next(); s1.next();    // advance to <TITLE>
            Assert.assertTrue(s1.getLocalName().equals("TITLE"));

            XMLEventReader e3 = inputFactory.createXMLEventReader(s1);
            Assert.assertEquals(e3.peek().getEventType(),
                                XMLStreamConstants.START_ELEMENT);
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
