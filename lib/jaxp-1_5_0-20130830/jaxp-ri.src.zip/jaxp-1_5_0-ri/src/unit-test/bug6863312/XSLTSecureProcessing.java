/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bug6863312;

import java.io.FileInputStream;
import javax.xml.XMLConstants;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.InputStream;
import java.io.StringWriter;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;

import junit.textui.TestRunner;
import junit.framework.*;

/**
 * copied from javax.xml.transform.ExtensionTest
 * when a security manager is in place, jaxp secure processing should be on, always
 * this is to test that related to the TransformerFactory
 *
 * Three tests in this test case:
 *
 * 1. by default, secure processing is off, but is turned on automatically when
 *    security manager is present.
 * 2. try setting secure processing off, throws TransformerConfigurationException with
 *    a message "secure processing can not be turned off" if security manager is present
 * 3. try setting secure processing on, always throws exception that extension functions
 *    are disabled while secure processing is on
 *
 * @author Joe.Wang
 */
public class XSLTSecureProcessing extends TestCase {
    StreamSource xslSource = null;
    StreamSource xmlSource = null;
    InputStream xslStream;
    InputStream  xmlStream;
    StringWriter xmlResultString;
    StreamResult xmlResultStream;
    // the transformer
    TransformerFactory transformerFactory = null;
    Transformer transformer = null;
    String xmlResult;
    boolean _isSecureMode = false;

    public XSLTSecureProcessing(String name) {
        super(name);
        if (System.getSecurityManager() != null) {
            _isSecureMode = true;
            System.out.println("Security Manager is present");
        } else {
            System.out.println("Security Manager is NOT present");
        }
    }

    public static void main(String [] args) {
        TestRunner.run(XSLTSecureProcessing.class);
    }
    // by default, SECURE_PROCESSING == false
    public void testDefault() throws Exception {
        System.out.println("1. Test default setting:");
        boolean exceptionCaught = false;
        // the style sheet
        xslSource = new StreamSource(this.getClass().getResourceAsStream("ExtensionTest.xsl"));
        // the xml source
        xmlSource = new StreamSource(this.getClass().getResourceAsStream("SecureProcessingTest.xml"));
        // the xml result
        xmlResultString = new StringWriter();
        xmlResultStream = new StreamResult(xmlResultString);
        try {
            transformerFactory = TransformerFactory.newInstance();
            transformer = transformerFactory.newTransformer(xslSource);
            transformer.transform(xmlSource, xmlResultStream);
            // expected success and the result is ...
            xmlResult = xmlResultString.toString();
            System.out.println(
                "Success. \nTransformation result (by default, SECURE_PROCESSING == false) = \"" + xmlResult + "\"");
        } catch (TransformerConfigurationException ex) {
                fail("Fail: " + ex.toString());
        } catch (TransformerException ex) {
            exceptionCaught = true;
            if (_isSecureMode) { // secure mode, expected exception
                System.out.println("SECURITY_PROCESSING is set true due to the present of security manager");
                System.out.println("Expected exception: " + ex.toString());
            } else {
                fail("Fail: " + ex.toString());
            }
        }
        //should throw exception when security manager is present
        if (_isSecureMode && !exceptionCaught) {
            fail("Fail: should throw exception when security manager is present");
        }
    }
    // set SECURE_PROCESSING == false
    public void testSetSPoff() throws Exception {
        System.out.println("2. Test setting secure processing to false:");
        boolean exceptionCaught = false;
        // the style sheet
        xslSource = new StreamSource(this.getClass().getResourceAsStream("ExtensionTest.xsl"));
        // the xml source
        xmlSource = new StreamSource(this.getClass().getResourceAsStream("SecureProcessingTest.xml"));
        // the xml result
        xmlResultString = new StringWriter();
        xmlResultStream = new StreamResult(xmlResultString);
        try {
            transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            transformer = transformerFactory.newTransformer(xslSource);
            transformer.transform(xmlSource, xmlResultStream);
            // success and the result is ...
            xmlResult = xmlResultString.toString();
            System.out.println(
                    "Transformation result (SECURE_PROCESSING == false) = \"" + xmlResult + "\"");
        } catch (TransformerConfigurationException ex) {
            exceptionCaught = true;
            if (_isSecureMode) {
                System.out.println("Expected exception: " + ex.toString());
            } else {
                fail("Fail: " + ex.toString());
            }
        } catch (TransformerException ex) {
            fail("Fail: " + ex.toString());
            ex.printStackTrace();
        }

        // expecting exception when security manager is present
        if (_isSecureMode && !exceptionCaught) {
            fail("Fail: can not set secure processing to false when security manager is present.");
        } else {
        }

    }
    //SECURE_PROCESSING == true
    public void testSetSPon() throws Exception {
        System.out.println("3. Test setting secure processing to true:");
        boolean exceptionCaught = false;
        // the style sheet
        xslSource = new StreamSource(this.getClass().getResourceAsStream("ExtensionTest.xsl"));
        // the xml source
        xmlSource = new StreamSource(this.getClass().getResourceAsStream("SecureProcessingTest.xml"));
        // the xml result
        xmlResultString = new StringWriter();
        xmlResultStream = new StreamResult(xmlResultString);

        // transform with a secure Transformer
        try {
            transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            transformer = transformerFactory.newTransformer(xslSource);
            transformer.transform(xmlSource, xmlResultStream);
            System.out.println("SECURITY_PROCESSING=" + transformerFactory.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING));
        } catch (TransformerConfigurationException ex) {
            fail("Fail: " + ex.toString());
            //ex.printStackTrace();
        } catch (TransformerException ex) {
            // expected failure
            System.out.println(
                    "Expected error: " + ex.toString());
            //ex.printStackTrace(System.out);
            exceptionCaught = true;
        }

        // unexpected success?
        if (!exceptionCaught) {
            // and the result is ...
            xmlResult = xmlResultString.toString();
            fail(
                    "Fail: Transformation result (SECURE_PROCESSING == true) = \"" + xmlResult + "\"");
            System.err.println("SECURITY_PROCESSING == true, expecting error but got result: \"" + xmlResult + "\"");
        }
    }
}
