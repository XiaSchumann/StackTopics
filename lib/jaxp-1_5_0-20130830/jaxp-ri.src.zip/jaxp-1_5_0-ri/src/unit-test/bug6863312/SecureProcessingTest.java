/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bug6863312;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javax.xml.XMLConstants;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.InputStream;
import java.io.StringWriter;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

import junit.textui.TestRunner;
import junit.framework.*;
/**
 * 6863312 Feature for Secure Processing
 * https://jaxp.dev.java.net/1.4/JAXP-Compatibility.html#JAXP_security
 * When security manager is present, this feature should be turned on always.
 *
 * See also XSLTSecureProcessing which tests in more detail regarding extension functions
 *
 * @author Joe.Wang
 */
public class SecureProcessingTest extends TestCase {
    StreamSource xslSource = null;
    StreamSource xmlSource = null;
    InputStream xslStream;
    InputStream  xmlStream;
    StringWriter xmlResultString;
    StreamResult xmlResultStream;
    Transformer transformer = null;
    String xmlResult;

    boolean _isSecureMode = false;
    int numFailures = 0;

    public SecureProcessingTest(String name) {
        super(name);
        if (System.getSecurityManager() != null) {
            _isSecureMode = true;
            System.out.println("Security Manager is present");
        } else {
            System.out.println("Security Manager is NOT present");
        }
    }

    public static void main(String [] args) {
        TestRunner.run(SecureProcessingTest.class);
    }


    public void testTransformerFactory() throws TransformerConfigurationException {
        System.out.println("\nTest TransformerFactory:");

        System.out.println("\nTest: default setting");
        TransformerFactory transformerFactory = null;
        transformerFactory = TransformerFactory.newInstance();
        boolean secureOn = (boolean)transformerFactory.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        // by default, SECURE_PROCESSING == false
        checkSuccess(_isSecureMode?true:false, _isSecureMode?true:false, secureOn);

        System.out.println("\nTest: trying to set the feature off");
        try {
            transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            secureOn = (boolean)transformerFactory.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        } catch (TransformerConfigurationException ex) {
            System.out.println("Exception: " + ex.getMessage());
            secureOn = true;
        }
        checkSuccess(_isSecureMode?true:false, true, secureOn);

        System.out.println("\nTest: trying to set the feature on");
        transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        secureOn = (boolean)transformerFactory.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        checkSuccess(true, false, secureOn);
    }

    public void testXPathFactory() throws XPathFactoryConfigurationException {
        System.out.println("\nTest XPathFactory:");

        System.out.println("\nTest: default setting");
        XPathFactory xPathFactory = XPathFactory.newInstance();
        boolean secureOn = (boolean)xPathFactory.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        System.out.println("\ndefault:" + secureOn);

        // by default, SECURE_PROCESSING == false
        checkSuccess(_isSecureMode?true:false, false, secureOn);

        System.out.println("\nTest: trying to set the feature off");

        try {
            xPathFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            secureOn = (boolean)xPathFactory.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        } catch (XPathFactoryConfigurationException ex) {
            System.out.println("Exception: " + ex.getMessage());
            secureOn = true;
        }
        checkSuccess(_isSecureMode?true:false, true, secureOn);

        System.out.println("\nTest: trying to set the feature on");
        xPathFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        secureOn = (boolean)xPathFactory.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        checkSuccess(true, false, secureOn);
    }

    public void testDBFactory() throws ParserConfigurationException {
        System.out.println("\nTest DocumentBuilderFactory:");

        System.out.println("\nTest: default setting");
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        boolean secureOn = (boolean)dbf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        // by default, SECURE_PROCESSING == true
        checkSuccess(_isSecureMode?true:true, false, secureOn);

        System.out.println("\nTest: trying to set the feature off");

        try {
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,false);
            secureOn = (boolean)dbf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        } catch (ParserConfigurationException ex) {
            System.out.println("Exception: " + ex.getMessage());
            secureOn = true;
        }
        checkSuccess(_isSecureMode?true:false, true, secureOn);

        System.out.println("\nTest: trying to set the feature on");
        dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        secureOn = (boolean)dbf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        checkSuccess(true, false, secureOn);
    }
    public void testSAXFactory() throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException {
        System.out.println("\nTest SAXFactory:");

        System.out.println("\nTest: default setting");
        SAXParserFactory spf = SAXParserFactory.newInstance();
        boolean secureOn = (boolean)spf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        // by default, SECURE_PROCESSING == true
        checkSuccess(_isSecureMode?true:true, false, secureOn);

        System.out.println("\nTest: trying to set the feature off");

        try {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            secureOn = (boolean)spf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        } catch (ParserConfigurationException ex) {
            System.out.println("Exception: " + ex.getMessage());
            secureOn = true;
        }
        checkSuccess(_isSecureMode?true:false, true, secureOn);

        System.out.println("\nTest: trying to set the feature on");
        spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        secureOn = (boolean)spf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        checkSuccess(true, false, secureOn);
    }
    public void testSchemaFactory() throws SAXNotRecognizedException, SAXNotSupportedException {
        System.out.println("\nTest SchemaFactory:");

        System.out.println("\nTest: default setting");
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        boolean secureOn = (boolean)sf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        // by default, SECURE_PROCESSING == true
        checkSuccess(_isSecureMode?true:true, false, secureOn);

        System.out.println("\nTest: trying to set the feature off");

        try {
            sf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            secureOn = (boolean)sf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        } catch (SAXNotSupportedException ex) {
            System.out.println("Exception: " + ex.getMessage());
            secureOn = true;
        }
        checkSuccess(_isSecureMode?true:false, true, secureOn);

        System.out.println("\nTest: trying to set the feature on");
        sf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        secureOn = (boolean)sf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        checkSuccess(true, false, secureOn);
    }

    public void testSchemaValidator() throws SAXNotRecognizedException, SAXNotSupportedException,
            FileNotFoundException, SAXException {
        System.out.println("\nTest XMLSchemaValidatorComponentManager:");

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        String file = getClass().getResource("types.xsd").getFile();
        Source[] sources = new Source[]{new StreamSource(new FileInputStream(file), file)};
        Schema schema = sf.newSchema(sources);
        Validator validator = schema.newValidator();

        System.out.println("\nTest: default setting");
        boolean secureOn = (boolean)validator.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        // by default, SECURE_PROCESSING should be true, it was false previously
        // due to a bug that's now fixed with 6927050
        checkSuccess(_isSecureMode?true:true, false, secureOn);

        System.out.println("\nTest: trying to set the feature off");

        try {
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            secureOn = (boolean)validator.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        } catch (SAXNotSupportedException ex) {
            System.out.println("Exception: " + ex.getMessage());
            secureOn = true;
        }
        checkSuccess(_isSecureMode?true:false, true, secureOn);

        System.out.println("\nTest: trying to set the feature on");
        validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        secureOn = (boolean)validator.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING);
        checkSuccess(true, false, secureOn);
    }

    public void report() {
        if (numFailures > 0) {
            System.out.println("Number of failures: "  + numFailures);
        }

    }
    void checkSuccess(boolean expectedValue, boolean expectedException, boolean result) {
        if (_isSecureMode) {
            if (expectedException) {
                if (!result)
                {
                    fail("**Fail**: when security manager is present, FEATURE_SECURE_PROCESSING cannot be turned off.");
                    numFailures++;
                } else {
                    System.out.println("Success: exception caught. When security manager is present, FEATURE_SECURE_PROCESSING cannot be turned off.");
                }
            } else {
                if (expectedValue && !result) {
                    fail("**Fail**: when security manager is present, FEATURE_SECURE_PROCESSING should be turned on.");
                    numFailures++;
                } else {
                    System.out.println("Success: FEATURE_SECURE_PROCESSING is on when security manager is present.");
                }
            }
        } else {
            if (expectedValue != result) {
                if (expectedValue) {
                    fail("**Fail**: expecting FEATURE_SECURE_PROCESSING to be turned on, but is false.");
                    numFailures++;
                } else {
                    fail("**Fail**: expecting FEATURE_SECURE_PROCESSING to be turned off, but is on.");
                    numFailures++;
                }
            } else {
                if (expectedValue) {
                    System.out.println("Success: FEATURE_SECURE_PROCESSING is turned on.");
                } else {
                    System.out.println("Success: FEATURE_SECURE_PROCESSING is off.");
                }
            }
        }
    }
}
