/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * @(#)$Id: Bug.java,v 1.2 2007-07-19 04:35:19 ofung Exp $
 */
package bug4970951;

import java.io.StringReader;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.TypeInfoProvider;
import javax.xml.validation.ValidatorHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class Bug extends TestCase {
    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    public static final String XSD = "<?xml version='1.0'?>\n"
        + "<schema xmlns='http://www.w3.org/2001/XMLSchema'\n"
        + "        xmlns:test='jaxp13_test'\n"
        + "        targetNamespace='jaxp13_test'\n"
        + "        elementFormDefault='qualified'>\n"
        + "    <element name='test'>\n"
        + "        <complexType>\n"
        + "            <sequence>\n"
        + "                <element name='child' type='string'/>\n"
        + "            </sequence>\n"
        + "            <attribute name='id' />\n"
        + "            <attribute name='date' default='2003-12-04'/>\n"
        + "        </complexType>\n"
        + "    </element>\n"
        + "</schema>\n";

    public static final String XML = "<?xml version='1.0'?>\n"
        + "<ns:test xmlns:ns='jaxp13_test' id='i001'>\n"
        + "  <ns:child>123abc</ns:child>\n"
        + "</ns:test>\n";

    private ValidatorHandler createValidatorHandler(String xsd)
    throws SAXException {
        SchemaFactory schemaFactory =
            SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");

        StringReader reader = new StringReader(xsd);
        StreamSource xsdSource = new StreamSource(reader);

        Schema schema = schemaFactory.newSchema(xsdSource);
        return schema.newValidatorHandler();
    }

    private XMLReader createXMLReader() throws ParserConfigurationException, SAXException {
        SAXParserFactory parserFactory = SAXParserFactory.newInstance();
        parserFactory.setNamespaceAware(true);

        return parserFactory.newSAXParser().getXMLReader();
    }

    private void parse(XMLReader xmlReader, String xml) throws SAXException, IOException {
        StringReader reader = new StringReader(xml);
        InputSource inSource = new InputSource(reader);

        xmlReader.parse(inSource);
    }

    public void test() throws Exception {
        XMLReader xmlReader = createXMLReader();
        final ValidatorHandler validatorHandler = createValidatorHandler(XSD);
        xmlReader.setContentHandler(validatorHandler);

        DefaultHandler handler = new DefaultHandler() {
            public void startElement(String uri, String localName,
                    String qName, Attributes attributes)
            throws SAXException {
                if (!"ns:test".equals(qName)) {
                    return;
                }

                TypeInfoProvider infoProvider = validatorHandler.getTypeInfoProvider();
                if (infoProvider == null) {
                    throw new SAXException("Can't obtain TypeInfoProvider object.");
                }

                int index = attributes.getIndex("id");
                if (index == -1) {
                    throw new SAXException("The attribute 'id' is not in the list.");
                }

                assertTrue(infoProvider.isSpecified(index));

                index = attributes.getIndex("date");
                if (index == -1) {
                    throw new SAXException("The attribute 'date' is not in the list.");
                }

                assertFalse(infoProvider.isSpecified(index));

                System.out.println("OK");
            }
        };
        validatorHandler.setContentHandler(handler);

        parse(xmlReader, XML);
    }
}
