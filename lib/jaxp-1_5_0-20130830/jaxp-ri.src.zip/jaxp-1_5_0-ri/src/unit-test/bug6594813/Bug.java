package bug6594813;

import java.io.StringReader;
import java.io.StringWriter;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.*;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Bug extends TestCase {

    public Bug(String name) {
        super(name);
    }

    private static final String TESTXML =
            "<?xml version='1.0' ?>\n"
            + "<soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ns1='http://faulttestservice.org/wsdl'>\n"
            + "<soapenv:Body>\n"
            + "<soapenv:Fault xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/'>\n"
            + "<faultcode>\n"
            + "soapenv:Server</faultcode>\n"
            + "<faultstring>\n"
            + "com.sun.ts.tests.jaxws.sharedwebservices.faultservice.DummyException</faultstring>\n"
            + "<detail>\n"
            + "<ns1:DummyException>\n"
            + "<dummyField1>\n"
            + "dummyString1</dummyField1>\n"
            + "<dummyField2>\n"
            + "dummyString2</dummyField2>\n"
            + "</ns1:DummyException>\n"
            + "</detail>\n"
            + "</soapenv:Fault>\n"
            + "</soapenv:Body>\n"
            + "</soapenv:Envelope>\n";

    // simplest XML to re-declare same prefix/namespace mappings
    private static final String SIMPLE_TESTXML =
            "<?xml version='1.0' ?>\n"
            + "<prefix:ElementName xmlns:prefix='URI'>\n"
            + "<prefix:ElementName xmlns:prefix='URI'>\n"
            + "</prefix:ElementName>\n"
            + "</prefix:ElementName>\n";

    public Bug() {
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    private String runTransform(SAXParser sp) throws Exception {
        // Run identity transform using SAX parser
        SAXSource src = new SAXSource(sp.getXMLReader(),
            new InputSource(new StringReader(TESTXML)));
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        StringWriter sw = new StringWriter();
        transformer.transform(src, new StreamResult(sw));

        String result = sw.getBuffer().toString();
        // System.out.println(result);
        return result;
    }

    private void checkWellFormedness(String xml) throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);       // Same as default
        spf.setFeature("http://xml.org/sax/features/namespace-prefixes", true);
        SAXParser sp = spf.newSAXParser();

        // Re-parse output to make sure that it is well formed
        sp.parse(new InputSource(new StringReader(xml)),
            new DefaultHandler());
    }

    /**
     * Test an identity transform of an XML document with NS decls
     * using a non-ns-aware parser. Output result to a StreamSource.
     * Set ns-awareness to FALSE and prefixes to FALSE.
     */
    public void testXMLNoNsAwareStreamResult1() {
        try {
            // Create SAX parser *without* enabling ns
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(false);       // Same as default
            spf.setFeature("http://xml.org/sax/features/namespace-prefixes", false);
            SAXParser sp = spf.newSAXParser();

            // Make sure that the output is well formed
            String xml = runTransform(sp);
            checkWellFormedness(xml);
        }
        catch (Throwable ex) {
            fail(ex.toString());
        }
    }

    /**
     * Test an identity transform of an XML document with NS decls
     * using a non-ns-aware parser. Output result to a StreamSource.
     * Set ns-awareness to FALSE and prefixes to TRUE.
     */
    public void testXMLNoNsAwareStreamResult2() {
        try {
            // Create SAX parser *without* enabling ns
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(false);       // Same as default
            spf.setFeature("http://xml.org/sax/features/namespace-prefixes", true);
            SAXParser sp = spf.newSAXParser();

            // Make sure that the output is well formed
            String xml = runTransform(sp);
            checkWellFormedness(xml);
        }
        catch (Throwable ex) {
            fail(ex.toString());
        }
    }

    /**
     * Test an identity transform of an XML document with NS decls
     * using a non-ns-aware parser. Output result to a StreamSource.
     * Set ns-awareness to TRUE and prefixes to FALSE.
     */
    public void testXMLNoNsAwareStreamResult3() {
        try {
            // Create SAX parser *without* enabling ns
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(true);       // Same as default
            spf.setFeature("http://xml.org/sax/features/namespace-prefixes", false);
            SAXParser sp = spf.newSAXParser();

            // Make sure that the output is well formed
            String xml = runTransform(sp);
            checkWellFormedness(xml);
        }
        catch (Throwable ex) {
            fail(ex.toString());
        }
    }

    /**
     * Test an identity transform of an XML document with NS decls
     * using a non-ns-aware parser. Output result to a StreamSource.
     * Set ns-awareness to TRUE and prefixes to TRUE.
     */
    public void testXMLNoNsAwareStreamResult4() {
        try {
            // Create SAX parser *without* enabling ns
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(true);       // Same as default
            spf.setFeature("http://xml.org/sax/features/namespace-prefixes", true);
            SAXParser sp = spf.newSAXParser();

            // Make sure that the output is well formed
            String xml = runTransform(sp);
            checkWellFormedness(xml);
        }
        catch (Throwable ex) {
            fail(ex.toString());
        }
    }

}
