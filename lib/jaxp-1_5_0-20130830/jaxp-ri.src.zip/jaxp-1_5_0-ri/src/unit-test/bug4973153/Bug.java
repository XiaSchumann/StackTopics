/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * @(#)$Id: Bug.java,v 1.2 2007-07-19 04:35:20 ofung Exp $
 */
package bug4973153;

import java.io.StringReader;

import java.io.*;
import java.io.PrintWriter;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.security.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.w3c.dom.ls.*;
import org.w3c.dom.traversal.NodeFilter;
import org.xml.sax.*;
import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug extends TestCase {

    DOMImplementationLS implLS = null;
    public String xml1 = "<?xml version=\"1.0\"?><ROOT><ELEMENT1></ELEMENT1><ELEMENT2></ELEMENT2></ROOT>";
    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

        public void testOne(){
                LSParser  db = createLSParser ();
        if (db == null) {
                        System.out.println("Unable to create LSParser !");
            return;
                }
                        LSSerializer dw = createLSSerializer();
            if (dw == null) {
                                System.out.println("Unable to create LSSerializer!");
                return;
            }

            DOMErrorHandlerImpl eh = new DOMErrorHandlerImpl();
            dw.getDomConfig().setParameter("error-handler",eh);
            Document doc = db.parse(getXml1Source());

            Output out = new Output();
            out.setByteStream(new ByteArrayOutputStream());
            out.setEncoding("WrOnG_EnCoDiNg");
                        try{
                if (dw.write(doc,out)){
                                        System.out.println("Expected result value - false");
                        return;
                }
                        }catch(Exception ex){
                                //This is bad.
                        }
            if (!eh.WrongEncodingErrorReceived) {
                fail("'unsupported-encoding' error was expected ");
                                return;
            }
            System.out.println("OKAY");
                        return;
    }

    protected void setUp() {
        Document doc = null;
        DocumentBuilder parser = null;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            parser = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
                StringBufferInputStream is = new StringBufferInputStream(xml1);
        try {
            doc = parser.parse(is);
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        DOMImplementation impl = doc.getImplementation();
        implLS = (DOMImplementationLS) impl.getFeature("LS","3.0");
    }

    protected void tearDown() {
        implLS = null;
    }

        public LSParser  createLSParser () {
        return implLS.createLSParser (DOMImplementationLS.MODE_SYNCHRONOUS,
                                                                                "http://www.w3.org/2001/XMLSchema");
    }
        public LSSerializer createLSSerializer() {
                return implLS.createLSSerializer();
        }

        public LSInput createLSInput() {
        return implLS.createLSInput();
    }

        public LSInput getXml1Source() {
        LSInput src = createLSInput();
        src.setStringData(xml1);
        return src;
    }
}
    class Output implements LSOutput {
        OutputStream bs;
        Writer cs;
        String sId;
        String enc;

        public Output() {
            bs = null;
            cs = null;
            sId = null;
            enc = "UTF-8";
        }

        public OutputStream getByteStream() {
            return bs;
        }
        public void setByteStream(OutputStream byteStream) {
            bs = byteStream;
        }
        public Writer getCharacterStream() {
            return cs;
        }
        public void setCharacterStream(Writer characterStream) {
            cs = characterStream;
        }
        public String getSystemId() {
            return sId;
        }
        public void setSystemId(String systemId) {
            sId = systemId;
        }
        public String getEncoding() {
            return enc;
        }
        public void setEncoding(String encoding) {
            enc = encoding;
        }
    }

    class DOMErrorHandlerImpl implements DOMErrorHandler {
        boolean NoOutputSpecifiedErrorReceived = false;
        boolean WrongEncodingErrorReceived = false;

        public boolean handleError(DOMError error) {
            if ("no-output-specified".equalsIgnoreCase(error.getType())) {
                NoOutputSpecifiedErrorReceived = true;
            } else if ("unsupported-encoding".equalsIgnoreCase(error.getType())) {
                WrongEncodingErrorReceived = true;
            }
            return true;
        }
    }
