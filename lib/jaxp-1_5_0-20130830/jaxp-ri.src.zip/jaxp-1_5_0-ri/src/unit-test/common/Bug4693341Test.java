/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2010 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


package common;


import javax.xml.parsers.SAXParser;
/**
import org.vmguys.vmtools.utils.DomFactory;
import org.vmguys.vmtools.utils.CostOps;
import org.vmguys.vmtools.utils.DifferenceFinder2;
*/
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.StringWriter;
import java.net.URL;
import javax.xml.XMLConstants;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

/**
 * CR4693341 -- see Bug4693341 in sqe gap test
 *
 * Patch for CR6435319 caused regression to the above
 * Test Bug4693341 uses JDOM which takes a URL with relative file path
 * The java.net.URI lacks the ability to absolutize file path as
 * Xerces URI does
 *
 * @author joe.wang@sun.com
 */
public class Bug4693341Test extends TestCase {

    /**
     * @param name Name of test.
     */
    public Bug4693341Test(String name) {
         super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(Bug4693341Test.class);
    }

/**
     * Improper Serialization of XML attachment
     */
    public void test() {
        boolean status = false;

        File xmlFile = new File("./jaxp-ri/src/unit-test/common/Bug4693341.xml");

        try {
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            
            String out = "jaxp-ri/src/unit-test/common" + File.separator+"Bug4693341.out";
            StreamResult result = new StreamResult(new FileOutputStream (out));

            String in = getClass().getResource("Bug4693341.xml").getPath();
            String golden  = "///C:/Projects/Jaxp/wsOnKenai/jaxp-sources/jaxp-ri/src/unit-test/common" + File.separator+"Bug4693341_golden.xml";
            File file = new File(in);
            StreamSource source = new StreamSource(new FileInputStream(file), ("file://" + in));
            System.err.println("file.toURI().toURL().toString()="+file.toURI().toURL().toString());
            System.err.println(source.getSystemId());

            transformer.transform(source, result);
            /*
             * This will check if the input and output are equal
             * This uses the isXMLEqual method defined in util
             */

            URL inputsource = new URL("file","",golden);
            URL output = new URL("file","",out);

            //error happens when trying to parse output

            String systemId = output.toExternalForm();
            System.out.println("systemId: "+systemId);
             InputSource is = new InputSource(systemId);
             SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
             parser.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");
             parser.parse(is, new DefaultHandler());

            //status = isXMLEqual(inputsource,output);
            //System.err.println("Files equal: " + isXMLEqual(inputsource,output)) ;


        } catch (Exception ex) {
            fail(ex.getMessage());
        }
      }

   /**
    *  Reused code from the JAXBUtil
    *  This uses the third party library vmtools
    *  to find out if the xml documents are equal
    */
    /**
    public static boolean isXMLEqual(URL url1, URL url2) {
      try {
         org.jdom.input.SAXBuilder sb = new org.jdom.input.SAXBuilder();
         sb.setFactory(new DomFactory());

         org.jdom.Document doc1 = sb.build(url1);
         org.jdom.Document doc2 = sb.build(url2);
         DifferenceFinder2 df = new DifferenceFinder2();
         CostOps diff = df.findDifferences(doc1.getRootElement(),
                    doc2.getRootElement());
         System.err.println("[XMLDiffs]" + diff.getCost());

         return (diff.getCost()==0)?true:false;

      } catch (Exception e) {
         e.printStackTrace();
      }
      return false;
   }
     */


}
