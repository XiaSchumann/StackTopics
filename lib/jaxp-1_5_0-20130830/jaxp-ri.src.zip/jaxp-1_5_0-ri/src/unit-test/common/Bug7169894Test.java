/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2012 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package common;

import java.net.URL;
import java.net.URLClassLoader;
import java.security.*;
import javax.xml.XMLConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.transform.TransformerFactory;
import javax.xml.validation.SchemaFactory;
import javax.xml.xpath.XPathFactory;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * 7169894: JAXP Plugability Layer: using service loader
 * see also 6975142: JAXP FactoryFinder fails to locate provider
 *
 * @author <a href="mailto:huizhe.wang@oracle.com">Joe Wang</a>
 *
 */
public class Bug7169894Test extends TestCase {
    static final String MYDATATYPEFACTORY ="test.factoryfinder.MyDatatypeFactory";
    static final String MYDOMFACTORY ="test.factoryfinder.MyDocumentBuilderFactory";
    static final String MYSAXPARSERFACTORY ="test.factoryfinder.MySAXParserFactory";
    static final String MYINPUTFACTORY ="test.factoryfinder.MyInputFactory";
    static final String MYTRANSFORMERFACTORY ="test.factoryfinder.MyTransformerFactory";
    static final String MYSCHEMAFACTORY ="test.factoryfinder.MySchemaFactory";
    static final String MYXPATHFACTORY ="test.factoryfinder.MyXPathFactory";

    static final String SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    static final String SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
    
    public static void main(String[] args) {
        TestRunner.run(Bug7169894Test.class);
    }

    public void xtest() {
        ClassLoader cl = this.getClass().getClassLoader();
        System.out.println("this cl: "+ cl);
        System.out.println("this cl parent: "+ cl.getParent());
        System.out.println("this cl parent's parent: "+ cl.getParent().getParent());
    }

    /**
     * this is a test copied from CR6723276
     * when system classloader is not the parent of the classloader, the serviceloader
     * will fail to load impl on the classpath
     */
    public void xtestClassLoader() {
        try {
        System.out.println(Thread.currentThread().getContextClassLoader());
        System.out.println(ClassLoader.getSystemClassLoader().getParent());
        Thread.currentThread().setContextClassLoader(new URLClassLoader(new URL[0], ClassLoader.getSystemClassLoader().getParent()));
        SAXParserFactory factory = SAXParserFactory.newInstance();
            System.out.println(factory.getClass().getName());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("org.apache.xerces.jaxp.SAXParserFactoryImpl not found")>0) {
                fail(e.getMessage());
            }
        }
    }
    /**
     * before patch, if tccl cannot find provider, bcl will be tried
     */
    public void xtestClassLoader_TCCL_BCL() {
        try {
        //Thread.currentThread().setContextClassLoader(new URLClassLoader(new URL[0], null)); //null is taken as bootstrap
        Thread.currentThread().setContextClassLoader(null);
        SAXParserFactory factory = SAXParserFactory.newInstance();
            System.out.println(factory.getClass().getName());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("org.apache.xerces.jaxp.SAXParserFactoryImpl not found")>0) {
                fail(e.getMessage());
            }
        }
    }
    public void testEventFactory_TCCL_BCL() {
        try {
        //Thread.currentThread().setContextClassLoader(new URLClassLoader(new URL[0], null));
        Thread.currentThread().setContextClassLoader(null);
        XMLEventFactory factory = XMLEventFactory.newInstance();
            System.out.println(factory.getClass().getName());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("org.apache.xerces.jaxp.SAXParserFactoryImpl not found")>0) {
                fail(e.getMessage());
            }
        }
    }
    public void xtestEventFactory_TCCL() {
        try {
        Thread.currentThread().setContextClassLoader(new URLClassLoader(new URL[0], ClassLoader.getSystemClassLoader().getParent()));
        XMLEventFactory factory = XMLEventFactory.newInstance();
            System.out.println(factory.getClass().getName());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("org.apache.xerces.jaxp.SAXParserFactoryImpl not found")>0) {
                fail(e.getMessage());
            }
        }
    }
    public void xtestSchemaFactory_TCCL() {
        try {
        System.out.println(Thread.currentThread().getContextClassLoader());
        System.out.println(ClassLoader.getSystemClassLoader().getParent());
//        Thread.currentThread().setContextClassLoader(new URLClassLoader(new URL[0], ClassLoader.getSystemClassLoader().getParent()));
        Thread.currentThread().setContextClassLoader(null);
        SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            System.out.println(factory.getClass().getName());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("org.apache.xerces.jaxp.SAXParserFactoryImpl not found")>0) {
                fail(e.getMessage());
            }
        }
    }
    public void xtestClassLoader1() {
        try {
        System.out.println(Thread.currentThread().getContextClassLoader());
        System.out.println(ClassLoader.getSystemClassLoader().getParent());
        Thread.currentThread().setContextClassLoader(new URLClassLoader(new URL[0], ClassLoader.getSystemClassLoader().getParent()));
        XMLInputFactory factory = XMLInputFactory.newInstance();
            System.out.println(factory.getClass().getName());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("org.apache.xerces.jaxp.SAXParserFactoryImpl not found")>0) {
                fail(e.getMessage());
            }
        }
    }

   /**
     * this test does not work in a normal jdk installation since stax.properties
     * will be read first
     * @throws Exception 
     */
    public void xtestDOMFactory() throws Exception {

        System.out.println("DocumentBuilderFactory: "+ MYDOMFACTORY);
            try {
                DocumentBuilderFactory xif = DocumentBuilderFactory.newInstance();
                System.out.println("Factory returned: " + xif.getClass().getName());
                //assertTrue(xif.getClass().getName().equals(MYDOMFACTORY));
            } catch(Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            } catch (Error e) {
                e.printStackTrace();
            }
    }

    public void xtestXPathFactory_SM() {
        //System.setSecurityManager(new SecurityManager());
        System.out.println("XPathFactory Impl: "+ MYXPATHFACTORY);
            try {
                XPathFactory xif = XPathFactory.newInstance();
                System.out.println(xif.getClass().getName());
                if (!xif.getClass().getName().equalsIgnoreCase(MYXPATHFACTORY)) {
                    fail(xif.getClass().getName());
                }
            } catch(Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
    }
    
   /**
     * this test does not work in a normal jdk installation since stax.properties
     * will be read first
     * @throws Exception 
     */
    public void xtestInputFactory() throws Exception {

        System.out.println("XMLInputFactory: "+ MYINPUTFACTORY);
            try {
                XMLInputFactory xif = XMLInputFactory.newInstance();
                System.out.println(xif.getClass().getName());
                assertTrue(xif.getClass().getName().equals(MYINPUTFACTORY));
            } catch(Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            } catch (Error e) {
                e.printStackTrace();
            }
    }

    /**
     * DOM and SAX use the same factory finder
     * *Note we cannot change the DOM impl since JUnit relies on it to function properly
     * @throws Exception 
     */
    public void xtestSAXFactory() {

        System.out.println("SAXFactory Impl: "+ MYSAXPARSERFACTORY);
        try {
            SAXParserFactory xif = SAXParserFactory.newInstance();
            System.out.println(xif.getClass().getName());
            if (!xif.getClass().getName().equalsIgnoreCase(MYSAXPARSERFACTORY)) {
                fail(xif.getClass().getName());
            }
        } catch(Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }

 
    
    /**
     * DOM and SAX use the same factory finder
     * *Note we cannot change the DOM impl since JUnit relies on it to function properly
     * @throws Exception 
     */
    public void xtestSAXFactory_SM() {
        Permissions granted = new java.security.Permissions();
        //granted.add(new AllPermission() );
        //System.setSecurityManager(new MySM(granted));
        
        SecurityManager sm = new SecurityManager();
        Permission p = new java.lang.RuntimePermission("setSecurityManager");
        //sm.checkPermission(p);
        System.setSecurityManager(new SecurityManager());
        System.out.println("Security is on ");
        System.out.println("SAXFactory Impl: "+ MYSAXPARSERFACTORY);
        try {
            SAXParserFactory xif = SAXParserFactory.newInstance();
            System.out.println(xif.getClass().getName());
            if (!xif.getClass().getName().equalsIgnoreCase(MYSAXPARSERFACTORY)) {
                //unsetSM();
                fail(xif.getClass().getName());
            }
        } catch(Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        
        //unsetSM();   
    }

    void unsetSM() {
            AccessController.doPrivileged(new PrivilegedAction() {
                public Object run() {
                    System.setSecurityManager(null);
                    return null;
                }
            });     
    }
    
    public void xtestDatatypeFactory() {

        System.out.println("DatatypeFactory Impl: "+ MYDATATYPEFACTORY);
            try {
                DatatypeFactory xif = DatatypeFactory.newInstance();
                System.out.println(xif.getClass().getName());
                if (!xif.getClass().getName().equalsIgnoreCase(MYDATATYPEFACTORY)) {
                    fail(xif.getClass().getName());
                }
            } catch(Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
    }

    public void xtestTransformerFactory() {

        System.out.println("TransformerFactory Impl: "+ MYTRANSFORMERFACTORY);
            try {
                TransformerFactory xif = TransformerFactory.newInstance();
                System.out.println(xif.getClass().getName());
                if (!xif.getClass().getName().equalsIgnoreCase(MYTRANSFORMERFACTORY)) {
                    fail(xif.getClass().getName());
                }
            } catch(Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
    }

    public void xtestSchemaFactory() {

        System.out.println("SchemaFactory Impl: "+ MYSCHEMAFACTORY);
            try {
                SchemaFactory xif = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
                System.out.println(xif.getClass().getName());
                if (!xif.getClass().getName().equalsIgnoreCase(MYSCHEMAFACTORY)) {
                    fail(xif.getClass().getName());
                }
            } catch(Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
    }
    public void xtestXPathFactory() {

        System.out.println("XPathFactory Impl: "+ MYXPATHFACTORY);
            try {
                XPathFactory xif = XPathFactory.newInstance();
                System.out.println(xif.getClass().getName());
                if (!xif.getClass().getName().equalsIgnoreCase(MYXPATHFACTORY)) {
                    fail(xif.getClass().getName());
                }
            } catch(Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
    }

    class MySM extends SecurityManager {
        Permissions granted;
        public MySM(Permissions perms) {
            granted = perms;
        }
        /**
        * The central point in checking permissions.
         * Overridden from java.lang.SecurityManager
        *
        * @param perm The permission requested.
        */
        @Override
         public void checkPermission(Permission perm) {
            if (granted.implies(perm)) {
                return;
            }
            super.checkPermission(perm);
         }

    }
}
