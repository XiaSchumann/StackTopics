/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2010 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package common;

import java.io.File;
import java.io.FilePermission;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.security.AccessController;
import java.security.AllPermission;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.security.Policy;
import java.security.PrivilegedAction;
import java.security.ProtectionDomain;
import java.util.PropertyPermission;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;


import org.xml.sax.SAXException;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * CR 6941169 use service mechanism
 *
 * @author huizhe.wang@oracle.com
 */
public class Bug6941169Test extends TestCase {
    static final String SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    static final String SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";

    private static final String DOM_FACTORY_ID = "javax.xml.parsers.DocumentBuilderFactory";
    private static final String SAX_FACTORY_ID = "javax.xml.parsers.SAXParserFactory";

    //impl specific feature
    final String ORACLE_FEATURE_SERVICE_MECHANISM = "http://www.oracle.com/feature/use-service-mechanism";

    static String _xml = Bug6941169Test.class.getResource("Bug6941169.xml").getPath();
    static String _xsd = Bug6941169Test.class.getResource("Bug6941169.xsd").getPath();
    private String _filepath;
    private boolean hasSM;
    private String _curdir;
    private Policy _orig;
    private Policy _new;

    public Bug6941169Test(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug6941169Test.class);
    }
    @Override
    public void setUp() {
        _filepath = _xml.substring(0, _xml.lastIndexOf('/'));

        System.out.println("_filepath=" + _filepath);
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length()-1);
        _orig = Policy.getPolicy();
        _new = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                new FilePermission(_filepath + "/-", "read,write,delete"),
                new FilePermission(_curdir + "/-", "read,write,delete"),
                new PropertyPermission("*", "read"),
                new PropertyPermission("javax.xml.parsers.DocumentBuilderFactory", "read,write"),
                new PropertyPermission("javax.xml.parsers.SAXParserFactory", "read,write")
                );
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    /**
     * validation uses the following handlers:
        ValidatorHandlerImpl -> SAXParserFactory
        DOMValidatorHelper -> DocumentBuilderFactory
        StreamValidatorHelper->SAXTransformerFactory
        StAXValidatorHelper ->SAXTransformerFactory
     * the following testcases test factory impl to verify if the
     * service mechanism is used
     */
    public void testValidation_SAX_withoutServiceMech() {
        System.out.println("Validation using SAX Source;  Service mechnism is turned off;  SAX Impl should be the default:");
        InputSource is = new InputSource(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml"));
        SAXSource ss = new SAXSource (is);
        System.setProperty(SAX_FACTORY_ID, "MySAXFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            factory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, false);
            Schema schema = factory.newSchema(new StreamSource(_xsd));
            Validator validator = schema.newValidator();
            validator.validate(ss, null);
        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("javax.xml.parsers.FactoryConfigurationError: Provider MySAXFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        }
        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(SAX_FACTORY_ID);
    }

    public void testValidation_SAX_withServiceMech() {
        System.out.println("Validation using SAX Source. Using service mechnism (by default) to find SAX Impl:");
        InputSource is = new InputSource(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml"));
        SAXSource ss = new SAXSource (is);
        System.setProperty(SAX_FACTORY_ID, "MySAXFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(new StreamSource(_xsd));
            Validator validator = schema.newValidator();
            validator.validate(ss, null);
            fail("User impl MySAXFactoryImpl should be used.");
        } catch (Exception e) {
            String error = e.getMessage();
            if (error.indexOf("javax.xml.parsers.FactoryConfigurationError: Provider MySAXFactoryImpl not found")>0) {
                //expected
            }
            //System.out.println(e.getMessage());

        }
        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(SAX_FACTORY_ID);
    }
    public void testValidation_SAX_withSM() {
        System.out.println("Validation using SAX Source with security manager:");
        InputSource is = new InputSource(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml"));
        SAXSource ss = new SAXSource (is);
        System.setProperty(SAX_FACTORY_ID, "MySAXFactoryImpl");
        Policy.setPolicy(_new);
        System.setSecurityManager(new SecurityManager());

        long start = System.currentTimeMillis();
        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            factory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, false);
            Schema schema = factory.newSchema(new StreamSource(_xsd));
            Validator validator = schema.newValidator();
            validator.validate(ss, null);
        } catch (Exception e) {
            String error = e.getMessage();
            if (error.indexOf("javax.xml.parsers.FactoryConfigurationError: Provider MySAXFactoryImpl not found")>0) {
                fail(e.getMessage());
            } else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } finally {
            System.clearProperty(SAX_FACTORY_ID);
            System.setSecurityManager(null);
        }
        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.setSecurityManager(null);

    }
    public void testTransform_DOM_withoutServiceMech() {
        System.out.println("Transform using DOM Source;  Service mechnism is turned off;  Default DOM Impl should be the default:");
        DOMSource domSource = new DOMSource();
        domSource.setSystemId(_xml);

//        DOMSource domSource = new DOMSource(getDocument(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml")));
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, false);

            Transformer t = factory.newTransformer();

            StringWriter result = new StringWriter();
            StreamResult streamResult = new StreamResult(result);
            t.transform(domSource, streamResult);
            System.out.println("Writing to "+result.toString());

        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } catch (Error e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        }

        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }

    /** this is by default */
    public void testTransform_DOM_withServiceMech() {
        System.out.println("Transform using DOM Source;  By default, the factory uses services mechanism to look up impl:");
        DOMSource domSource = new DOMSource();
        domSource.setSystemId(_xml);

//        DOMSource domSource = new DOMSource(getDocument(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml")));
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer t = factory.newTransformer();

            StringWriter result = new StringWriter();
            StreamResult streamResult = new StreamResult(result);
            t.transform(domSource, streamResult);
            System.out.println("Writing to "+result.toString());

            fail("User impl MyDOMFactoryImpl should be used.");

        } catch (Exception e) {
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                //expected
            }
            System.out.println(error);

        } catch (Error e) {
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                //expected
            }
            System.out.println(error);

        }

        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }

    public void testTransform_DOM_withSM() {
        System.out.println("Transform using DOM Source;  Security Manager is set:");
        DOMSource domSource = new DOMSource();
        domSource.setSystemId(_xml);

//        DOMSource domSource = new DOMSource(getDocument(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml")));
        Policy.setPolicy(_new);
        System.setSecurityManager(new SecurityManager());
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            TransformerFactory factory = TransformerFactory.newInstance(
                    "com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl",
                    TransformerFactory.class.getClassLoader());
            Transformer t = factory.newTransformer();

            StringWriter result = new StringWriter();
            StreamResult streamResult = new StreamResult(result);
            t.transform(domSource, streamResult);
            System.out.println("Writing to "+result.toString());

        } catch (Exception e) {
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            } else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } catch (Error e) {
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            } else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } finally {
            System.clearProperty(DOM_FACTORY_ID);
            System.setSecurityManager(null);
        }
        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }


    public void testXPath_DOM_withoutServiceMech() {
        final String XPATH_EXPRESSION = "/fooTest";
        System.out.println("Evaluate DOM Source;  Service mechnism is turned off;  Default DOM Impl should be used:");
        Document doc = getDocument(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml"));
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
                XPathFactory xPathFactory = XPathFactory.newInstance();
                xPathFactory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, false);

                XPath xPath = xPathFactory.newXPath();

                String xPathResult = xPath.evaluate(XPATH_EXPRESSION, doc);


        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } catch (Error e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        }

        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }

    public void testXPath_DOM_withServiceMech() {
        final String XPATH_EXPRESSION = "/fooTest";
        System.out.println("Evaluate DOM Source;  Service mechnism is on by default;  It would try to use MyDOMFactoryImpl:");
        InputStream input = getClass().getResourceAsStream("Bug6941169.xml");
        InputSource source = new InputSource(input);
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            XPathFactory xPathFactory = XPathFactory.newInstance();

            XPath xPath = xPathFactory.newXPath();

            String xPathResult = xPath.evaluate(XPATH_EXPRESSION, source);
            fail("User impl MyDOMFactoryImpl should be used.");


        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                System.out.println("Tried to locate MyDOMFactoryImpl");
            }else {
                fail(e.getMessage());

            }

            //System.out.println(e.getMessage());

        }  catch (Error e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                System.out.println("Tried to locate MyDOMFactoryImpl");
            }else {
                fail(e.getMessage());

            }

            //System.out.println(e.getMessage());

        }

        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }

    public void testXPath_DOM_withSM() {
        final String XPATH_EXPRESSION = "/fooTest";
        System.out.println("Evaluate DOM Source;  Security Manager is set:");
        Policy.setPolicy(_new);
        System.setSecurityManager(new SecurityManager());
        InputStream input = getClass().getResourceAsStream("Bug6941169.xml");
        InputSource source = new InputSource(input);
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            XPathFactory xPathFactory = XPathFactory.newInstance("http://java.sun.com/jaxp/xpath/dom",
                    "com.sun.org.apache.xpath.internal.jaxp.XPathFactoryImpl", null);

            XPath xPath = xPathFactory.newXPath();

            String xPathResult = xPath.evaluate(XPATH_EXPRESSION, source);
            System.out.println("Use default impl");
        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl should be used");
            }

            //System.out.println(e.getMessage());

        }  catch (Error e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl should be used");
            }

            //System.out.println(e.getMessage());

        } finally {
            System.clearProperty(DOM_FACTORY_ID);
            System.setSecurityManager(null);
        }
        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }
    public void testSM() {
        SecurityManager sm =System.getSecurityManager();
        if (System.getSecurityManager() != null) {
            System.out.println("Security manager not cleared: " + sm.toString());
        } else {
            System.out.println("Security manager cleared: ");
        }
    }

    private static Document getDocument(InputStream in) {

        Document document = null;

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            DocumentBuilder db = dbf.newDocumentBuilder();
            document = db.parse(in);
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }

        return document;
    }
}
