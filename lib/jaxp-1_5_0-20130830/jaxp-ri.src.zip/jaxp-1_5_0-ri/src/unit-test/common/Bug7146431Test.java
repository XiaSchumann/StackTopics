/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2010 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package common;

import java.io.InputStream;
import java.io.StringWriter;
import java.security.AllPermission;
import java.security.Permission;
import java.security.Permissions;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;



import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

/**
 * CR 7146431 java.security files out-of-sync
 * 
 * @author huizhe.wang@oracle.com
 */
public class Bug7146431Test extends TestCase {
    static final String SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    static final String SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";

    private static final String DOM_FACTORY_ID = "javax.xml.parsers.DocumentBuilderFactory";
    private static final String SAX_FACTORY_ID = "javax.xml.parsers.SAXParserFactory";

    //impl specific feature
    final String ORACLE_FEATURE_SERVICE_MECHANISM = "http://www.oracle.com/feature/use-service-mechanism";

    static String _xml = Bug7146431Test.class.getResource("Bug6941169.xml").getPath();
    static String _xsd = Bug7146431Test.class.getResource("Bug6941169.xsd").getPath();

    public Bug7146431Test(String name) {
        super(name);
    }
    
    public static void main(String[] args) {
        TestRunner.run(Bug7146431Test.class);
    }

    public void testInternal() {
        Permissions granted = new java.security.Permissions();
        granted.add(new AllPermission() );
        System.setSecurityManager(new MySM(granted));

        try {
            com.sun.org.apache.xerces.internal.utils.SecuritySupport ss = 
                    com.sun.org.apache.xerces.internal.utils.SecuritySupport.getInstance();
            com.sun.org.apache.xalan.internal.utils.SecuritySupport ss1 = 
                    com.sun.org.apache.xalan.internal.utils.SecuritySupport.getInstance();
            fail("access to internal.utils should be restricted");
        } catch (Exception e) {
            //expected
        }

        System.setSecurityManager(null);

    }
    public void testTransform_DOM_withoutServiceMech() {
        System.out.println("Transform using DOM Source;  Service mechnism is turned off;  Default DOM Impl should be the default:");
        DOMSource domSource = new DOMSource();
        domSource.setSystemId(_xml);

//        DOMSource domSource = new DOMSource(getDocument(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml")));
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, false);

            Transformer t = factory.newTransformer();

            StringWriter result = new StringWriter();
            StreamResult streamResult = new StreamResult(result);
            t.transform(domSource, streamResult);
            System.out.println("Writing to "+result.toString());

        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } catch (Error e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        }

        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }

    /** this is by default */
    public void testTransform_DOM_withServiceMech() {
        System.out.println("Transform using DOM Source;  By default, the factory uses services mechanism to look up impl:");
        DOMSource domSource = new DOMSource();
        domSource.setSystemId(_xml);

//        DOMSource domSource = new DOMSource(getDocument(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml")));
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer t = factory.newTransformer();

            StringWriter result = new StringWriter();
            StreamResult streamResult = new StreamResult(result);
            t.transform(domSource, streamResult);
            System.out.println("Writing to "+result.toString());

            fail("User impl MyDOMFactoryImpl should be used.");

        } catch (Exception e) {
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                //expected
            }
            System.out.println(error);

        } catch (Error e) {
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                //expected
            }
            System.out.println(error);

        }

        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }

    public void testTransform_DOM_withSM() {
        System.out.println("Transform using DOM Source;  Security Manager is set:");
        DOMSource domSource = new DOMSource();
        domSource.setSystemId(_xml);

//        DOMSource domSource = new DOMSource(getDocument(Bug6941169Test.class.getResourceAsStream("Bug6941169.xml")));
        Permissions granted = new java.security.Permissions();
        granted.add(new AllPermission() );
        System.setSecurityManager(new MySM(granted));
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            TransformerFactory factory = TransformerFactory.newInstance(
                    "com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl",
                    TransformerFactory.class.getClassLoader());
            Transformer t = factory.newTransformer();

            StringWriter result = new StringWriter();
            StreamResult streamResult = new StreamResult(result);
            t.transform(domSource, streamResult);
            System.out.println("Writing to "+result.toString());

        } catch (Exception e) {
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            } else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } catch (Error e) {
            String error = e.getMessage();
            if (error.indexOf("Provider MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            } else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } finally {
            System.clearProperty(DOM_FACTORY_ID);
            System.setSecurityManager(null);
        }
        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }


    public void testXPath_DOM_withoutServiceMech() {
        final String XPATH_EXPRESSION = "/fooTest";
        System.out.println("Evaluate DOM Source;  Service mechnism is turned off;  Default DOM Impl should be used:");
        Document doc = getDocument(Bug7146431Test.class.getResourceAsStream("Bug6941169.xml"));
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
                XPathFactory xPathFactory = XPathFactory.newInstance();
                xPathFactory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, false);

                XPath xPath = xPathFactory.newXPath();

                String xPathResult = xPath.evaluate(XPATH_EXPRESSION, doc);


        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        } catch (Error e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl is used");
            }

            //System.out.println(e.getMessage());

        }

        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }

    public void testXPath_DOM_withServiceMech() {
        final String XPATH_EXPRESSION = "/fooTest";
        System.out.println("Evaluate DOM Source;  Service mechnism is on by default;  It would try to use MyDOMFactoryImpl:");
        InputStream input = getClass().getResourceAsStream("Bug6941169.xml");
        InputSource source = new InputSource(input);
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            XPathFactory xPathFactory = XPathFactory.newInstance();

            XPath xPath = xPathFactory.newXPath();

            String xPathResult = xPath.evaluate(XPATH_EXPRESSION, source);
            fail("User impl MyDOMFactoryImpl should be used.");


        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                System.out.println("Tried to locate MyDOMFactoryImpl");
            }else {
                fail(e.getMessage());

            }

            //System.out.println(e.getMessage());

        }  catch (Error e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                System.out.println("Tried to locate MyDOMFactoryImpl");
            }else {
                fail(e.getMessage());

            }

            //System.out.println(e.getMessage());

        }

        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }

    public void testXPath_DOM_withSM() {
        final String XPATH_EXPRESSION = "/fooTest";
        System.out.println("Evaluate DOM Source;  Security Manager is set:");
        Permissions granted = new java.security.Permissions();
        granted.add(new AllPermission() );
        System.setSecurityManager(new MySM(granted));
        InputStream input = getClass().getResourceAsStream("Bug6941169.xml");
        InputSource source = new InputSource(input);
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");
        long start = System.currentTimeMillis();
        try {
            XPathFactory xPathFactory = XPathFactory.newInstance("http://java.sun.com/jaxp/xpath/dom",
                    "com.sun.org.apache.xpath.internal.jaxp.XPathFactoryImpl", null);

            XPath xPath = xPathFactory.newXPath();

            String xPathResult = xPath.evaluate(XPATH_EXPRESSION, source);
            System.out.println("Use default impl");
        } catch (Exception e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl should be used");
            }

            //System.out.println(e.getMessage());

        }  catch (Error e) {
            //e.printStackTrace();
            String error = e.getMessage();
            if (error.indexOf("MyDOMFactoryImpl not found")>0) {
                fail(e.getMessage());
            }else {
                System.out.println("Default impl should be used");
            }

            //System.out.println(e.getMessage());

        } finally {
            System.clearProperty(DOM_FACTORY_ID);
            System.setSecurityManager(null);
        }
        long end = System.currentTimeMillis();
        double elapsedTime = ((end-start));
        System.out.println("Time elapsed: " + elapsedTime);
        System.clearProperty(DOM_FACTORY_ID);
    }
    public void testSM() {
        SecurityManager sm =System.getSecurityManager();
        if (System.getSecurityManager() != null) {
            System.out.println("Security manager not cleared: " + sm.toString());
        } else {
            System.out.println("Security manager cleared: ");
        }
    }

    private static Document getDocument(InputStream in) {

        Document document = null;

	try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
	    DocumentBuilder db = dbf.newDocumentBuilder();
            document = db.parse(in);
	} catch (Exception e) {
            e.printStackTrace();
            fail(e.toString());
	}

        return document;
    }

    class MySM extends SecurityManager {
        Permissions granted;
        public MySM(Permissions perms) {
            granted = perms;
        }
        /**
        * The central point in checking permissions.
         * Overridden from java.lang.SecurityManager
        *
        * @param perm The permission requested.
        */
        @Override
         public void checkPermission(Permission perm) {
            if (granted.implies(perm)) {
                return;
            }
            super.checkPermission(perm);
         }

    }

}
