/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2010 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package common;


import java.io.File;
import java.io.FilePermission;
import java.security.Policy;
import java.util.PropertyPermission;
import javax.xml.XMLConstants;
import javax.xml.transform.TransformerFactory;
import javax.xml.validation.SchemaFactory;
import javax.xml.xpath.XPathFactory;
import junit.framework.TestCase;
import junit.textui.TestRunner;


/**
 * CR 7143711 Feature added by 7053556 should not override what's set by the constructor in secure mode
 *
 * @author huizhe.wang@oracle.com
 */
public class Bug7143711Test extends TestCase {
    static final String SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    static final String SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";

    private static final String DOM_FACTORY_ID = "javax.xml.parsers.DocumentBuilderFactory";
    private static final String SAX_FACTORY_ID = "javax.xml.parsers.SAXParserFactory";

    //impl specific feature
    final String ORACLE_FEATURE_SERVICE_MECHANISM = "http://www.oracle.com/feature/use-service-mechanism";
    private Policy _orig;
    private boolean hasSM;
    private SimplePolicy _new;
    private String _curdir;

    public Bug7143711Test(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug7143711Test.class);
    }

    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length()-1);
        _orig = Policy.getPolicy();
        _new = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                new FilePermission(_curdir + "/-", "read,write,delete"),
                new PropertyPermission("*", "read"),
                new PropertyPermission("javax.xml.parsers.DocumentBuilderFactory", "read,write"),
                new PropertyPermission("javax.xml.parsers.SAXParserFactory", "read,write"),
                new RuntimePermission("accessClassInPackage.com.sun.org.apache.xalan.internal.xsltc.trax")
                );
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void testValidation_SAX_withSM() {
        System.out.println("Validation using SAX Source with security manager:");
        System.setProperty(SAX_FACTORY_ID, "MySAXFactoryImpl");
        Policy.setPolicy(_new);
        System.setSecurityManager(new SecurityManager());

        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            //should not allow
            factory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, true);
            if ((boolean)factory.getFeature(ORACLE_FEATURE_SERVICE_MECHANISM)) {
                fail("should not override in secure mode");
            }
        } catch (Exception e) {
            fail(e.getMessage());

        } finally {
            System.clearProperty(SAX_FACTORY_ID);
            System.setSecurityManager(null);
        }

        System.setSecurityManager(null);

    }

    public void testTransform_DOM_withSM() {
        System.out.println("Transform using DOM Source;  Security Manager is set:");

        Policy.setPolicy(_new);
        System.setSecurityManager(new SecurityManager());
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");

        try {
            TransformerFactory factory = TransformerFactory.newInstance(
                    "com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl",
                    TransformerFactory.class.getClassLoader());
            factory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, true);
            if (((com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl)factory).useServicesMechnism()) {
                fail("should not override in secure mode");
            }

        } catch (Exception e) {
            fail(e.getMessage());
        } finally {
            System.clearProperty(DOM_FACTORY_ID);
            System.setSecurityManager(null);
        }

        System.clearProperty(DOM_FACTORY_ID);
    }


    public void testXPath_DOM_withSM() {
        System.out.println("Evaluate DOM Source;  Security Manager is set:");
        Policy.setPolicy(_new);
        System.setSecurityManager(new SecurityManager());
        System.setProperty(DOM_FACTORY_ID, "MyDOMFactoryImpl");

        try {
            XPathFactory xPathFactory = XPathFactory.newInstance("http://java.sun.com/jaxp/xpath/dom",
                    "com.sun.org.apache.xpath.internal.jaxp.XPathFactoryImpl", null);
            xPathFactory.setFeature(ORACLE_FEATURE_SERVICE_MECHANISM, true);
            if ((boolean)xPathFactory.getFeature(ORACLE_FEATURE_SERVICE_MECHANISM)) {
                fail("should not override in secure mode");
            }

        } catch (Exception e) {
            fail(e.getMessage());
        } finally {
            System.clearProperty(DOM_FACTORY_ID);
            System.setSecurityManager(null);
        }

        System.clearProperty(DOM_FACTORY_ID);
    }
    public void testSM() {
        SecurityManager sm =System.getSecurityManager();
        if (System.getSecurityManager() != null) {
            System.out.println("Security manager not cleared: " + sm.toString());
        } else {
            System.out.println("Security manager cleared: ");
        }
    }
}
