/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2010 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package common;


import java.io.File;
import java.io.FilePermission;
import java.security.Policy;
import junit.framework.TestCase;
import junit.textui.TestRunner;



/**
 * CR6979306 Xalan, Xerces and Crimson versions in jaxp and Java SE 1.4.2, 5.0 and 6
 *
 * Correct versions:
 * JDK5: Xerces 2.6.2, Xalan 2.6
 * JDK6: Xerces 2.7.1, Xalan 2.7
 * JDK7: Xerces 2.7.1, Xalan 2.7
 *
 * @author huizhe.wang@oracle.com</a>
 */

public class Bug6979306Test extends TestCase {

    /**
     * @inheritDoc
     */
    public Bug6979306Test(String name) {
        super(name);
    }

    /**
     * @inheritDoc
     */
    public static void main(String[] args) {
        TestRunner.run(Bug6979306Test.class);
    }
    
    private Policy _orig;
    private boolean hasSM;
    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File temp = new File("/tmp/this/does/not/exist/but/that/is/ok");
        
        _orig = Policy.getPolicy();
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                new RuntimePermission("accessClassInPackage.com.sun.org.apache.*")
                );
        Policy.setPolicy(p);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void test() {
        String[] input = {};
        com.sun.org.apache.xalan.internal.xslt.EnvironmentCheck.main(input);
        com.sun.org.apache.xerces.internal.impl.Version.main(input);
        com.sun.org.apache.xalan.internal.Version._main(input);
    }

}
