/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


package bug6489890;

import javax.xml.stream.XMLEventReader;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * An XMLEventReader should start in an undefined state, and
 * move to a START_DOCUMENT state. A call to peek() should
 * return the same event as a call to nextEvent(). It follows
 * that the first call to peek() should return START_DOCUMENT
 * as explained in CR 6489890.
 *
 * @author Santiago.PericasGeertsen@sun.com
 */
public class Test extends TestCase {

    public static void main(String [] args){
        TestRunner.run(Test.class);
    }

    public void test0() {
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();

            XMLStreamReader xsr = xif.createXMLStreamReader(
                    getClass().getResource("sgml.xml").toString(),
                    getClass().getResourceAsStream("sgml.xml"));

            XMLEventReader xer = xif.createXMLEventReader(xsr);

            assertTrue(xer.peek().getEventType() == XMLEvent.START_DOCUMENT);
            assertTrue(xer.peek() == xer.nextEvent());
            xsr.close();
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }

    public void test1() {
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();

            XMLStreamReader xsr = xif.createXMLStreamReader(
                    getClass().getResource("sgml.xml").toString(),
                    getClass().getResourceAsStream("sgml.xml"));

            XMLEventReader xer = xif.createXMLEventReader(xsr);

            assertTrue(xer.nextEvent().getEventType() == XMLEvent.START_DOCUMENT);
            xsr.close();
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }

}
