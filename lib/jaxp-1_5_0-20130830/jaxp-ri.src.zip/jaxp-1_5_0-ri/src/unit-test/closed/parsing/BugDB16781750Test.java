/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package closed.parsing;

/**16781750
 * 
 * @author huizhe.wang@oracle.com
 */

import closed.bugdb14495809.Bug7192390Base;
import javax.xml.stream.XMLInputFactoryTest.*;
import common.SimplePolicy;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.Policy;
import java.util.PropertyPermission;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import util.DOMEcho;

public class BugDB16781750Test extends TestCase{
    String Temp_Result = "";
    boolean PASSED = true;
    boolean FAILED = false;

    String XMLInputFactoryClassName = "com.sun.xml.internal.stream.XMLInputFactoryImpl";
    String XMLInputFactoryID = "javax.xml.stream.XMLInputFactory";
    String MYFACTORYID = "MyInputFactory";
    ClassLoader CL = null;

    private boolean hasSM;
    private Policy _orig;

    /** Creates a new instance of Bug */
    public BugDB16781750Test(String name) {
         super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(BugDB16781750Test.class);
    }

    private BugDB16781750Test() {
        super("Bug6756677Test");
    }
    
    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }
        _orig = Policy.getPolicy();
        
        if (hasSM) {
            Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new PropertyPermission(XMLInputFactoryID, "write"),
                    new PropertyPermission(MYFACTORYID, "write"));
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void testEntityExpansion() {
        reportMemUsuage("before test:");
        long mem0 = startMemory();
        String file = this.getClass().getResource("BugDB16781750.xml").getPath();
        try {
            //System.setProperty("entityExpansionLimit","65535"); //2xx16 = 65536
            System.setProperty("entityExpansionLimit","64000"); 
            System.setProperty("elementAttributeLimit","100000"); 
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            //dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, Boolean.TRUE);
            dbf.setNamespaceAware(true);
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new FileInputStream(file));
            printDOMTree(doc);
        } catch (OutOfMemoryError oom) {
            oom.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            long memUsed1 = mem0 - endMemory();
            System.out.println("Memory used: " + memUsed1 / 1024 / 1024 + "MB");
        }
    }
    
    public void xtestParameterEntity() {
        reportMemUsuage("before test:");
        long mem0 = startMemory();
        String file = this.getClass().getResource("BugDB17025262.xml").getPath();
        try {
            //System.setProperty("entityExpansionLimit","65535"); //2xx16 = 65536
            System.setProperty("entityExpansionLimit","64000"); 
            System.setProperty("elementAttributeLimit","100000"); 
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            //dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            //dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, Boolean.TRUE);
            dbf.setNamespaceAware(true);
            DocumentBuilder db = dbf.newDocumentBuilder();

//            InputSource is = new InputSource(new FileInputStream(file));
//            is.setSystemId(file);
            Document doc = db.parse(new FileInputStream(file), file);
            printDOMTree(doc);
        } catch (OutOfMemoryError oom) {
            oom.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            long memUsed1 = mem0 - endMemory();
            System.out.println("Memory used: " + memUsed1 / 1024 / 1024 + "MB");
        }
    }

    public void printDOMTree(Document doc) {
        OutputStreamWriter outWriter = null;
        try {
            outWriter = new OutputStreamWriter(System.out, DOMEcho.outputEncoding);
            PrintWriter writer = new PrintWriter(outWriter, true);
            DOMEcho echo = new DOMEcho(writer);
            new DOMEcho(new PrintWriter(outWriter, true)).echo(doc);
        } catch (UnsupportedEncodingException ex) {        
            Logger.getLogger(BugDB16781750Test.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                outWriter.close();
            } catch (IOException ex) {
                Logger.getLogger(BugDB16781750Test.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    long startMemory() {
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        long memFree = Runtime.getRuntime().freeMemory();
        return memFree;
    }

    long endMemory() {
        long memFree = Runtime.getRuntime().freeMemory();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        return memFree;
    }

    void reportMemUsuage(String msg) {
        System.out.println(msg);
        long memTotal = Runtime.getRuntime().totalMemory();
        long memFree = Runtime.getRuntime().freeMemory();
        long maxBytes = Runtime.getRuntime().maxMemory();
        System.out.println("Memory in JVM: \nMax: " + maxBytes / 1024 / 1024 + "MB \nTotal available: " + memTotal / 1024 / 1024 + "MB \nFree: " + memFree / 1024 / 1024 + "M");
    }

}
