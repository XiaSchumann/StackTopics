
package closed.parsing;


import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.XMLFormatter;
import util.TestBase;

/**
 * JDK-4629315 Appending of XML Logfiles doesn't merge new records
 *
 * @author Joe Wang huizhe.wang@oracle.com
 */
public class LoggerTest extends TestBase {

    static String xml = "<?xml version='1.0' encoding='UTF-8' standalone='no'?>"
            + "<!DOCTYPE foo [ "
            + "<!ENTITY bar 'test' >"
            + "]>"
            + "<foo>&bar;</foo>";

    /**
     * @param name Name of test.
     */
    public LoggerTest(String name) {
        super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        LoggerTest test = new LoggerTest("OneTest");
        test.setUp();

        test.test();

        test.tearDown();
    }
    String xmlFile;
    String xmlFileId;

    protected void setUp() {
        super.setUp();
        xmlFile = parentPath + "/closed/parsing/logfile.xml";

        if (isWindows) {
            xmlFile = "/" + xmlFile;
        }

        xmlFileId = "file://" + xmlFile;
    }

    /**
     * The CatalogManager shall throw ACE if catalog class specified is in a
     * restricted package
     */
    public void test() {
        try {
            FileHandler fh = new FileHandler(xmlFile,true);
            XMLFormatter xmlf = new XMLFormatter();
            fh.setFormatter(xmlf);
            Logger logger = Logger.getLogger("test.test1.test2");
            logger.addHandler(fh);
            logger.setLevel(Level.ALL);
            logger.warning("that is a test log message -- Level WARNING");
            logger.info("that is a second test log message -- Level WARNING");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}
