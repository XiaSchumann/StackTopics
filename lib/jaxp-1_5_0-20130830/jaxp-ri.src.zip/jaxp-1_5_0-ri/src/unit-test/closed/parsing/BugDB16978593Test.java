/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2012 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.parsing;

import java.io.*;
import javax.xml.parsers.*;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Bug 16978593 - DOS ATTACK TRIGGERED BY LONG XML NAMES IN XML DECLARATION
 *
 * @author Joe Wang huizhe.wang@oracle.com
 */
public class BugDB16978593Test extends TestCase {

    /**
     * @param name Name of test.
     */
    public BugDB16978593Test(String name) {
        super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(BugDB16978593Test.class);
        System.exit(0);
    }
    String[] xmlDecls = {"<?xml versions=\"1.0\" encoding=\"UTF8\"standalone=\"yes\" ?>",
        "<?xml version=\"1.0\" eencoding=\"UTF8\"?>",
        "<?xmlversion=\"1.0\" encoding=\"UTF8\"?>",
        "<?xml version=\"1.0\" encoding=\"UTF8\"standalone=\"yes\" ?>",
        "<?xml version=\"1.0\" encoding=\"UTF8\" standallone=\"yes\" ?>"};

    /**
     * Verifies that only legal names are accepted
     */
    public void testParsingLongName() {
        try {
            InputStream is = this.getClass().getResourceAsStream("BugDB16978593.xml");
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            //dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            dbf.setNamespaceAware(true);
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(is);
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg.indexOf("The ' = ' character must follow \"version\" in the XML declaration") > -1) {
                //expected error
            } else {
                fail(msg);
            }
        } finally {
        }
    }

    /**
     * verify that the patch does not affect how the parser was handling
     * the parsing of XML Declaration
     */
    public void testParsingXMLDecl() {
        for (String xml : xmlDecls) {
            parse(xml);
        }
    }

    public void parse(String xml) {
        try {
            StringReader in = new StringReader(xml);
            InputSource source = new InputSource(in);

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            //dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            dbf.setNamespaceAware(true);
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(source);
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg.indexOf("The ' = ' character must follow \"version\" in the XML declaration") > -1) {            
                /**
                 * previous error msg: The version is required in the XML declaration
                 * Now: The ' = ' character must follow "version" in the XML declaration
                 */
                System.out.println("typo: verions ");
            } else if (msg.indexOf("A pseudo attribute name is expected") > -1) {
                /**
                 * previous error msg: The encoding declaration is required in the text declaration
                 * Now: A pseudo attribute name is expected
                 */
                System.out.println("typo: eencoding | typo: standallone"); 
            } else if (msg.indexOf("White space is required between the processing instruction target and data") > -1) {
                System.out.println("typo: xmlversion");
            } else if (msg.indexOf("White space is required before the encoding pseudo attribute in the XML declaration") > -1) {
                System.out.println("typo: UTF8\"standalone");  
            } else if (msg.indexOf("The standalone name in XML declaration may be misspelled") > -1) {
                /**
                 * previous error msg: The standalone name in XML declaration may be misspelled
                 * Now: A pseudo attribute name is expected
                 */
                System.out.println("typo: standallone"); 
                 /**
                 * note there's a bug in the error report where it was reporting encoding error
                 * while parsing standalone
                 */
            } else {
                fail(msg);
            }
        } 
    }

}
