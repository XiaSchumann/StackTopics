/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2012 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.parsing;

import com.sun.org.apache.xml.internal.resolver.Catalog;
import com.sun.org.apache.xml.internal.resolver.CatalogManager;
import com.sun.org.apache.xml.internal.resolver.readers.DOMCatalogReader;
import com.sun.org.apache.xml.internal.resolver.readers.SAXCatalogReader;
import com.sun.org.apache.xml.internal.resolver.tools.CatalogResolver;
import common.SimplePolicy;
import java.io.*;
import java.security.Policy;
import javax.xml.parsers.*;
import org.xml.sax.XMLReader;
import util.TestBase;

/**
 * Bug 16978593 - DOS ATTACK TRIGGERED BY LONG XML NAMES IN XML DECLARATION
 *
 * @author Joe Wang huizhe.wang@oracle.com
 */
public class JDK8022937Test extends TestBase {

    private static String CATALOG_CLASSNAME = "xml.catalog.className";
    private static String CATALOG_FILE = "xml.catalog.files";
    static String xml = "<?xml version='1.0' encoding='UTF-8' standalone='no'?>"
            + "<!DOCTYPE foo [ "
            + "<!ENTITY bar 'test' >"
            + "]>"
            + "<foo>&bar;</foo>";

    /**
     * @param name Name of test.
     */
    public JDK8022937Test(String name) {
        super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        JDK8022937Test test = new JDK8022937Test("OneTest");
        test.setUp();

        test.testResolverSM();
        test.testResolver();
        test.testSAXCatalogReaderSM();
        test.testSAXCatalogReader();
        test.testDOMCatalogReaderSM();
        test.testDOMCatalogReader();
        test.testUsingResolver();
        test.tearDown();
    }
    String xmlFile, catalogFile;
    String xmlFileId, catalogFileId;

    protected void setUp() {
        super.setUp();
        xmlFile = parentPath + "/closed/parsing/JDK8022937.xml";
        catalogFile = parentPath + "/closed/parsing/JDK8022937catalog.xml";

        if (isWindows) {
            xmlFile = "/" + xmlFile;
            catalogFile = "/" + catalogFile;
        }

        xmlFileId = "file://" + xmlFile;
        catalogFileId = "file://" + catalogFile;
    }

    /**
     * The CatalogManager shall throw ACE if catalog class specified is in a
     * restricted package
     */
    public void testResolverSM() {
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"));
        Policy.setPolicy(p);
        System.setSecurityManager(new SecurityManager());
        try {
            CatalogManager cm = new CatalogManager();
            cm.setCatalogClassName("com.sun.org.apache.xerces.internal.utils.ObjectFactory");
            cm.setCatalogClassName("com.sun.org.apache.xerces.internal.utils.ObjectFactory");
            Object obj = cm.getPrivateCatalog();
            //the impl catches ACE and return null
            if (obj == null) {
                success("testResolverSM passed: CatalogManager catches ACE and returns null");
            } else {
                fail("CatalogManager falls back to default after CCE, which indicates it accessed class ObjectFactory");
            }
        } catch (Exception e) {
            fail(e.getMessage());
        } finally {
            System.setSecurityManager(null);
        }
    }

    /**
     * Without a security manager, the CatalogManager would work as usual
     * CatalogManager catches CCE and falls back to default implementation
     */
    public void testResolver() {
        try {
            CatalogManager cm = new CatalogManager();
            cm.setCatalogClassName("com.sun.org.apache.xerces.internal.utils.ObjectFactory");
            Object obj = cm.getPrivateCatalog();
            if (obj == null) {
                fail("CatalogManager shall return default implemenation");
            }
            if (obj.getClass().isAssignableFrom(Catalog.class)) {
                success("testResolver passed: work as usual");
            }
        } catch (Exception e) {
            String msg = e.getMessage();
            fail(msg);
        }
    }

    /**
     * Reflection in DOMCatalogReader and SAXCatalogReader is unnecessary since
     * the default implementation does not take user-specified parser
     *
     * Since SAXCatalogReader and DOMCatalogReader are public, it's possible to
     * instantiate them directly
     */
    public void testSAXCatalogReaderSM() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        PrintStream original = System.out;
        System.setOut(ps);
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                new RuntimePermission("setIO"));
        Policy.setPolicy(p);
        System.setSecurityManager(new SecurityManager());
        try {
            CatalogManager.getStaticManager().debug.setDebug(2);
            SAXCatalogReader cr = new SAXCatalogReader();
            cr.setCatalogParser(null, testName, "com.sun.org.apache.xerces.internal.utils.ObjectFactory");
            cr.startElement(null, testName, testName, null);
            String content = baos.toString();
            System.setOut(original);
            fail("testSAXCatalogReaderSM failed: should throw ACE");

        } catch (Exception e) {
            System.setOut(original);
            String msg = e.getMessage();
            if (msg.indexOf("accessClassInPackage") > -1) {
                success("testSAXCatalogReaderSM passed: no permission to restricted package");
            } else {
                fail(msg);
            }
        } finally {
            System.setSecurityManager(null);
        }
    }

    /**
     * Catalog reader catches CCE, and print out debug information.
     */
    public void testSAXCatalogReader() {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PrintStream ps = new PrintStream(baos);
            PrintStream original = System.out;
            System.setOut(ps);
        try {

            CatalogManager.getStaticManager().debug.setDebug(2);
            SAXCatalogReader cr = new SAXCatalogReader();
            cr.setCatalogParser(null, testName, "com.sun.org.apache.xerces.internal.utils.ObjectFactory");
            cr.startElement(null, testName, testName, null);
            String content = baos.toString();
            System.setOut(original);
            if (content.indexOf("java.lang.ClassCastException") > -1) {
                success("testSAXCatalogReader passed: CCE expected");
            } else {
                fail("testSAXCatalogReader failed: " + content);
            }
        } catch (Exception e) {
            System.setOut(original);

            fail(e.getMessage());

        } finally {
            System.clearProperty(CATALOG_FILE);
        }
    }

    /**
     * Since SAXCatalogReader and DOMCatalogReader are public, it's possible to
     * instantiate them directly
     */
    public void testDOMCatalogReaderSM() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        PrintStream original = System.out;
        System.setOut(ps);
        InputStream is = null;
        try {
            is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
            //is = new FileInputStream(new StringReader(xml));
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                new RuntimePermission("setIO"));
        Policy.setPolicy(p);
        System.setSecurityManager(new SecurityManager());
        try {
            CatalogManager.getStaticManager().debug.setDebug(2);
            DOMCatalogReader cr = new DOMCatalogReader();
            cr.setCatalogParser(null, "foo", "com.sun.org.apache.xerces.internal.utils.ObjectFactory");
            cr.readCatalog(null, is);

            String content = baos.toString();
            System.setOut(original);
            fail("testDOMCatalogReaderSM failed: should throw ACE");
        } catch (Exception e) {
            System.setOut(original);
            String msg = e.getMessage();
            if (msg.indexOf("accessClassInPackage") > -1) {
                success("testSAXCatalogReaderSM passed: no permission to restricted package");
            } else {
                fail(msg);
            }
        } finally {
            System.setSecurityManager(null);
        }
    }

    /**
     * Catalog reader catches CCE, and print out debug information.
     */
    public void testDOMCatalogReader() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        PrintStream original = System.out;
        System.setOut(ps);
        InputStream is = null;
        try {
            is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
            //is = new FileInputStream(new StringReader(xml));
        } catch (Exception ex) {
            fail(ex.getMessage());
        }
        try {
            CatalogResolver resolver = new CatalogResolver();
            Catalog catalog = resolver.getCatalog();
            catalog.getCatalogManager().debug.setDebug(2);
            //catalog.getCatalog().getCatalogManager().debug.setDebug(2);
            //CatalogManager.getStaticManager().debug.setDebug(2);
            DOMCatalogReader cr = new DOMCatalogReader();
            cr.setCatalogParser(null, "foo", "com.sun.org.apache.xerces.internal.utils.ObjectFactory");
            cr.readCatalog(catalog, is);
            String content = baos.toString();
            System.setOut(original);
            if (content.indexOf("java.lang.ClassCastException") > -1) {
                success("testSAXCatalogReader passed: CCE expected");
            } else {
                fail("testSAXCatalogReader failed: " + content);
            }
        } catch (Exception e) {
            /**
             * DOMCatalogReader catches CCE, and throws a new exception that
             * swallows the cause. So check the debug information instead
             */
            String content = baos.toString();
            System.setOut(original);
            System.out.println(content);
            if (content.indexOf("Cannot cast XML Catalog Parser class") > -1) {
                success("testSAXCatalogReader passed: CCE expected");
            } else {
                fail("testSAXCatalogReader failed: " + content);
            }
        }
    }

    /**
     * "public" catalog did not work, since the impl does not check "public"
     * (13) in the impl. System(14) is supported.
     */
    public void testUsingResolver() {
        System.setProperty(CATALOG_FILE, catalogFile);
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setValidating(true);
            SAXParser parser = factory.newSAXParser();
            XMLReader reader = parser.getXMLReader();
            CatalogManager.getStaticManager().setUseStaticCatalog(false);
            CatalogResolver resolver = new CatalogResolver();
            reader.setEntityResolver(resolver);
            reader.parse(xmlFile);
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg.indexOf("xhtml-lat1.ent") > -1) {
                //expected error since xhtml-lat1.ent is not included
                success("testUsingResolver passed: expected: xhtml-lat1.ent is not included");
            } else {
                fail(msg);
            }
        } finally {
            System.clearProperty(CATALOG_FILE);
        }
    }

//------------------he following methods are not completed-----------------------------------------------
    /**
     * the following methods are not completed
     */
    public void testSAXResolver1() {
        //System.setProperty(CATALOG_CLASSNAME, "com.sun.org.apache.xml.internal.resolver.readers.XCatalogReader");
        System.setProperty(CATALOG_CLASSNAME, "com.sun.org.apache.xml.internal.resolver.Resolver");
        System.setProperty(CATALOG_FILE, catalogFile);
        try {
            CatalogResolver cr = new CatalogResolver();

            SAXParserFactory factory = SAXParserFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setValidating(true);
            SAXParser parser = factory.newSAXParser();
            XMLReader reader = parser.getXMLReader();
            reader.setEntityResolver(new CatalogResolver());
            reader.parse(xmlFile);
        } catch (Exception e) {
            e.printStackTrace();
            String msg = e.getMessage();
            if (msg.indexOf("The ' = ' character must follow \"version\" in the XML declaration") > -1) {
                //expected error
            } else {
                fail(msg);
            }
        } finally {
            System.clearProperty(CATALOG_FILE);
        }
    }

    /**
     * There isn't a way to use DOMCatalogParser, or it's not implemented
     */
    public void testDOMResolver() {

        System.setProperty(CATALOG_CLASSNAME, "com.sun.org.apache.xml.internal.resolver.readers.XCatalogReader");
        System.setProperty(CATALOG_FILE, catalogFile);
        try {
            CatalogResolver cr = new CatalogResolver();

        } catch (Exception e) {
            e.printStackTrace();
            String msg = e.getMessage();
            if (msg.indexOf("The ' = ' character must follow \"version\" in the XML declaration") > -1) {
                //expected error
            } else {
                fail(msg);
            }
        } finally {
            System.clearProperty(CATALOG_FILE);
        }
    }
}
