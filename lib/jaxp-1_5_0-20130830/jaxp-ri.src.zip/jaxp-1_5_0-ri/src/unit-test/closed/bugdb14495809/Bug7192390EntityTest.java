/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.bugdb14495809;

import java.io.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * accessExternalDTD: jaxp 1.5 property. Allow specifying the method of
 * accessing external DTD Value: local, remote; default is local Error message:
 * External DTD: [local or remote] access not allowed.
 *
 * Relationship with existing features:
 *
 * 1. FEATURE FOR SECURE PROCESSING If this feature is on, accessExternalDTD is
 * default to local only; However, it can overwrite the default if it is set
 * after the secure feature.
 *
 * 2. disallow-doctype-decl for SAX and DOM and SUPPORT_DTD for StAX If these
 * features are set, the accessExternalDTD feature has no effect
 *
 * 3. load-external-dtd if this feature is turned off for non-validating
 * parsing, the accessExternalDTD feature has no effect.
 *
 *
 * This change is required by CR 7192390.
 *
 * @author huizhe.wang@oracle.com
 */
public class Bug7192390EntityTest extends Bug7192390Base {

    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390EntityTest(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bug7192390EntityTest.class);
    }

/////////////////////////////////////////////////
///////////External Entity Reference (EER)
/////////////////////////////////////////////////
    /**
     * For JDK7 and 8, there's no restriction by default
     */
    public void testEER_default() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
            checkDefaultBehavior(TEST_EXTERNALDTD, "testEER_default", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }

        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
            checkDefaultBehavior(TEST_EXTERNALDTD, "testEER_default", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }

    /**
     * System Property javax.xml.accessExternalDTD may be used to override the
     * default
     */
    public void testEER_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }
    
    /**
     * JAXP Property always takes preference
     */
    public void testEER_JAXPProperty() {
        SAXParser parser = null;
        try {
            parser = getSAXParser(false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            
            //file access is allowed by the property
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        }
        try {
            //SAXParser is reset to the same state as when it was created with SAXParserFactory.newSAXParser().
            parser.reset();
            
            //property such as ACCESS_EXTERNAL_DTD would need to be set explicitly after reset
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            //http access should be denied
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testEER_JAXPProperty", PROTOCOL_HTTP);
        } catch (Exception e) {
            denyExternalAccess(e, PROTOCOL_HTTP);
        }
    }    
   
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testSAXEER_Secure() {
        try {
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
            checkFSPBehavior(TEST_EXTERNALDTD, "testSAXEER_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testSAXEER_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }
    
    /**
     * ACCESS_EXTERNAL_DTD can be used to set current allowance
     */
    public void testSAXEER_SecureOR() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            //secure processing denies external access
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            //reset ACCESS_EXTERNAL_DTD to allow access
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * if EXTERNAL_GENERAL_ENTITIES_FEATURE is set to false, the access
     * restriction should have no effect
     */
    public void testEER_EGEF() {
        SAXParser parser = null;
        try {
            parser = getSAXParser(false, false, false, NOTINCGENENTITY_TRUE, false);
            //file access is allowed
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testEER_EGEF", e, "if EXTERNAL_GENERAL_ENTITIES_FEATURE is set to false, the access restriction should have no effect", null);
        }
        try {
            //SAXParser is reset to the same state as when it was created with SAXParserFactory.newSAXParser().
            parser.reset();            
            //properties such as ACCESS_EXTERNAL_DTD need to be set explicitly after reset
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            //http not allowed by access property, however it has no effect since external entities are not resolved
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
            success("testEER_EGEF passed");
        } catch (Exception e) {
            ignoreAccessRestriction("testEER_EGEF", e, "if EXTERNAL_GENERAL_ENTITIES_FEATURE is set to false, the access restriction should have no effect", null);
        }
    }
    /**
     * if disallow DTD is specified, protocol restriction has no effect
     */
    public void testSAXEER_disallowDTD() {

        try {
            SAXParser parser = getSAXParser(false, DISALLOWDTD_TRUE, false);
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testSAXEER_disallowDTD", PROTOCOL_HTTP);
        } catch (Exception e) {
            disallowDTD(e);
        }
        try {
            SAXParser parser = getSAXParser(false, DISALLOWDTD_TRUE, false);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testSAXEER_disallowDTD", PROTOCOL_FILE);
        } catch (Exception e) {
            disallowDTD(e);
        }
    }

    /**
     * if http://apache.org/xml/features/nonvalidating/load-external-dtd is
     * false, the access restriction should have no effect
     */
    public void testSAXDefault_notLoadDTD() {

        try {
            SAXParser parser = getSAXParser(false, false, NOTLOADEXTERNALDTD_TRUE);
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testSAXDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            SAXParser parser = getSAXParser(false, false, NOTLOADEXTERNALDTD_TRUE);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testSAXDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    public void testSAXAccess_notLoadDTD() {

        try {
            SAXParser parser = getSAXParser(false, false, NOTLOADEXTERNALDTD_TRUE);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "x");
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testSAXAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            SAXParser parser = getSAXParser(false, false, NOTLOADEXTERNALDTD_TRUE);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "x");
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testSAXAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    /**
     * DOM -- similar tests as SAX
     */
    public void testDOMDefault() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_http)));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDOMDefault", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_file)));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDOMDefault", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    public void testDOMSP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_file)));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testDOMJAXPProperty() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "file, http");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_file)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testDOM_Secure() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_http)));
            checkFSPBehavior(TEST_EXTERNALDTD, "testDOM_Secure", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_file)));
            checkFSPBehavior(TEST_EXTERNALDTD, "testDOM_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    
    /**
     * System property will override that set by FSP
     */
    public void testDOM_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_file)));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * ACCESS_EXTERNAL_DTD can be used to set current allowance
     */
    public void testDOM_SecureOR() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "file, http");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_file)));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testDOMDefault_notLoadDTD() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_http)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_file)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    public void testDOMAccess_notLoadDTD() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "x");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_http)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_file)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    /**
     * StAX
     */
    public void testStAXDefault() {
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_http));
            readDTD(xsr);
            checkDefaultBehavior(TEST_EXTERNALDTD, "testStAXDefault", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_file));
            readDTD(xsr);
            checkDefaultBehavior(TEST_EXTERNALDTD, "testStAXDefault", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    public void testStAXSP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_http));
            readDTD(xsr);
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_file));
            readDTD(xsr);
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testStAXJAXPProperties() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "");

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_http));
            readDTD(xsr);
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_file));
            readDTD(xsr);
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * Refer to CR 6542088 for the behavior of SupportDTD and
     * IS_REPLACING_ENTITY_REFERENCES when SupportDTD=false and
     * IS_REPLACING_ENTITY_REFERENCES=true, a fatal error will be thrown, no
     * external entity will be loaded
     *
     * **Access Restriction therefore has not effect on External General
     * Entity**
     */
    public void testStAXDefault_notLoadDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_http));
            readDTD(xsr);
        } catch (Exception e) {
            ignoreAccessRestriction("testStAXDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", "item");
        }
    }

    public void testStAXAccess_notLoadDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
            xif.setProperty(ACCESS_EXTERNAL_DTD, "x");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_http));
            readDTD(xsr);
        } catch (Exception e) {
            ignoreAccessRestriction("testStAXDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", "item");
        }
    }

    /**
     * External General Entity will not be loaded if
     * IS_SUPPORTING_EXTERNAL_ENTITIES = false
     *
     * **Access Restriction therefore is not necessary**
     */
    public void testStAXDefault_notSupportEE() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);

        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_http));
            readDTD(xsr);
        } catch (Exception e) {
            ignoreAccessRestriction("testStAXDefault_notSupportEE", e, "IS_SUPPORTING_EXTERNAL_ENTITIES=false, access restriction should have no effect.", null);
        }
    }

    /**
     * External General Entity will still be loaded if
     * IS_REPLACING_ENTITY_REFERENCES = false
     *
     * **Access Restriction therefore is necessary**
     */
    public void testStAXDefault_notReplaceEntity() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_http));
            readDTD(xsr);
            checkDefaultBehavior(TEST_EXTERNALDTD, "testStAXDefault_notReplaceEntity", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }

    /**
     * When both SupportDTD and IS_REPLACING_ENTITY_REFERENCES are false, entity
     * is skipped.
     *
     * **Access Restriction has no effect**
     */
    public void testStAXDefault_notSupportDTDNorReplaceEntity() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
            xif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_http));
            readDTD(xsr);
            //success("testStAXDefault_notSupportDTDNorReplaceEntity passed");
        } catch (Exception e) {
            ignoreAccessRestriction("testStAXDefault_notSupportDTDNorReplaceEntity", e, "both SupportDTD and IS_REPLACING_ENTITY_REFERENCES are false, access restriction should have no effect.", null);
        }
    }

    SAXParser getSAXParser(boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD, boolean notIncGeneralEntity, boolean notIncParameterEntity)
            throws ParserConfigurationException, SAXException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        if (secure) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        if (disallowDTD) {
            spf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, disallowDTD);
        }
        if (notLoadExternalDTD) {
            spf.setValidating(false);
            spf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
        }
        if (notIncGeneralEntity) {
            spf.setFeature(EXTERNAL_GENERAL_ENTITIES_FEATURE, false);
        }
        if (notIncParameterEntity) {
            spf.setFeature(EXTERNAL_PARAMETER_ENTITIES_FEATURE, false);
        }
        SAXParser parser = spf.newSAXParser();

        return parser;
    }

/////////////////////////////////////////////////
///////////Using Entity Resolver
/////////////////////////////////////////////////
    /**
     * The resolver handles replace* keyword; But the extra http link will still
     * be denied since the resolver returns null when the http link is
     * encountered
     */
    public void testEER_wEntityResolver_default() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            XMLReader reader = parser.getXMLReader();
            reader.setEntityResolver(new myEntityResolver());
            reader.parse(new InputSource(new StringReader(_external_entity_resolver)));
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }

    /**
     * The access restriction should be ignored if the inputsource is created by
     * a resolver. In this case, the local path would have been restricted if
     * it's not created by the resolver
     */
    public void testEER_wEntityResolver_JAXPProperty() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            //grant http access, the file access is taken care of by the resolver 
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
            XMLReader reader = parser.getXMLReader();
            reader.setEntityResolver(new myEntityResolver());
            reader.parse(new InputSource(new StringReader(_external_entity_resolver)));
        } catch (Exception e) {
            ignoreAccessRestriction("testEER_wEntityResolver_JAXPProperty", e, "should not throw error since http access is allowed, and file entity resolved by the resolver.", null);
        }
    }

    /**
     * denyExternalAccess(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
     */
    public void testDOM_wEntityResolver_Default() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            docBuilder = dbf.newDocumentBuilder();
            docBuilder.setEntityResolver(new myEntityResolver());
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_resolver)));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDOM_wEntityResolver_Default", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }

    /**
     * The access restriction should be ignored if the inputsource is created by
     * a resolver. In this case, the local path would have been restricted if
     * it's not created by the resolver
     */
    public void testDOM_wEntityResolver_JAXPProperty() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            //grant http access, the file access is taken care of by the resolver
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
            docBuilder = dbf.newDocumentBuilder();
            docBuilder.setEntityResolver(new myEntityResolver());
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_resolver)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOM_wEntityResolver_JAXPProperty", e, "should not throw error since http access is allowed, and file entity resolved by the resolver.", null);
        }
    }

    public void testStAX_wEntityResolver_Default() {
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setXMLResolver(new MyStaxResolver());
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_resolver_stax));
            readDTD(xsr);
            checkDefaultBehavior(TEST_EXTERNALDTD, "testStAX_wEntityResolver_Default", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }

    public void testStAX_wEntityResolver_JAXPProperty() {
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
            xif.setXMLResolver(new MyStaxResolver());
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity_resolver_stax));
            readDTD(xsr);
        } catch (Exception e) {
            ignoreAccessRestriction("testStAX_wEntityResolver_JAXPProperty", e, "should not throw error since http access is allowed, and file entity resolved by the resolver.", null);
        }
    }
}
