package closed.bugdb14495809;

import java.io.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import junit.textui.TestRunner;
import org.xml.sax.Attributes;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author huizhe.wang@oracle.com
 */
public class Bug7192390Test_XInclude extends Bug7192390Base {

    static final boolean XINCLUDE_AWARE = true;
    final private String Passed = "ok:   %s";
    final private String Failed = "fail: %s";
    //for XInclude tests
    String _xi_file = getClass().getResource("Bug7192390_XI.xml").getPath();
    String _xi_rootfile = getClass().getResource("XI_roottest.xml").getPath();
    boolean xIncludeAware = false;

    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390Test_XInclude(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bug7192390Test_XInclude.class);
    }

/////////////////////////////////////////////////
///////////XInclude
/////////////////////////////////////////////////
    /**
     * JAXP setXIncludeAware feature is off by default, no need to add new
     * property for XInclude in Xerces
     */
    public void xtestXInclude_default() {
        xIncludeAware = false;
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(true);
            SAXParser parser = spf.newSAXParser();
            parser.parse(new InputSource(_xi_file), new MyHandler1());

        } catch (Exception e) {
            e.printStackTrace();
        }
        if (xIncludeAware) {
            fail("XIncludeAware should be false by default");
        }
    }

    public void xtestXInclude_aware() {
        xIncludeAware = false;
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(true);
            spf.setXIncludeAware(true);
            spf.setFeature("http://apache.org/xml/features/xinclude", true);
            SAXParser parser = spf.newSAXParser();
            parser.parse(new InputSource(_xi_file), new MyHandler1());

        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!xIncludeAware) {
            fail("XIncludeAware is true, element1 should be included");
        }
    }

    /////////////////////////////////////////////////
    ///////////XInclude aware
    /////////////////////////////////////////////////   
    public void testSAX_XInclude_aware_default() {
        try {
            SAXParser parser = getSAXParser(false);
            parser.parse(_xi_rootfile, new DefaultHandler());

            System.out.println(String.format(Failed, "(file) access shall be denied"));
        } catch (Exception e) {
            //e.printStackTrace();
            denyExternalAccess(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    /*
     * test: XInclude aware SAX, allow access via system property
     */

    public void xtestSAX_XInclude_aware_sp() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file");
        try {
            SAXParser parser = getSAXParser(false);
            parser.parse(_xi_rootfile, new DefaultHandler());
            System.out.println(String.format(Passed, SP_ACCESS_EXTERNAL_DTD + " (file)"));

        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }
    /*
     * test: XInclude aware SAX, allow access via JAXP property
     */

    public void xtestSAX_XInclude_aware_jaxp() {
        try {
            SAXParser parser = getSAXParser(false);

            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            parser.parse(_xi_rootfile, new DefaultHandler());

            System.out.println(String.format(Passed, ACCESS_EXTERNAL_DTD + " (file)"));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }
    /*
     * test: XInclude aware SAX, access is denied when Secure Processing is
     * set explicitly
     */

    public void xtestSAX_XInclude_aware_secure() {
        try {
            SAXParser parser = getSAXParser(true);

            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            parser.parse(_xi_rootfile, new DefaultHandler());

            System.out.println(String.format(Passed, ACCESS_EXTERNAL_DTD + " (file)"));
        } catch (Exception e) {
            denyExternalAccess(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    /**
     * by default, forbid any connection
     */
    public void xtestDOM_XInclude_aware_default() {
        try {
            DocumentBuilderFactory factory = getDocumentBuilderFactory();
            DocumentBuilder db = factory.newDocumentBuilder();
            db.parse(_xi_rootfile);
        } catch (Exception e) {
            denyExternalAccess(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    /**
     * test: XInclude aware DOM, allow access via system property
     */
    public void xtestDOM_XInclude_aware_sp() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file");
        try {
            DocumentBuilderFactory factory = getDocumentBuilderFactory();
            DocumentBuilder db = factory.newDocumentBuilder();
            db.parse(_xi_rootfile);
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * test: XInclude aware DOM, allow access via jaxp property
     */
    public void xtestDOM_XInclude_aware_jaxp() {
        try {
            DocumentBuilderFactory factory = getDocumentBuilderFactory();
            factory.setAttribute(ACCESS_EXTERNAL_DTD, "file");

            DocumentBuilder db = factory.newDocumentBuilder();
            db.parse(_xi_rootfile);
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    /**
     * test: XInclude aware DOM, access is denied when Secure Processing is set
     * explicitly
     */
    public void xtestDOM_XInclude_aware_secure() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file");
        try {
            DocumentBuilderFactory factory = getDocumentBuilderFactory();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            DocumentBuilder db = factory.newDocumentBuilder();
            db.parse(_xi_rootfile);
        } catch (Exception e) {
            denyExternalAccess(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /*
     * test: XInclude aware SAX, allow access via JAXP property
     */
    public void xxtestSAX_XInclude_aware_jaxp() {
        SAX_XInclude(_xi_rootfile, false);
    }

    /*
     * test: XInclude aware SAX, allow access via system property
     */
    public void xxtestSAX_XInclude_aware_sp() {
        SAX_XInclude(_xi_rootfile, true);
    }

    /*
     * test: XInclude aware DOM, allow access via JAXP property
     */
    public void xxtestDOM_XInclude_aware_jaxp() {
        DOM_XInclude(_xi_rootfile, false, false);
    }
    /*
     * test: XInclude aware DOM, allow access via system property
     */

    public void xxtestDOM_XInclude_aware_sp() {
        DOM_XInclude(_xi_rootfile, false, true);
    }

    void DOM_XInclude(String xmlDoc, boolean isDefault, boolean viaSysProperty) {
        try {
            DocumentBuilderFactory factory = getDocumentBuilderFactory();
            if (isDefault) {
                DocumentBuilder db = factory.newDocumentBuilder();
                db.parse(xmlDoc);
            } else {
                if (viaSysProperty) {
                    System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file");
                    System.out.println(String.format(Passed, SP_ACCESS_EXTERNAL_DTD + " (file)"));
                } else {
                    factory.setAttribute(ACCESS_EXTERNAL_DTD, "file");
                    DocumentBuilder db = factory.newDocumentBuilder();
                    db.parse(xmlDoc);
                    System.out.println(String.format(Passed, ACCESS_EXTERNAL_DTD + " (file)"));
                }
            }
        } catch (Exception e) {
            System.out.println(String.format(Failed, e.getMessage()));
            allowExternalAccess(e);

        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    void SAX_XInclude(String xmlDoc, boolean viaSysProperty) {
        try {
            SAXParser parser = getSAXParser(false);
            if (viaSysProperty) {

                System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file");
                parser.parse(xmlDoc, new DefaultHandler());

                System.out.println(String.format(Passed, SP_ACCESS_EXTERNAL_DTD + " (file)"));
            } else {

                parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
                parser.parse(xmlDoc, new DefaultHandler());

                System.out.println(String.format(Passed, ACCESS_EXTERNAL_DTD + " (file)"));
            }
        } catch (Exception e) {
            System.out.println(String.format(Failed, e.getMessage()));
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    DocumentBuilderFactory getDocumentBuilderFactory() {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        // We cannot use validating parser since many XML documents do not have associated DTD.
        factory.setValidating(false);
        factory.setNamespaceAware(true);
        factory.setXIncludeAware(true);
        return factory;

    }

    /**
     * Get an XInclude-aware SAX Parser
     *
     * @param secure -- secure processing
     * @return a SAX Parser
     * @throws ParserConfigurationException
     * @throws SAXException
     */
    SAXParser getSAXParser(boolean secure) throws ParserConfigurationException, SAXException {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setXIncludeAware(true);
        if (secure) {
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        factory.setFeature("http://apache.org/xml/features/xinclude", true);

        SAXParser parser = factory.newSAXParser();
        return parser;
    }

    public class MyHandler1 extends DefaultHandler2 implements ErrorHandler {

        StringBuffer currentValue = new StringBuffer();

        public void startDocument() throws SAXException {
        }

        public void endDocument() throws SAXException {
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            currentValue.delete(0, currentValue.length());
            try {
                System.out.println("Element: " + uri + ":" + localName + " " + qName);
                if (localName.equalsIgnoreCase("element1")) {
                    xIncludeAware = true;
                }

            } catch (Exception e) {
                throw new SAXException(e);
            }

        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
            System.out.println("Text: \n" + currentValue.toString() + "\n");
            System.out.println("End Element: " + uri + ":" + localName + " " + qName);
        }

        public void characters(char ch[], int start, int length) throws SAXException {
            currentValue.append(ch, start, length);
        }

        public void internalEntityDecl(String name, String value) throws SAXException {
            super.internalEntityDecl(name, value);
            System.out.println("internalEntityDecl() is invoked for entity : " + name);
        }

        public void externalEntityDecl(String name, String publicId, String systemId) throws SAXException {
            super.externalEntityDecl(name, publicId, systemId);
            System.out.println("externalEntityDecl() is invoked for entity : " + name);
        }

        public void startEntity(String name) throws SAXException {
            super.startEntity(name);
//		System.out.println("startEntity() is invoked for entity : " + name) ;
        }

        public void endEntity(String name) throws SAXException {
            super.endEntity(name);
//		System.out.println("endEntity() is invoked for entity : " + name) ;
        }

        public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
            System.out.println("resolveEntity(publicId, systemId) is invoked");
            return super.resolveEntity(publicId, systemId);
        }

        public InputSource resolveEntity(String name, String publicId, String baseURI, String systemId) throws SAXException, IOException {
            System.out.println("resolveEntity(name, publicId, baseURI, systemId) is invoked");
            return super.resolveEntity(name, publicId, baseURI, systemId);
        }

        public InputSource getExternalSubset(String name, String baseURI) throws SAXException, IOException {
            System.out.println("getExternalSubset() is invoked");
            return super.getExternalSubset(name, baseURI);
        }
    }
}
