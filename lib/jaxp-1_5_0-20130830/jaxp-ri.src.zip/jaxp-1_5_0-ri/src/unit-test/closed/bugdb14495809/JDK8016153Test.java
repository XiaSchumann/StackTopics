package closed.bugdb14495809;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.xml.sax.InputSource;

/**
 * run this test with Xerces jar on the bootclasspath
 * @author huizhe.wang@oracle.com
 */
public class JDK8016153Test extends TestCase {

    /**
     * Creates a new instance of StreamReader
     */
    public JDK8016153Test(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(JDK8016153Test.class);
    }


//####current test
    /**
     * all access is allowed by default
     */
    public void testStylesheetPI_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
            System.out.println("all access is allowed by default");
        } catch (Exception e) {
            e.printStackTrace();
            String err = e.getMessage();
            //fail(e.toString());
        }
    }

}
