
package closed.bugdb14495809;

import java.io.*;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import junit.textui.TestRunner;
import org.xml.sax.SAXException;

/**
 * @author huizhe.wang@oracle.com
 */
public class Bug7192390_XSDInclude_Test extends Bug7192390Base {

    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390_XSDInclude_Test(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bug7192390_XSDInclude_Test.class);
    }

/////////////////////////////////////////////////
///////////XSD Include
/////////////////////////////////////////////////
    public void testSchemaInclude_default() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_XSDInclude_Test.class.getResource("XSDInclude_company.xsd").getFile())));
            reportFailToDenyAccess(TEST_EXTERNALSCHEMA, "testSchemaInclude_default", PROTOCOL_FILE);
        } catch (SAXException e) {
            denyExternalAccess(TEST_EXTERNALSCHEMA, e, "file");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaInclude_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_XSDInclude_Test.class.getResource("XSDInclude_company.xsd").getFile())));
        } catch (SAXException e) {
            allowExternalAccess(e);
        }
        System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
    }
            
    /**
     * jaxp property takes preference
     */
    public void testSchemaInclude_JAXPProperty() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file");
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_XSDInclude_Test.class.getResource("XSDInclude_company.xsd").getFile())));
        } catch (SAXException e) {
            allowExternalAccess(e);
        }
    }
    
    /**
     * jaxp property takes preference, this is also true with FEATURE_SECURE_PROCESSING
     */
    public void testSchemaInclude_Secure() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_XSDInclude_Test.class.getResource("XSDInclude_company.xsd").getFile())));
            reportFailToDenyAccess(TEST_EXTERNALSCHEMA, "testSchemaInclude_Secure", PROTOCOL_FILE);
        } catch (SAXException e) {
            denyExternalAccess(e, "file");
        }
        System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
    }

}
