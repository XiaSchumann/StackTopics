/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.bugdb14495809;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URI;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLResolver;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.DefaultHandler;
import util.DOMEcho;

/**
 *
 * accessExternalDTD: jaxp 1.5 property. Allow specifying the
 * method of accessing external DTD Value: local, remote; default is local Error
 * message: External DTD: [local or remote] access not allowed.
 *
 * Relationship with existing features:
 *
 * 1. FEATURE FOR SECURE PROCESSING If this feature is on, accessExternalDTD is
 * default to local only; However, it can overwrite the default if it is set
 * after the secure feature.
 *
 * 2. disallow-doctype-decl for SAX and DOM and SUPPORT_DTD for StAX If these
 * features are set, the accessExternalDTD feature has no effect
 *
 * 3. load-external-dtd if this feature is turned off for non-validating
 * parsing, the accessExternalDTD feature has no effect.
 *
 *
 * This change is required by CR 7192390.
 *
 * @author huizhe.wang@oracle.com
 */
public class Bug7192390Base extends TestCase {

    public static final String ORACLE_JAXP_PROPERTY_PREFIX =
            "http://www.oracle.com/xml/jaxp/properties/";
    public static final String JDK_XSLT_SYSTEMPROPERTY = "javax.xml.transform.";

    /**
    public static final String ACCESS_EXTERNAL_DTD = "http://www.oracle.com/xml/jaxp/properties/accessExternalDTD";
    public static final String ACCESS_EXTERNAL_SCHEMA = "http://www.oracle.com/xml/jaxp/properties/accessExternalSchema";
    public static final String ACCESS_EXTERNAL_STYLESHEET = "http://www.oracle.com/xml/jaxp/properties/accessExternalStylesheet";
    public static final String SP_ACCESS_EXTERNAL_DTD = "jdk.xml.accessExternalDTD";
    public static final String SP_ACCESS_EXTERNAL_SCHEMA = "jdk.xml.accessExternalSchema";
    public static final String SP_ACCESS_EXTERNAL_STYLESHEET = "jdk.xml.accessExternalStylesheet";
    */
    
    public static final String ACCESS_EXTERNAL_DTD = XMLConstants.ACCESS_EXTERNAL_DTD;
    public static final String ACCESS_EXTERNAL_SCHEMA = XMLConstants.ACCESS_EXTERNAL_SCHEMA;
    public static final String ACCESS_EXTERNAL_STYLESHEET = XMLConstants.ACCESS_EXTERNAL_STYLESHEET;
    public static final String SP_ACCESS_EXTERNAL_DTD = "javax.xml.accessExternalDTD";
    public static final String SP_ACCESS_EXTERNAL_SCHEMA = "javax.xml.accessExternalSchema";
    public static final String SP_ACCESS_EXTERNAL_STYLESHEET = "javax.xml.accessExternalStylesheet";

    public static final String DISALLOW_DOCTYPE_DECL_FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
    public static final String LOAD_EXTERNAL_DTD_FEATURE = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
    public static final String EXTERNAL_GENERAL_ENTITIES_FEATURE = "http://xml.org/sax/features/external-general-entities";
    public static final String EXTERNAL_PARAMETER_ENTITIES_FEATURE = "http://xml.org/sax/features/external-parameter-entities";
    static final String SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    static final String SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";

    public static final String IGNORE_EXTERNAL_ENTITY_ERROR = "http://www.oracle.com/xml/jaxp/features/ignoreAccessExternalDTDError";
    public static final boolean SECURE_PROCESSING_TRUE = true;
    public static final boolean SECURE_PROCESSING_FALSE = false;
    public static final boolean DISALLOWDTD_TRUE = true;
    public static final boolean DISALLOWDTD_FALSE = false;
    public static final boolean NOTLOADEXTERNALDTD_TRUE = true;
    public static final boolean NOTLOADEXTERNALDTD_FALSE = false;
    public static final boolean NOTINCGENENTITY_TRUE = true;
    public static final boolean NOTINCPARAMETERENTITY_TRUE = true;
    public static final boolean IGNORE_ERROR_TRUE = true;
    public static final boolean IGNORE_ERROR_FALSE = false;
    static final String ACCESS_DEFAULT = "file";
    static final String ACCESS_DEFAULT_WSECURE = "";
    public static final String ACCESS_EXTERNAL_ALL = "all";
    static final String PROTOCOL_FILE = "file";
    static final String PROTOCOL_HTTP = "http";
    final boolean DEBUG = false;
    static String JAXPProperty_accessExternalDTD;
    static String JAXPProperty_accessExternalSchema;
    static String JAXPProperty_accessExternalStylesheet;
    static final int TEST_EXTERNALDTD = 1;
    static final int TEST_EXTERNALSCHEMA = 2;
    static final int TEST_EXTERNALSTYLESHEET = 3;
    String _external_dtd_file = getClass().getResource("toys2.xml").getPath();
    //_httpserver/tests/bugdb14495809/
    /**
     * final String _external_dtd_http = "<?xml version='1.0' encoding
     * ='utf-8'?>" + "<!DOCTYPE properties SYSTEM
     * \"http://java.sun.com/dtd/properties.dtd\">" + "<properties>" +
     * "<comment>java.util.Properties</comment>" + "<entry
     * key=\"key1\">value1</entry>" + "</properties>";
     */
    String _external_dtd_http, _external_dtd_filepath;
    /**
     * static final String _public_external_dtd = "<?xml version=\"1.0\"
     * encoding=\"utf-8\"?>" + "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0
     * Transitional//EN\"" + "
     * \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\" [" + "<!-- an
     * internal subset can be embedded here -->" + "]>" + "<!-- the XHTML
     * document body starts here-->" + "<html>" + "..." + "</html>";
     */
    String _public_external_dtd;
    String _external_entity;
    String _external_entity_file;
    String _external_entity_http;
    String _external_entity_resolver;
    //only InputStream is supported for StAX's XMLResolver
    String _external_entity_resolver_stax;
    String _external_parameter_entity_file;
    String _external_parameter_entity_http;
    String _xsd_external_dtd_http;
    String _xsl_pi_xslhttp;

    //test with jaxp.properties
    static final boolean hasJaxpProperties = false;
    //for httpserver
    static final String REMOTE_FILE_LOCATION = "/jaxp-ri/src/unit-test/closed/bugdb14495809/remotefiles";
    static final String DOCROOT = ".";
    static final String TESTCONTEXT = REMOTE_FILE_LOCATION;  //mapped to local file path
    static MyHttpServer _httpserver;
    static int _httpserverPort = 65530;
    static String originalJavaHome;

    String _remoteFilePath;
    String _filepath;
    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390Base(String name) {
        super(name);
    }

    @Override
    protected void tearDown() {
        resetJavaHome();
        if (_httpserver != null) {
            _httpserver.stop();
        }
    }

    @Override
    protected void setUp() {
        if (!isJaxp1_5()) {
            System.exit(0);
        }

        if (hasJaxpProperties) {
            //save original java.home, set it to user.dir
            setJavaHome();
        }

        _httpserver = new MyHttpServer(TESTCONTEXT, DOCROOT);
        _httpserver.start();
        _remoteFilePath = _httpserver.getAddress() + REMOTE_FILE_LOCATION;

        JAXPProperty_accessExternalDTD = readJAXPProperty(SP_ACCESS_EXTERNAL_DTD);
        JAXPProperty_accessExternalSchema = readJAXPProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        JAXPProperty_accessExternalStylesheet = readJAXPProperty(SP_ACCESS_EXTERNAL_STYLESHEET);

        _filepath = Bug7192390Base.class.getResource("test.xml").getPath();
        int pos = _filepath.lastIndexOf('/');
        _filepath = _filepath.substring(0, pos);
        initFiles(_remoteFilePath);
    }

    void initFiles(String remoteFilePath) {
        _external_entity_file = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder "
                + "[ <!ENTITY item SYSTEM \""
                + Bug7192390Base.class.getResource("Bug7192390_item.xml").getPath()
                + "\"> ]"
                + ">"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "&item;"
                + "</SupplierOrder>";
        
        _external_dtd_filepath = remoteFilePath + "/properties.dtd";
        _external_dtd_http = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE properties SYSTEM \""
                + remoteFilePath
                + "/properties.dtd\">"
                + "<properties>"
                + "<comment>java.util.Properties</comment>"
                + "<entry key=\"key1\">value1</entry>"
                + "</properties>";

        _public_external_dtd = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\""
                + " \""
                + remoteFilePath
                + "/xhtml1-transitional.dtd\" ["
                + "<!-- an internal subset can be embedded here -->"
                + "]>"
                + "<!-- the XHTML document body starts here-->"
                + "<html>"
                + "..."
                + "</html>";
        _external_entity = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE document "
                + "[ <!ENTITY foo SYSTEM \"C:\\Test\\test.txt\"> ]"
                + ">"
                + "<document>"
                + "<name>&foo;</name>"
                + "</document>";

        _external_entity_http = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder "
                + "[ <!ENTITY item SYSTEM \""
                + remoteFilePath
                + "/Bug7192390_item.xml"
                + "\"> ]"
                + ">"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "&item;"
                + "</SupplierOrder>";
        _external_entity_resolver = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder [ "
                + "<!ENTITY item SYSTEM \""
                + remoteFilePath
                + "/Bug7192390_item.xml"
                + "\">"
                + "<!ENTITY item1 SYSTEM \"replaceWithLocalpath\">"
                + "<!ENTITY item2 SYSTEM \"replaceWithRemotepath\">"
                + " ]>"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "&item;"
                + "&item1;"
                + "&item2;"
                + "</SupplierOrder>";
        //only InputStream is supported for StAX's XMLResolver
        _external_entity_resolver_stax = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder [ "
                + "<!ENTITY item SYSTEM \""
                + remoteFilePath
                + "/Bug7192390_item.xml"
                + "\">"
                + "<!ENTITY item1 SYSTEM \"replaceWithLocalpath\">"
                + " ]>"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "&item;"
                + "&item1;"
                + "</SupplierOrder>";
        _external_parameter_entity_file = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder ["
                + "<!ENTITY % paraEntity SYSTEM \""
                + Bug7192390Base.class.getResource("Bug7192390_paramEntity.dtd").getPath()
                + "\">"
                + "%paraEntity;"
                + "]>"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "<LineItems>"
                + "<LineItem categoryId=\"BIRDS\" itemId=\"EST-18\" lineNo=\"0\" productId=\"AV-CB-01\" quantity=\"&quantity;\" unitPrice=\"&unitPrice;\"/>"
                + "</LineItems>"
                + "</SupplierOrder>";
        _external_parameter_entity_http = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder ["
                + "<!ENTITY % paraEntity SYSTEM \""
                + remoteFilePath
                + "/Bug7192390_paramEntity.dtd\">"
                + "%paraEntity;"
                + "]>"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "<LineItems>"
                + "<LineItem categoryId=\"BIRDS\" itemId=\"EST-18\" lineNo=\"0\" productId=\"AV-CB-01\" quantity=\"&quantity;\" unitPrice=\"&unitPrice;\"/>"
                + "</LineItems>"
                + "</SupplierOrder>";

        _xsd_external_dtd_http = "<?xml version=\"1.0\"?>"
                + "<!DOCTYPE xs:schema PUBLIC \"-//W3C//DTD XMLSCHEMA 200102//EN\" \""
                + remoteFilePath
                + "/XMLSchema.dtd\" ["
                + "<!ATTLIST xs:schema          id  ID  #IMPLIED>"
                + "<!ATTLIST xs:complexType     id  ID  #IMPLIED>"
                + "<!ATTLIST xs:element         id  ID  #IMPLIED>"
                + "<!ATTLIST xs:sequence        id  ID  #IMPLIED>"
                + "]>"
                + "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\">"
                + "  <xs:element name=\"validation\">"
                + "     <xs:complexType>"
                + "       <xs:sequence>"
                + "        <xs:element name=\"val\" type=\"xs:string\" maxOccurs=\"16\" />"
                + "       </xs:sequence>"
                + "     </xs:complexType>"
                + "  </xs:element>"
                + "</xs:schema>";

        _xsl_pi_xslhttp = ""
                + "<?xml version='1.0'?>"
                + "<?xml-stylesheet href=\""
                + remoteFilePath
                + "/XSLPI_target.xsl\" type=\"text/xml\"?>"
                + "<xsl:stylesheet "
                + "    xmlns:xsl='http://www.w3.org/1999/XSL/Transform' "
                + "    version='1.0'>"
                + "</xsl:stylesheet> ";
     
    }

    SAXParser getSAXParser(boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD)
            throws ParserConfigurationException, SAXException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        if (secure) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        if (disallowDTD) {
            spf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, disallowDTD);
        }
        if (notLoadExternalDTD) {
            spf.setValidating(false);
            spf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
        }
        spf.setFeature("http://xml.org/sax/features/namespaces", true);
        SAXParser parser = spf.newSAXParser();

        return parser;
    }

    /**
     * helper method for creating validating SAX parser
     *
     * @param secure
     * @return
     * @throws Exception
     */
    protected SAXParser createValidatingParser(boolean secure) throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);
        spf.setValidating(true);
        if (secure) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        SAXParser parser = spf.newSAXParser();
        parser.setProperty(
                "http://java.sun.com/xml/jaxp/properties/schemaLanguage",
                "http://www.w3.org/2001/XMLSchema");

        return parser;
    }

    /**
     * Create validating DOM builder
     *
     * @param secure
     * @return
     * @throws Exception
     */
    protected DocumentBuilder createValidatingDOM(boolean secure, boolean allowExternalSchema) throws Exception {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            dbf.setValidating(true);
            dbf.setAttribute(SCHEMA_LANGUAGE, XMLConstants.W3C_XML_SCHEMA_NS_URI);
            if (secure) {
                dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            }
            if (allowExternalSchema) {
                //override secure setting for external schema access
                dbf.setAttribute(ACCESS_EXTERNAL_SCHEMA, "file, http");
            }
            dbf.setFeature("http://apache.org/xml/features/validation/schema", true);
            docBuilder = dbf.newDocumentBuilder();
            docBuilder.setErrorHandler(new ErrorHandler() {
                public void warning(SAXParseException exception) throws SAXException {
                }
                public void error(SAXParseException exception) throws SAXException {
                }
                public void fatalError(SAXParseException exception) throws SAXException {
                }
            });
        } catch (Exception e) {
        }


        return docBuilder;
    }

    DOMSource getDOMSource(String uri) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            Document doc = dbf.newDocumentBuilder().parse(uri);
            DOMSource ds = new DOMSource(doc);
            ds.setSystemId(uri);
            return ds;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    /**
     * Report failure if the process goes through without error, unless
     * jaxp.properties is set to allow the protocol
     *
     * @param type -- type of a restriction, e.g. external DTD, XSD or XSL
     * @param testName -- name of the testcase
     * @param protocol -- the protocol requested by external resources
     */
    void reportFailToDenyAccess(int type, String testName, String protocol) {
        if (!isAllowedByJAXPDotProperty(type, protocol)) {
            fail(testName + ": " + protocol + " access should be denied");
        } else {
            success(testName + " passed");
        }
    }

    /**
     * Access restriction should have no effect when certain features/properties
     * are in place to control the relevant constructs. Report failure if the
     * process throws exception
     *
     * @param type -- type of a restriction, e.g. external DTD, XSD or XSL
     * @param testName -- name of the testcase
     * @param msg -- error msg
     */
    void reportFailToGoThrough(int type, String testName, String msg) {
        fail(testName + ": " + msg);
    }

    /**
     * Check if the new properties are supported
     *
     * @return true if yes, false if not
     */
    public boolean isJaxp1_5() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
        } catch (ParserConfigurationException ex) {
            fail(ex.getMessage());
        } catch (SAXException ex) {
            String err = ex.getMessage();
            if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("New accessExternal* properties not supported. Tests not run.");
                return false;
            }
        }
        return true;
    }

    /**
     * check if the protocol is allowed by the property set in jaxp.properties
     *
     * @param type -- type of a restriction, e.g. external DTD, XSD or XSL
     * @param protocol -- the protocol requested by external resources
     * @return true if jaxp.properties is set to allow the protocol
     */
    boolean isAllowedByJAXPDotProperty(int type, String protocol) {
        switch (type) {
            case TEST_EXTERNALDTD:
                if (JAXPProperty_accessExternalDTD != null
                        && (JAXPProperty_accessExternalDTD.contains(protocol)
                        || JAXPProperty_accessExternalDTD.equalsIgnoreCase(ACCESS_EXTERNAL_ALL))) {
                    return true;
                }
                break;
            case TEST_EXTERNALSCHEMA:
                if (JAXPProperty_accessExternalSchema != null
                        && (JAXPProperty_accessExternalSchema.contains(protocol)
                        || JAXPProperty_accessExternalSchema.equalsIgnoreCase(ACCESS_EXTERNAL_ALL))) {
                    return true;
                }
                break;
            case TEST_EXTERNALSTYLESHEET:
                if (JAXPProperty_accessExternalSchema != null
                        && (JAXPProperty_accessExternalSchema.contains(protocol)
                        || JAXPProperty_accessExternalSchema.equalsIgnoreCase(ACCESS_EXTERNAL_ALL))) {
                    return true;
                }
                break;
        }
        return false;
    }

    void denyExternalAccess(int type, Exception e, String protocol) {
        if (isAllowedByJAXPDotProperty(type, protocol)) {
            allowExternalAccess(e);
        } else {
            denyExternalAccess(e, protocol);
        }
    }

    void denyExternalAccess(Exception e, String protocol) {
        String err = e.getMessage();
        if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
            //expected before this patch
            System.out.println("Property accessExternalDTD not supported");
        } else if (err.indexOf("Property '" + ACCESS_EXTERNAL_SCHEMA + "' is not recognized.") > -1) {
            System.out.println("Property accessExternalSchema not supported");
        } else if (err.indexOf("TransformerFactory does not recognise attribute") > -1) {
            System.out.println(err);
        } else if (err.indexOf("External DTD: \"" + protocol + "\" access is not allowed") > -1) {
            //expected error
            System.out.println(protocol + " access not allowed");
        } else if (err.indexOf("'" + protocol + "' access is not allowed") > -1) {
            //expected error
            System.out.println(protocol + " access not allowed");
        } else if (err.indexOf("DOCTYPE is disallowed") > -1) {
            //expected error
            System.out.println(DISALLOW_DOCTYPE_DECL_FEATURE + " is set");
        } else if (err.indexOf("was referenced, but not declared.") > -1) {
            //expected error when IS_REPLACING_ENTITY_REFERENCES = false and access is allowed by jaxp.properties
            System.out.println("IS_REPLACING_ENTITY_REFERENCES=false and access is allowed by jaxp.properties ");
        } else {
            e.printStackTrace();
            fail("Failure: " + e.getMessage());
        }
    }
    
    void allowExternalAccess(String testName, Exception e) {
        System.out.println("Test name:" + testName);
        allowExternalAccess(e);
    }

    void allowExternalAccess(Exception e) {
        String err = e.getMessage();
        if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
            //expected before this patch
            System.out.println("Property accessExternalDTD not supported");
        } else if (err.indexOf("Property '" + ACCESS_EXTERNAL_SCHEMA + "' is not recognized.") > -1) {
            System.out.println("Property accessExternalSchema not supported");
        } else if (err.indexOf("TransformerFactory does not recognise attribute") > -1) {
            System.out.println("TransformerFactory does not recognise attribute 'http://www.oracle.com/xml/jaxp/properties/accessExternalStylesheet'");
        } else if (err.indexOf("Connection timed out: connect") > -1) {
            //sometimes we get this error when http://java.sun.com/dtd/properties.dtd is not accessible
            System.out.println("Connection timed out: connect");
        } else if (err.indexOf("was referenced, but not declared.") > -1) {
            //expected error when IS_REPLACING_ENTITY_REFERENCES = false and access is allowed by jaxp.properties
            System.out.println("IS_REPLACING_ENTITY_REFERENCES=false and access is allowed by jaxp.properties ");
        } else {
            e.printStackTrace();
            fail("Failure: " + e.getMessage());
        }
    }

    void ignoreAccessRestriction(String testName, Exception e, String errMsg, String entity) {
        String err = e.getMessage();
        if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
            //expected before this patch
            System.out.println("Property accessExternalDTD not supported");
        } else if (err.indexOf("Property '" + ACCESS_EXTERNAL_SCHEMA + "' is not recognized.") > -1) {
            System.out.println("Property accessExternalSchema not supported");
        } else if (err.indexOf("Property '" + ACCESS_EXTERNAL_STYLESHEET + "' is not recognized.") > -1) {
            System.out.println("Property accessExternalSchema not supported");
        } else if (err.indexOf("TransformerFactory does not recognise attribute") > -1) {
            System.out.println("TransformerFactory does not recognise attribute 'http://www.oracle.com/xml/jaxp/properties/accessExternalStylesheet'");
        } else if (err.indexOf("Connection timed out: connect") > -1) {
            //sometimes we get this error when http://java.sun.com/dtd/properties.dtd is not accessible
            System.out.println("Connection timed out: connect");
        } else if (err.indexOf("The entity \"" + entity + "\" was referenced, but not declared") > -1) {
            System.out.println("The entity \"" + entity + "\" was referenced, but not declared");
        } else {
            e.printStackTrace();
            if (errMsg != null) {
                fail(testName + ": " + errMsg);
            } else {
                fail(testName + ": Failure: " + e.getMessage());
            }
        }
    }

    void disallowDTD(Exception e) {
        String err = e.getMessage();
        if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
            //expected before this patch
            System.out.println("Property accessExternalDTD not supported");
        } else if (err.indexOf("Property '" + ACCESS_EXTERNAL_SCHEMA + "' is not recognized.") > -1) {
            System.out.println("Property accessExternalSchema not supported");
        } else if (err.indexOf("TransformerFactory does not recognise attribute") > -1) {
            System.out.println("TransformerFactory does not recognise attribute 'http://www.oracle.com/xml/jaxp/properties/accessExternalStylesheet'");
        } else if (err.indexOf("DOCTYPE is disallowed") > -1) {
            //expected error
            System.out.println(DISALLOW_DOCTYPE_DECL_FEATURE + " is set");
        } else {
            e.printStackTrace();
            fail("Failure: " + e.getMessage());
        }
    }

    void readDTD(XMLStreamReader xsr) throws XMLStreamException {
        while (xsr.hasNext()) {
            int e = xsr.next();
            if (e == XMLEvent.DTD) {
                print("DTD: " + xsr.getText());
            }
        }

    }

    void print(String s) {
        if (DEBUG) {
            System.out.println(s);
        }
    }

    static class TestHttpHandler implements HttpHandler {

        String _docroot;

        public TestHttpHandler(String docroot) {
            _docroot = docroot;
        }

        public void handle(HttpExchange t)
                throws IOException {
            InputStream is = t.getRequestBody();
            Headers map = t.getRequestHeaders();
            Headers rmap = t.getResponseHeaders();
            OutputStream os = t.getResponseBody();
            URI uri = t.getRequestURI();
            String path = uri.getPath();


            while (is.read() != -1) ;
            is.close();

            File f = new File(_docroot, path);
            if (!f.exists()) {
                notfound(t, path);
                return;
            }

            String method = t.getRequestMethod();
            if (method.equals("HEAD")) {
                rmap.set("Content-Length", Long.toString(f.length()));
                t.sendResponseHeaders(200, -1);
                t.close();
            } else if (!method.equals("GET")) {
                t.sendResponseHeaders(405, -1);
                t.close();
                return;
            }

            if (path.endsWith(".html") || path.endsWith(".htm")) {
                rmap.set("Content-Type", "text/html");
            } else {
                rmap.set("Content-Type", "text/plain");
            }

            t.sendResponseHeaders(200, f.length());

            FileInputStream fis = new FileInputStream(f);
            int count = 0;
            try {
                byte[] buf = new byte[16 * 1024];
                int len;
                while ((len = fis.read(buf)) != -1) {
                    os.write(buf, 0, len);
                    count += len;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            fis.close();
            os.close();
        }

        void moved(HttpExchange t) throws IOException {
            Headers req = t.getRequestHeaders();
            Headers map = t.getResponseHeaders();
            URI uri = t.getRequestURI();
            String host = req.getFirst("Host");
            String location = "http://" + host + uri.getPath() + "/";
            map.set("Content-Type", "text/html");
            map.set("Location", location);
            t.sendResponseHeaders(301, -1);
            t.close();
        }

        void notfound(HttpExchange t, String p) throws IOException {
            t.getResponseHeaders().set("Content-Type", "text/html");
            t.sendResponseHeaders(404, 0);
            OutputStream os = t.getResponseBody();
            String s = "<h2>File not found</h2>";
            s = s + p + "<p>";
            os.write(s.getBytes());
            os.close();
            t.close();
        }
    }

    /**
     * SAX handler
     */
    public class MyHandler extends DefaultHandler2 implements ErrorHandler {

        StringBuffer currentValue = new StringBuffer();

        public void startDocument() throws SAXException {
        }

        public void endDocument() throws SAXException {
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            currentValue.delete(0, currentValue.length());
            try {
                System.out.println("Element: " + uri + ":" + localName + " " + qName);
            } catch (Exception e) {
                throw new SAXException(e);
            }

        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
            System.out.println("Text: \n" + currentValue.toString() + "\n");
            System.out.println("End Element: " + uri + ":" + localName + " " + qName);
        }

        public void characters(char ch[], int start, int length) throws SAXException {
            currentValue.append(ch, start, length);
        }

        public void internalEntityDecl(String name, String value) throws SAXException {
            super.internalEntityDecl(name, value);
            System.out.println("internalEntityDecl() is invoked for entity : " + name);
        }

        public void externalEntityDecl(String name, String publicId, String systemId) throws SAXException {
            super.externalEntityDecl(name, publicId, systemId);
            System.out.println("externalEntityDecl() is invoked for entity : " + name);
        }

        public void startEntity(String name) throws SAXException {
            super.startEntity(name);
//		System.out.println("startEntity() is invoked for entity : " + name) ;
        }

        public void endEntity(String name) throws SAXException {
            super.endEntity(name);
//		System.out.println("endEntity() is invoked for entity : " + name) ;
        }

        public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
            System.out.println("resolveEntity(publicId, systemId) is invoked");
            return super.resolveEntity(publicId, systemId);
        }

        public InputSource resolveEntity(String name, String publicId, String baseURI, String systemId) throws SAXException, IOException {
            System.out.println("resolveEntity(name, publicId, baseURI, systemId) is invoked");
            return super.resolveEntity(name, publicId, baseURI, systemId);
        }

        public InputSource getExternalSubset(String name, String baseURI) throws SAXException, IOException {
            System.out.println("getExternalSubset() is invoked");
            return super.getExternalSubset(name, baseURI);
        }
    }

    /////////////////////////////////////////////////
    ///////////Using Resolver
    /////////////////////////////////////////////////
    class myEntityResolver implements EntityResolver {

        public InputSource resolveEntity(String publicId, String systemId) {
            if (systemId.indexOf("replaceWithLocalpath") > -1) {
                return new InputSource(Bug7192390Base.class.getResource("Bug7192390_item.xml").getPath());
            } else if (systemId.indexOf("replaceWithRemotepath") > -1) {
                return new InputSource(_remoteFilePath + "/Bug7192390_item.xml");
            }

            return null;
        }
    }

    class myExternalDTDResolver implements EntityResolver {

        public InputSource resolveEntity(String publicId, String systemId) {
            if (systemId.indexOf("properties.dtd") > -1) {
                return new InputSource(_external_dtd_filepath);
            } else if (systemId.indexOf("externalDTD2.dtd") > -1) {
                return new InputSource(Bug7192390Base.class.getResource("externalDTD2.dtd").getPath());
            }

            return null;
        }
    }

    class MyStaxResolver implements XMLResolver {

        public MyStaxResolver() {
        }

        public Object resolveEntity(String publicId, String systemId, String baseURI, String namespace) throws javax.xml.stream.XMLStreamException {
            if (systemId.indexOf("replaceWithLocalpath") > -1) {
                return Bug7192390Base.class.getResourceAsStream("Bug7192390_item.xml");
            } else if (systemId.indexOf("replaceWithRemotepath") > -1) {
                try {
                    XMLInputFactory xif = XMLInputFactory.newInstance();
                    XMLStreamReader xsr = xif.createXMLStreamReader(new StreamSource(_remoteFilePath + "/Bug7192390_item.xml"));
                    return xsr;
                } catch (Exception e) {
                }
            }

            return null;
        }
    }

    /**
     * Read from $java.home/lib/jaxp.properties for the specified property
     *
     * @param propertyId the Id of the property
     * @return the value of the property
     */
    public static String getDefaultAccessProperty(String sysPropertyId, String defaultVal) {
        String accessExternal = getSystemProperty(sysPropertyId);
        if (accessExternal != null) {
            accessExternal = accessExternal.toLowerCase();
        } else {
            accessExternal = readJAXPProperty(sysPropertyId);
            if (accessExternal == null) {
                accessExternal = defaultVal;
            }
        }
        return accessExternal;
    }

    /**
     * Save original java home, and set it to user.dir
     */
    static void setJavaHome() {
        originalJavaHome = (String)
        AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                String javaHome = System.getProperty("java.home");
                System.setProperty("java.home", System.getProperty("user.dir"));
                return javaHome;
            }
        });
    }

    /**
     * reset java home to the original value
     */
    static void resetJavaHome() {
        if (originalJavaHome != null) {
            AccessController.doPrivileged(new PrivilegedAction() {
                public Object run() {
                    System.setProperty("java.home", originalJavaHome);
                    return null;
                }
            });
        }
    }

    /**
     * Read from $java.home/lib/jaxp.properties for the specified property
     *
     * @param propertyId the Id of the property
     * @return the value of the property
     */
    static String readJAXPProperty(String propertyId) {
        String value = null;
        try {
            if (firstTime) {
                synchronized (cacheProps) {
                    if (firstTime) {
                        String configFile = getSystemProperty("java.home") + File.separator
                                + "lib" + File.separator + "jaxp.properties";
                        File f = new File(configFile);
                        firstTime = false;
                        if (getFileExists(f)) {
                            cacheProps.load(getFileInputStream(f));
                        }
                    }
                }
            }
            value = cacheProps.getProperty(propertyId);

        } catch (Exception ex) {
        }

        return value;
    }

    public static String getSystemProperty(final String propName) {
        return (String) AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                return System.getProperty(propName);
            }
        });
    }

    static boolean getFileExists(final File f) {
        return ((Boolean) AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                return f.exists() ? Boolean.TRUE : Boolean.FALSE;
            }
        })).booleanValue();
    }

    static FileInputStream getFileInputStream(final File file)
            throws FileNotFoundException {
        try {
            return (FileInputStream) AccessController.doPrivileged(new PrivilegedExceptionAction() {
                public Object run() throws FileNotFoundException {
                    return new FileInputStream(file);
                }
            });
        } catch (PrivilegedActionException e) {
            throw (FileNotFoundException) e.getException();
        }
    }


    /**
     * jaxp 1.5 does not require implementations to restrict by default
     * 
     * For JDK9:
     * The default value is 'file' (including jar:file); The keyword "all" grants permission
     * to all protocols. When {@link javax.xml.XMLConstants#FEATURE_SECURE_PROCESSING} is on,
     * the default value is an empty string indicating no access is allowed.    
     * 
     * For JDK7, 8:
     * The default value is 'all' granting permission to all protocols. If by default, 
     * {@link javax.xml.XMLConstants#FEATURE_SECURE_PROCESSING} is true, it should
     * not change the default value. However, if {@link javax.xml.XMLConstants#FEATURE_SECURE_PROCESSING}
     * is set explicitly, the values of the properties shall be set to an empty string 
     * indicating no access is allowed.    
     * 
     */
    public void checkDefaultBehavior(int type, String testName, String protocol) {
        if (versionNumber >= 1.9) {
            reportFailToDenyAccess(type, testName, protocol);
        }
    }
    public void checkDefaultBehaviorExp(int type, Exception e, String protocol) {
        if (versionNumber >= 1.9) {
            denyExternalAccess(type, e, protocol);
        } else {
            allowExternalAccess(e);
        }
    }
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void checkFSPBehavior(int type, String testName, String protocol) {
        if (versionNumber >= 1.8) {
            reportFailToDenyAccess(type, testName, protocol);
        }
    }
    public void checkFSPBehaviorExp(String testName, int type, Exception e, String protocol) {
        System.out.println("Test " + testName);
        checkFSPBehaviorExp(type, e, protocol);
    }
    public void checkFSPBehaviorExp(int type, Exception e, String protocol) {
        if (versionNumber >= 1.8) {
            denyExternalAccess(type, e, protocol);
        } else {
            allowExternalAccess(e);
        }
    }
    
    public void printDOMTree(Document doc) {
        OutputStreamWriter outWriter = null;
        try {
            outWriter = new OutputStreamWriter(System.out, DOMEcho.outputEncoding);
            PrintWriter writer = new PrintWriter(outWriter, true);
            DOMEcho echo = new DOMEcho(writer);
            new DOMEcho(new PrintWriter(outWriter, true)).echo(doc);
        } catch (UnsupportedEncodingException ex) {        
            Logger.getLogger(Bug7192390Base.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                outWriter.close();
            } catch (IOException ex) {
                Logger.getLogger(Bug7192390Base.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    static final String javaVersion = System.getProperty("java.version");
    static final double versionNumber = getJavaVersion();
    static double getJavaVersion() {
        String version = javaVersion.substring(0, javaVersion.indexOf('.', 2));
        return Double.parseDouble(version);
    }    
    
    /**
     * Cache for properties in java.home/lib/jaxp.properties
     */
    static final Properties cacheProps = new Properties();
    /**
     * Flag indicating if properties from java.home/lib/jaxp.properties have
     * been cached.
     */
    static volatile boolean firstTime = true;
    
    void success(String msg) {
        System.out.println(msg);
    }
}
