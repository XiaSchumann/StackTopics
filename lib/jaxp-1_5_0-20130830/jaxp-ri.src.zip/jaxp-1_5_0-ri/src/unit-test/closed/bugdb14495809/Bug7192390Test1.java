package closed.bugdb14495809;

import java.io.*;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * @author huizhe.wang@oracle.com
 */
public class Bug7192390Test1 extends Bug7192390Base {

    private static String XSL_INC_FILE = null;
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<book>"
            + "<chapter>"
            + "<title>Introduction</title>"
            + "<para>Paragraph 1</para>"
            + "<para>Paragraph 2</para>"
            + "</chapter>"
            + "</book>";

    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390Test1(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bug7192390Test1.class);
    }
    private static final String PROPS_DTD_URI =
            "http://java.sun.com/dtd/properties.dtd";
    private static final String PROPS_DTD =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<!-- DTD for properties -->"
            + "<!ELEMENT properties ( comment?, entry* ) >"
            + "<!ATTLIST properties"
            + " version CDATA #FIXED \"1.0\">"
            + "<!ELEMENT comment (#PCDATA) >"
            + "<!ELEMENT entry (#PCDATA) >"
            + "<!ATTLIST entry "
            + " key CDATA #REQUIRED>";
    
    String _xmlFile, _xsdFile, _xmlValFile, _xsdValFile, _xsdImport, _xsdInclude;
    String _xmlFileId, _xmlValFileId;
    
    String _xslFile, _xmlFile_xslt, _xslIncFile, _xslDocFile, _xmlDocFile;
    String _sourceDTD, _xslDTD;
    String _xslFileId, _xslIncFileId, _xslDocFileId;
    //junit @Override
    protected void setUp() {
        super.setUp();
        _xmlFile = _filepath + "/val_test.xml";
        _xsdFile = _filepath + "/val_test.xsd";
        _xmlValFile = _filepath + "/validation.xml";
        _xsdValFile = _filepath + "/validation.xsd";
        _xsdImport = _filepath + "/XSDImport_company.xsd";
        _xsdInclude = _filepath + "/XSDInclude_company.xsd";
        _xmlFileId = "file://" + _xmlFile;
        _xmlValFileId = "file://" + _xmlValFile;

        //xslt test
       _xslFile = _filepath + "/XSLPI.xsl";
        _xmlFile_xslt = _filepath + "/XSLPI.xml";
        _xslIncFile = _filepath + "/XSLInclude_main.xsl";
        _xslDocFile = _filepath + "/DocumentFunc.xsl";
        _xmlDocFile = _filepath + "/DocumentFunc.xml";
        _sourceDTD = _filepath + "/XSLSourceDTD.xml";
        _xslDTD = _filepath + "/XSLDTD.xsl";
        //system id
        _xslFileId = "file:" + _xslFile;
        _xslIncFileId = "file:" + _xslIncFile;
        _xslDocFileId = "file:" + _xslDocFile;             
    }
    public void testEER_wEntityResolver_default() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            XMLReader reader = parser.getXMLReader();
            reader.setEntityResolver(new myEntityResolver());
            reader.parse(new InputSource(new StringReader(_external_entity_resolver)));
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }
    
    
    DOMSource getDOMSource(String uri, String systemId) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            Document doc = dbf.newDocumentBuilder().parse(new FileInputStream(uri));
            DOMSource ds = new DOMSource(doc);
            ds.setSystemId(systemId);
            return ds;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void xtestSchemaLocation_Validator_DOM_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            DOMSource source = getDOMSource(_xmlFileId);
            validator.validate(source);
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaLocation_Validator_DOM_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp("testSchemaLocation_Validator_DOM_Secure", TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    
    public void xtestSchemaLoading_SAX_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").toExternalForm()));
            //source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }
    
    public void xtestStAXAccess_notLoadDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
            xif.setProperty(ACCESS_EXTERNAL_DTD, "x");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
            readDTD(xsr);
        } catch (Exception e) {
        String err = e.getMessage();
        if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
        System.out.println("error message: " +err);
        }                 
            ignoreAccessRestriction("testStAXAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }


    
    public void xtestSchemaLocation_Validator_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaLocation_Validator_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp("testSchemaLocation_Validator_Secure", TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    
    public void xtestDTDinXSD_SysPropertySFP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            // Setting SFP should not change anything since SP_ACCESS_EXTERNAL_DTD is set.

            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            Schema schema = schemaFactory.newSchema(new StreamSource(new StringReader(_xsd_external_dtd_http)));
            success("testDTDinXSD_SysPropertySFP passed");
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    } 
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void xtestSchemaLocation_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaLocation_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    
    public void xtestDOM_wEntityResolver_Default() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            docBuilder = dbf.newDocumentBuilder();
            docBuilder.setEntityResolver(new myEntityResolver());
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_resolver)));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDOM_wEntityResolver_Default", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }
    
    public void xtestStylesheetPI_stream_FileAllowedByDefault_select12() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            StreamSource xslSource = new StreamSource(Bug7192390_XSLT_Test.class.getResource("select12.xsl").toExternalForm());
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("select12.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("select12.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            fail(e.toString());
        }
    }

    public void xtestStylesheetPI_stream_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            StreamSource xslSource = new StreamSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            fail(e.toString());
        }
    }
    
    public void xtestEER_JAXPProperty() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            //file access is allowed

            //parser.parse(this.getClass().getResource("toys2.xml").getFile(), new DefaultHandler());
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
            parser.reset();
            //but not http
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
  //          checkDefaultBehavior(TEST_EXTERNALDTD, "testEER_JAXPProperty", PROTOCOL_HTTP);
        } catch (Exception e) {
            allowExternalAccess(e);
//            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }    
    public void xtestStAXJAXPProperties() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, "");
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
            readDTD(xsr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
    public void xtestStAXEventJAXPProperties() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, "");
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
            XMLEventReader er = xif.createXMLEventReader(xsr);
            //readDTD(xsr);
            while (er.hasNext()) {
                er.nextEvent();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
    
    public void xtestSchemaLoading_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("Bug7192390_val.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void xtestInclude_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
            reportFailToDenyAccess(TEST_EXTERNALSTYLESHEET, "testInclude_secure", PROTOCOL_FILE);
        } catch (Exception e) {
            denyExternalAccess(TEST_EXTERNALSTYLESHEET, e, "file");
        }
    }

    public void xtestStylesheetPI_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            denyExternalAccess(e, "file");
        }
    }

    public void xxtestInclude_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
            reportFailToDenyAccess(TEST_EXTERNALSTYLESHEET, "testInclude_secure", PROTOCOL_FILE);
        } catch (Exception e) {
            denyExternalAccess(TEST_EXTERNALSTYLESHEET, e, "file");
        }
    }

    public void xtestSchemaLoading_JAXPProperty2() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            //validator.setProperty(ACCESS_EXTERNAL_DTD, "");
            validator.setProperty(ACCESS_EXTERNAL_SCHEMA, "");
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("Bug7192390_val.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);
            reportFailToDenyAccess(TEST_EXTERNALSCHEMA, "testSchemaLoading_JAXPProperty1", PROTOCOL_FILE);

        } catch (Exception e) {
            e.printStackTrace();
//            denyExternalAccess(e, "file");
        }
    }

    public void xtestSchemaLocation_JAXPProperty1() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(ACCESS_EXTERNAL_DTD, "");
            validator.setProperty(ACCESS_EXTERNAL_SCHEMA, "");
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            denyExternalAccess(e, "file");
        }
    }

    //-------------------------
    Document getLoadingDoc(InputSource in)
            throws SAXException, IOException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setIgnoringElementContentWhitespace(true);
        dbf.setValidating(true);
        dbf.setCoalescing(true);
        dbf.setIgnoringComments(true);
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            db.setEntityResolver(new Resolver());
            db.setErrorHandler(new EH());
            //InputSource is = new InputSource(in);
            return db.parse(in);
        } catch (ParserConfigurationException x) {
            throw new Error(x);
        }
    }

    private static class Resolver implements EntityResolver {

        public InputSource resolveEntity(String pid, String sid)
                throws SAXException {
            if (sid.indexOf("properties.dtd") > 0) {
                InputSource is;
                is = new InputSource(new StringReader(PROPS_DTD));
                is.setSystemId(PROPS_DTD_URI);
                return is;
            }
            throw new SAXException("Invalid system identifier: " + sid);
        }
    }

    private static class EH implements ErrorHandler {

        public void error(SAXParseException x) throws SAXException {
            throw x;
        }

        public void fatalError(SAXParseException x) throws SAXException {
            throw x;
        }

        public void warning(SAXParseException x) throws SAXException {
            throw x;
        }
    }
    private static URIResolver resolver = new URIResolver() {
        public Source resolve(String href, String base)
                throws TransformerException {
            System.out.println("resolving: " + href);
            return new StreamSource(this.getClass().getResourceAsStream(href));
        }
    };

    SAXParser getSAXParser(boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD, boolean notIncGeneralEntity, boolean notIncParameterEntity)
            throws ParserConfigurationException, SAXException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        if (secure) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        if (disallowDTD) {
            spf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, disallowDTD);
        }
        if (notLoadExternalDTD) {
            spf.setValidating(false);
            spf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
        }
        if (notIncGeneralEntity) {
            spf.setFeature(EXTERNAL_GENERAL_ENTITIES_FEATURE, false);
        }
        if (notIncParameterEntity) {
            spf.setFeature(EXTERNAL_PARAMETER_ENTITIES_FEATURE, false);
        }
        SAXParser parser = spf.newSAXParser();

        return parser;
    }

}
