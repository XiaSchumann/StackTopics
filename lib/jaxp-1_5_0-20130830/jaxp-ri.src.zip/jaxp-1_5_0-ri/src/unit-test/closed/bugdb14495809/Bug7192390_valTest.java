/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.bugdb14495809;

import bug4966232.Bug;
import java.io.File;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * accessExternalDTD: jaxp 1.5 property. Allow specifying the
 * method of accessing external DTD Value: local, remote; default is local Error
 * message: External DTD: [local or remote] access not allowed.
 *
 * Relationship with existing features:
 *
 * 1. FEATURE FOR SECURE PROCESSING If this feature is on, accessExternalDTD is
 * default to local only; However, it can overwrite the default if it is set
 * after the secure feature.
 *
 * 2. disallow-doctype-decl for SAX and DOM and SUPPORT_DTD for StAX If these
 * features are set, the accessExternalDTD feature has no effect
 *
 * 3. load-external-dtd if this feature is turned off for non-validating
 * parsing, the accessExternalDTD feature has no effect.
 *
 *
 * This change is required by CR 7189567.
 *
 * @author huizhe.wang@oracle.com
 */
public class Bug7192390_valTest extends Bug7192390Base {

    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390_valTest(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bug7192390_valTest.class);
    }
    String _xmlFile, _xsdFile, _xmlValFile, _xsdValFile, _xsdImport, _xsdInclude;
    String _xmlFileId, _xmlValFileId;
    //junit @Override

    protected void setUp() {
        super.setUp();
        _xmlFile = _filepath + "/val_test.xml";
        _xsdFile = _filepath + "/val_test.xsd";
        _xmlValFile = _filepath + "/validation.xml";
        _xsdValFile = _filepath + "/validation.xsd";
        _xsdImport = _filepath + "/XSDImport_company.xsd";
        _xsdInclude = _filepath + "/XSDInclude_company.xsd";
        _xmlFileId = "file:" + _xmlFile;
        _xmlValFileId = "file:" + _xmlValFile;
    }
/////////////////////////////////////////////////
///////////SchemaLocation
/////////////////////////////////////////////////

    DOMSource getDOMSource(String uri) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            Document doc = dbf.newDocumentBuilder().parse(uri);
            DOMSource ds = new DOMSource(doc);
            return ds;
        } catch (Exception e) {
            return null;
        }
    }
    /**
     * For JDK7 and 8, there's no restriction by default
     */
    public void testSchemaLocationSAX_default() {
        try {
            SAXParser parser = createValidatingParser(false);
            parser.parse(
                    Bug7192390_valTest.class.getResource("test.xml").toExternalForm(),
                    new DefaultHandler());
            checkDefaultBehavior(TEST_EXTERNALSCHEMA, "testSchemaLocationSAX_default", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALSCHEMA, e, "file");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaLocationSAX_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try {
            SAXParser parser = createValidatingParser(false);
            parser.parse(
                    Bug7192390_valTest.class.getResource("test.xml").toExternalForm(),
                    new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }
        
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testSchemaLocationSAX_Secure() {
        try {
            SAXParser parser = createValidatingParser(SECURE_PROCESSING_TRUE);
            parser.parse(
                    Bug7192390_valTest.class.getResource("test.xml").toExternalForm(),
                    new DefaultHandler());
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaLocationSAX_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testSchemaLocationSAX_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try {
            SAXParser parser = createValidatingParser(SECURE_PROCESSING_TRUE);
            parser.parse(
                    Bug7192390_valTest.class.getResource("test.xml").toExternalForm(),
                    new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }

    /**
     * the access property will override default or other settings such as 
     * secure processing
     */
    public void testSchemaLocationSAX_JAXPProperty() {
        try {
            SAXParser parser = createValidatingParser(SECURE_PROCESSING_TRUE);
            parser.setProperty(ACCESS_EXTERNAL_SCHEMA, "file");
            parser.parse(
                    Bug7192390_valTest.class.getResource("test.xml").toExternalForm(),
                    new DefaultHandler());

        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    /**
     * access denied by default since secure processing is on
     */
    public void testSchemaLocationDOM_default() {
        try {
            DocumentBuilder docBuilder = createValidatingDOM(false, false);
            Document document = docBuilder.parse(Bug7192390_valTest.class.getResource("test.xml").toExternalForm());
            checkDefaultBehavior(TEST_EXTERNALSCHEMA, "testSchemaLocationDOM_default", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALSCHEMA, e, "file");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaLocationDOM_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try {
            DocumentBuilder docBuilder = createValidatingDOM(false, false);
            Document document = docBuilder.parse(Bug7192390_valTest.class.getResource("test.xml").toExternalForm());
            success("testSchemaLocationDOM_SP passed");
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }
        
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testSchemaLocationDOM_Secure() {
        try {
            DocumentBuilder docBuilder = createValidatingDOM(SECURE_PROCESSING_TRUE, false);
            Document document = docBuilder.parse(Bug7192390_valTest.class.getResource("test.xml").toExternalForm());
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaLocationDOM_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testSchemaLocationDOM_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try {
            DocumentBuilder docBuilder = createValidatingDOM(SECURE_PROCESSING_TRUE, false);
            Document document = docBuilder.parse(Bug7192390_valTest.class.getResource("test.xml").toExternalForm());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }

    /**
     * the access property will override default or other settings such as 
     * secure processing
     */
    public void testSchemaLocationDOM_JAXPProperty() {
        try {
            //set secure processing, and then allow external schema
            DocumentBuilder docBuilder = createValidatingDOM(SECURE_PROCESSING_TRUE, true);            
            Document document = docBuilder.parse(Bug7192390_valTest.class.getResource("test.xml").toExternalForm());
            success("testSchemaLocationDOM_JAXPProperty passed");
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }
    
    
    /**
     * access denied by default since secure processing is on
     */
    public void testSchemaLocation_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);
            checkDefaultBehavior(TEST_EXTERNALSCHEMA, "testSchemaLocation_default", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALSCHEMA, e, "file");
        }
    }
    public void testSchemaLocation_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            e.printStackTrace();
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }
    
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testSchemaLocation_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaLocation_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

/**
            test.testSchemaLocation_SAX_Secure();
            test.testSchemaLocation_DOM_Secure(); // This test is failing!
            test.testSchemaLocation_StAX_Secure();
            test.testSchemaLocation_Validator_Secure(); // This test is failing!
            test.testSchemaLocation_Validator_SAX_Secure(); // This test is failing!
            test.testSchemaLocation_Validator_DOM_Secure(); // This test is failing!
            */
    public void testSchemaLocation_DOM_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            //DOMSource source = new DOMSource(null, _xmlFileId);
            DOMSource source = getDOMSource(_xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_DOM_SP passed");
        } catch (Exception e) {
            allowExternalAccess("testSchemaLocation_DOM_SP", e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }

    public void testSchemaLocation_Validator_DOM_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            //DOMSource source = new DOMSource(null, _xmlFileId);
            //DOMSource source = getDOMSource(_xmlFileId);
            DOMSource source = getDOMSource(Bug7192390Base.class.getResource("test.xml").getPath());
            
            validator.validate(source);
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaLocation_Validator_DOM_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp("testSchemaLocation_Validator_DOM_Secure", TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    } 
/**
            test.testSchemaLocation_Validator_StAX_Secure(); // This test is failing!
            test.testSchemaLocation_default();
            test.testSchemaLocation_SAX_default();
            test.testSchemaLocation_SAX2_default();
            test.testSchemaLocation_schema();
            test.testSchemaLocation_SAX_schema();

            test.testSchemaLocationSAXSP_Secure();
            test.testSchemaLocationSAXSP_Secure2();
            test.testSchemaLocationDOM_Secure_SP();
 */
    /**
     * System property will override that set by FSP
     */
    public void testSchemaLocation_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }

    public void testSchemaLocation_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(ACCESS_EXTERNAL_DTD, "");
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    public void testSchemaLocation_JAXPProperty1() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(ACCESS_EXTERNAL_DTD, "");
            validator.setProperty(ACCESS_EXTERNAL_SCHEMA, "");
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            denyExternalAccess(e, "file");
        }
    }
    
/////////////////////////////////////////////////
///////////noNamespaceSchemaLocation
/////////////////////////////////////////////////
    
    /**
     * access denied by default since secure processing is on
     */
    public void testSchemaLoading_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("Bug7192390_val.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);
            checkDefaultBehavior(TEST_EXTERNALSCHEMA, "testSchemaLoading_default", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALSCHEMA, e, "file");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaLoading_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("Bug7192390_val.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testSchemaLoading_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("Bug7192390_val.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaLoading_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testSchemaLoading_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("Bug7192390_val.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }

    /**
     * in rare cases, xml file may refer to both external dtd and xsd
     * the external dtd shall be restricted by the ACCESS_EXTERNAL_DTD property
     * 
     * ACCESS_EXTERNAL_DTD can be set on SchemaFactory, as well as the validator
     */
    public void testSchemaLoading_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("Bug7192390_val.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    /**
     * in rare cases, xml file may refer to both external dtd and xsd
     * the external dtd shall be restricted by the ACCESS_EXTERNAL_DTD property
     */
    public void testSchemaLoading_JAXPProperty1() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(ACCESS_EXTERNAL_DTD, "");
            validator.setProperty(ACCESS_EXTERNAL_SCHEMA, "");
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("Bug7192390_val.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);
            reportFailToDenyAccess(TEST_EXTERNALSCHEMA, "testSchemaLoading_JAXPProperty1", PROTOCOL_FILE);

        } catch (Exception e) {
            denyExternalAccess(e, "file");
        }
    }
    
    /**
     * SAXSource
     */    
    public void testSchemaLoading_SAX_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").toExternalForm()));
            //source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);

        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    public void testSchemaLoading_SAX_JAXPProperty1() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(ACCESS_EXTERNAL_DTD, "");
            SAXSource source = new SAXSource(new InputSource(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").toExternalForm()));
            //source.setSystemId(Bug7192390_valTest.class.getResource("Bug7192390_val.xml").getPath());
            validator.validate(source);
            reportFailToDenyAccess(TEST_EXTERNALSCHEMA, "testSchemaLoading_JAXPProperty1", PROTOCOL_FILE);
        } catch (Exception e) {
            denyExternalAccess(e, "file");
        }
    }

    /**
     * restriction does not apply to schema created explicitly
     */
    public void testSchemaLocation_schema() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "");
            Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xsd")));
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(Bug7192390_valTest.class.getResourceAsStream("test.xml"));
            source.setSystemId(Bug7192390_valTest.class.getResource("test.xml").getPath());
            validator.validate(source);
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }
    

/////////////////////////////////////////////////
///////////XSD Import
/////////////////////////////////////////////////
    public void testSchemaImport_default() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDImport_company.xsd").getFile())));
            checkDefaultBehavior(TEST_EXTERNALSCHEMA, "testSchemaImport_default", PROTOCOL_FILE);
        } catch (SAXException e) {
            checkDefaultBehaviorExp(TEST_EXTERNALSCHEMA, e, "file");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaImport_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDImport_company.xsd").getFile())));
        } catch (SAXException e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }
            
    /**
     * jaxp property takes preference
     */
    public void testSchemaImport_JAXPProperty() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file");
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDImport_company.xsd").getFile())));
        } catch (SAXException e) {
            allowExternalAccess(e);
        }
    }
    
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testSchemaImport_Secure() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDImport_company.xsd").getFile())));
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaImport_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testSchemaImport_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDImport_company.xsd").getFile())));
        } catch (SAXException e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }

/////////////////////////////////////////////////
///////////XSD Include
/////////////////////////////////////////////////
    public void testSchemaInclude_default() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDInclude_company.xsd").getFile())));
            checkDefaultBehavior(TEST_EXTERNALSCHEMA, "testSchemaInclude_default", PROTOCOL_FILE);
        } catch (SAXException e) {
            checkDefaultBehaviorExp(TEST_EXTERNALSCHEMA, e, "file");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaInclude_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDInclude_company.xsd").getFile())));
        } catch (SAXException e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }
            
    /**
     * jaxp property takes preference
     */
    public void testSchemaInclude_JAXPProperty() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file");
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDInclude_company.xsd").getFile())));
        } catch (SAXException e) {
            allowExternalAccess(e);
        }
    }
    
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testSchemaInclude_Secure() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDInclude_company.xsd").getFile())));
            checkFSPBehavior(TEST_EXTERNALDTD, "testSchemaInclude_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testSchemaInclude_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_SCHEMA, "file");
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(Bug7192390_valTest.class.getResource("XSDInclude_company.xsd").getFile())));
        } catch (SAXException e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_SCHEMA);
        }
    }
    
}
