/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.bugdb14495809;

import java.io.*;
import java.net.URL;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Bug6954738_Test;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * accessExternalDTD: an Oracle implementation property. Allow specifying the
 * method of accessing external DTD Value: local, remote; default is local Error
 * message: External DTD: [local or remote] access not allowed.
 *
 * Relationship with existing features:
 *
 * 1. FEATURE FOR SECURE PROCESSING If this feature is on, accessExternalDTD is
 * default to local only; However, it can overwrite the default if it is set
 * after the secure feature.
 *
 * 2. disallow-doctype-decl for SAX and DOM and SUPPORT_DTD for StAX If these
 * features are set, the accessExternalDTD feature has no effect
 *
 * 3. load-external-dtd if this feature is turned off for non-validating
 * parsing, the accessExternalDTD feature has no effect.
 *
 *
 * This change is required by CR 7192390.
 *
 * @author huizhe.wang@oracle.com
 */
public class Bkup_Bug7192390Test extends Bkup_Bug7192390Base {


    /**
     * Creates a new instance of StreamReader
     */
    public Bkup_Bug7192390Test(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bkup_Bug7192390Test.class);
    }

    @Override
    protected void setUp() {
        _external_entity_remote = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder "
                + "[ <!ENTITY item SYSTEM \""
                + Bkup_Bug7192390Test.class.getResource("Bug7192390_item.xml").getPath()
                + "\"> ]"
                + ">"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "&item;"
                + "</SupplierOrder>";

    }

/////////////////////////////////////////////////
///////////SchemaLocation
/////////////////////////////////////////////////
    public void xtestSchemaLocation() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

                //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema();
                Validator validator = schema.newValidator();
                validator.setErrorHandler(new ErrorHandler() {
                        public void error(SAXParseException exception) throws SAXException {
                                exception.printStackTrace();
                        }

                        public void fatalError(SAXParseException exception) throws SAXException {
                                exception.printStackTrace();
                        }

                        public void warning(SAXParseException exception) throws SAXException {
                                exception.printStackTrace();
                        }
                });
                validator.validate(new StreamSource(Bkup_Bug7192390Test.class.getResourceAsStream("Bug7192390_val.xml")));

        } catch (SAXException e) {
            System.out.println(e.getMessage() );


        } catch (IOException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

/////////////////////////////////////////////////
///////////External DTD in schema
/////////////////////////////////////////////////
    public void xtestSchemaED() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            //schemaFactory.setFeature(name, value);
            //schemaFactory.setProperty(name, value);
            URL url = Bkup_Bug7192390Test.class.getResource("Bug7192390_val.xsd");
            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema(url);
                Validator validator = schema.newValidator();
                validator.setErrorHandler(new ErrorHandler() {
                        public void error(SAXParseException exception) throws SAXException {
                                exception.printStackTrace();
                        }

                        public void fatalError(SAXParseException exception) throws SAXException {
                                exception.printStackTrace();
                        }

                        public void warning(SAXParseException exception) throws SAXException {
                                exception.printStackTrace();
                        }
                });
                validator.validate(new StreamSource(Bkup_Bug7192390Test.class.getResourceAsStream("Bug7192390_val.xml")));

        } catch (SAXException e) {
            e.printStackTrace();
            System.out.println(e.getMessage() );


        } catch (IOException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }    
/////////////////////////////////////////////////
///////////External Entity Reference (EER)
/////////////////////////////////////////////////
    /**
     * External Entity Reference, file access requested, file access granted by
     * default
     */
    public void xtestEER_file_default() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
//            parser.parse(new InputSource(new StringReader(_external_entity_remote)), new MyHandler());
            parser.parse(new InputSource(new StringReader(_external_entity_remote)), new DefaultHandler());
        } catch (Exception e) {
            e.printStackTrace();
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }
    /**
     * External Entity Reference, file access requested, file access not allowed
     */
    public void xtestEER_file_denied() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "http");
            parser.parse(new InputSource(new StringReader(_external_entity_remote)), new MyHandler());
            fail("Failure: file access requested but only http is allowed");
        } catch (Exception e) {
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"file\" access is not allowed") > -1) {
                //expected error
                System.out.println("file access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    /**
     * External Entity Reference, http access requested, but only file access is
     * allowed by default
     */
    public void xtestEER_http_default() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity_remote)), new DefaultHandler());
        } catch (Exception e) {
            e.printStackTrace();
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"remote\" access is not allowed") > -1) {
                //expected error
                System.out.println("remote access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    /**
     * External Entity Reference, http access requested, http access allowed
     */
    public void xtestEER_http_http() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "remote");
            parser.parse(new InputSource(new StringReader(_external_entity_remote)), new DefaultHandler());
        } catch (Exception e) {
            e.printStackTrace();
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"remote\" access is not allowed") > -1) {
                //expected error
                System.out.println("remote access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

/////////////////////////////////////////////////
///////////External DTD 
/////////////////////////////////////////////////
    /**
     * SAX
     */
    public void xtestLocalAllowed() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "local");
            parser.parse(new InputSource(new StringReader(_external_entity)), new MyHandler());
        } catch (Exception e) {
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteAllowed() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "remote");
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDeniedByDefault() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            e.printStackTrace();
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"remote\" access is not allowed") > -1) {
                //expected error
                System.out.println("remote access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDenied() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "local");
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"remote\" access is not allowed") > -1) {
                //expected error
                System.out.println("remote access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDenied_ignoreErr() {

        try {
            SAXParser parser = getSAXParser(false, false, false, IGNORE_ERROR_TRUE);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "local");
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new MyHandler());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    /**
     * DOM
     */
    public void xtestLocalAllowed_DOM() {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "file");
            DocumentBuilder docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity)));
        } catch (Exception e) {
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteAllowed_DOM() {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "http");
            DocumentBuilder docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDeniedByDefault_DOM() {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"remote\" access is not allowed") > -1) {
                //expected error
                System.out.println("remote access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDenied_DOM() {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "file");
            DocumentBuilder docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"remote\" access is not allowed") > -1) {
                //expected error
                System.out.println("remote access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDenied_ignoreErr_DOM() {

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "file");
            dbf.setFeature(IGNORE_EXTERNAL_ENTITY_ERROR, true);
            DocumentBuilder docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    /**
     * StAX
     */
    public void xtestLocalAllowed_StAX() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, "local");
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_entity));
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteAllowed_StAX() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, "remote");
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDeniedByDefault_StAX() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
        } catch (Exception e) {
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"remote\" access is not allowed") > -1) {
                //expected error
                System.out.println("remote access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDenied_StAX() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, "local");
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
        } catch (Exception e) {
            e.printStackTrace();
            String err = e.getMessage();
            if (err.indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else if (err.indexOf("External DTD: \"remote\" access is not allowed") > -1) {
                //expected error
                System.out.println("remote access not allowed");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestRemoteDenied_ignoreErr_StAX() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, "local");
            xif.setProperty(IGNORE_EXTERNAL_ENTITY_ERROR, Boolean.TRUE);
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }
//####current test
    /**
     * public identifier
     */
    public void testPublicIdentifier() {

        try {
            SAXParser parser = getSAXParser(false, false, false, IGNORE_ERROR_TRUE);
            parser.parse(new InputSource(new StringReader(_public_external_dtd)), new MyHandler());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * possibly read local file
     */
    public void xtestXXElocalfile() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity)), new MyHandler());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * can local, protected file be read when SM is present?
     */
    public void xtestXXElocalfile_sm() {
        System.out.println("Security Manager \n");
        System.setSecurityManager(new SecurityManager());
        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.parse(new InputSource(new StringReader(_external_entity)), new MyHandler());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //default = "local"

    public void xtestDefault() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
            parser.reset();
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
            fail("Failure: http not allowed. Should report error: ");
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("External Entity Reference: \"http\" protocol is not allowed.") > -1) {
                //expected failure
                System.out.println(e.getMessage());
                System.out.println("Success: http protocol not allowed.");
            } else {
                System.out.println("Failure: should report protocol is not allowed error");
                fail("Failure: should report protocol is not allowed error ");
            }
        }
    }

    public void xtestDefault_IgnoreError() {

        try {
            SAXParser parser = getSAXParser(false, false, false, true);
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Failure: http protocol not allowed, but the error should be ignored ");
        }
    }

    public void xtestSetHTTP() {

        try {
            SAXParser parser = getSAXParser(false, false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "local");
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    public void xtestSetSecureFeature() {

        try {
            SAXParser parser = getSAXParser(true, false, false, false);
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
            fail("Failure: should report protocol is not allowed error ");
        } catch (Exception e) {
            if (e.getMessage().indexOf("External Entity Reference: \"http\" protocol is not allowed.") > -1) {
                //expected failure
                System.out.println(e.getMessage());
                System.out.println("Success: http protocol not allowed.");
            } else {
                System.out.println("Failure: should report protocol is not allowed error");
                fail("Failure: should report protocol is not allowed error ");
            }
        }
    }
    //set to allow http after secure feature

    public void xtestSetSecureFeatureHttp() {

        try {
            SAXParser parser = getSAXParser(true, false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "remote");
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            if (e.getMessage().indexOf("Property 'http://java.sun.com/xml/jaxp/properties/accessExternalDTD' is not recognized.") > -1) {
                //expected before this patch
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }
    //set to disallow dtd: eternal-entity-protocol shall have no effect

    public void xtestSetDisallowDTD() {

        try {
            SAXParser parser = getSAXParser(false, true, false, false);
            try {
                parser.setProperty(ACCESS_EXTERNAL_DTD, "remote");
            } catch (org.xml.sax.SAXNotRecognizedException e) {
            }

            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
            fail("Failure: DTD not allowed");
        } catch (Exception e) {
            if (e.getMessage().indexOf("DOCTYPE is disallowed") > -1) {
                //expected DTD is disallowed
                System.out.println("Property accessExternalDTD not supported");
            } else {
                System.out.println("Failure:  " + e.getMessage());
                fail("Failure: " + e.getMessage());
            }
        }
    }

    //set to not to load external dtd for nonvalidating parser: eternal-entity-protocol shall have no effect
    public void xtestNotLoadExternalDTD() {

        try {
            SAXParser parser = getSAXParser(false, false, true, false);
            try {
                parser.setProperty(ACCESS_EXTERNAL_DTD, "remote");
            } catch (org.xml.sax.SAXNotRecognizedException e) {
            }

            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (FileNotFoundException ffe) {
            fail("Should not attempt to load external dtd");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failure:  " + e.getMessage());
            fail("Failure: " + e.getMessage());
        }
    }

    private static String XSL_INC_FILE = null;
  
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<book>"
            + "<chapter>"
            + "<title>Introduction</title>"
            + "<para>Paragraph 1</para>"
            + "<para>Paragraph 2</para>"
            + "</chapter>"
            + "</book>";

    public void xtestStylesheetPI1() {
        try {
            javax.xml.parsers.SAXParserFactory saxFactory =
                    javax.xml.parsers.SAXParserFactory.newInstance();


            saxFactory.setFeature(
                    javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING,
                    true);

            javax.xml.parsers.SAXParser parser = saxFactory.newSAXParser();
            org.xml.sax.XMLReader xmlReader = parser.getXMLReader();
            xmlReader.setEntityResolver(new org.xml.sax.EntityResolver() {
                public org.xml.sax.InputSource resolveEntity(
                        String publicId, String systemId) throws org.xml.sax.SAXException, java.io.IOException {
                    throw new org.xml.sax.SAXException(
                            "Will not resolve entities (for stylesheet)");
                }
            });

            javax.xml.transform.TransformerFactory factory =
                    javax.xml.transform.TransformerFactory.newInstance();

            factory.setURIResolver(new javax.xml.transform.URIResolver() {
                public javax.xml.transform.Source resolve(
                        String href, String base) throws javax.xml.transform.TransformerException {
                    throw new RuntimeException //javax.xml.transform.TransformerException
                            (
                            "Will not resolve URIs");
                }
            });

            factory.setFeature(
                    javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING,
                    true);
            javax.xml.transform.Transformer transformer = factory.newTransformer(
                    new javax.xml.transform.sax.SAXSource(
                    xmlReader,
                    new org.xml.sax.InputSource(new java.io.StringReader(XSL_INC_FILE))));

            transformer.transform(
                    new javax.xml.transform.stream.StreamSource(
                    new java.io.StringReader(SRC)),
                    new javax.xml.transform.stream.StreamResult(
                    System.out));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
