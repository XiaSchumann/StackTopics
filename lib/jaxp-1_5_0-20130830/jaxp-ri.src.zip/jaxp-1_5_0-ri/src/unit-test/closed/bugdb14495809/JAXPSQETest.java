package closed.bugdb14495809;

import java.io.*;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * @author huizhe.wang@oracle.com
 */
public class JAXPSQETest extends Bug7192390Base {

    private static String XSL_INC_FILE = null;
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<book>"
            + "<chapter>"
            + "<title>Introduction</title>"
            + "<para>Paragraph 1</para>"
            + "<para>Paragraph 2</para>"
            + "</chapter>"
            + "</book>";

    /**
     * Creates a new instance of StreamReader
     */
    public JAXPSQETest(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(JAXPSQETest.class);
    }
    private static final String PROPS_DTD_URI =
            "http://java.sun.com/dtd/properties.dtd";
    private static final String PROPS_DTD =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<!-- DTD for properties -->"
            + "<!ELEMENT properties ( comment?, entry* ) >"
            + "<!ATTLIST properties"
            + " version CDATA #FIXED \"1.0\">"
            + "<!ELEMENT comment (#PCDATA) >"
            + "<!ELEMENT entry (#PCDATA) >"
            + "<!ATTLIST entry "
            + " key CDATA #REQUIRED>";

//####current test

    
    /**
     * Test from jaxp sqe Product test
     * 
     * Although there's a Resolver, but since it implements org.xml.sax.helpers.XMLFilterImpl
     * which does nothing but pass through events by default, this test works similar
     * to without a resolver. External access therefore needs to be explictly granted.
     */
    public void testResolver() {

	XMLReader xmlReader = null;
        FileInputStream instream = null;
        InputSource is=null;

	MyEntityResolver eResolver=null;

        try {
	    SAXParser saxParser = SAXParserFactory.newInstance().newSAXParser();
	    xmlReader = saxParser.getXMLReader();	

	    eResolver = new MyEntityResolver();
	    xmlReader.setEntityResolver(eResolver);

            instream = new FileInputStream(JAXPSQETest.class.getResource("publish.xml").getPath());
            is = new InputSource(instream);
	    xmlReader.parse(is);
	    eResolver.flushNClose();

	} catch( Exception e) {
	    e.printStackTrace();
	}

    

    }
class MyEntityResolver extends XMLFilterImpl {

    BufferedWriter bWriter;

    MyEntityResolver() {
        super();

	String workDirPath = "jaxp-ri/src/unit-test/closed/bugdb14495809";

        try {
            bWriter = new BufferedWriter(new FileWriter(
				workDirPath + "/EntityResolver.out"));
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public InputSource resolveEntity(String publicid, String systemid) {

	InputSource is = null;
	String str = "In resolveEntity.." + " " + publicid + " " + systemid;
	try {
	    is = super.resolveEntity(publicid, systemid);
            bWriter.write( str, 0,str.length());
            bWriter.newLine();
	} catch (SAXException e) {
	    e.printStackTrace();
	} catch (IOException e) {
	    e.printStackTrace();
	}
	return is;
    }

    public void flushNClose() {
        try {
                bWriter.flush();
                bWriter.close();
        } catch (IOException e) {}
    }
}


    //-------------------------
    Document getLoadingDoc(InputSource in)
            throws SAXException, IOException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setIgnoringElementContentWhitespace(true);
        dbf.setValidating(true);
        dbf.setCoalescing(true);
        dbf.setIgnoringComments(true);
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            db.setEntityResolver(new Resolver());
            db.setErrorHandler(new EH());
            //InputSource is = new InputSource(in);
            return db.parse(in);
        } catch (ParserConfigurationException x) {
            throw new Error(x);
        }
    }

    private static class Resolver implements EntityResolver {

        public InputSource resolveEntity(String pid, String sid)
                throws SAXException {
            if (sid.indexOf("properties.dtd") > 0) {
                InputSource is;
                is = new InputSource(new StringReader(PROPS_DTD));
                is.setSystemId(PROPS_DTD_URI);
                return is;
            }
            throw new SAXException("Invalid system identifier: " + sid);
        }
    }

    private static class EH implements ErrorHandler {

        public void error(SAXParseException x) throws SAXException {
            throw x;
        }

        public void fatalError(SAXParseException x) throws SAXException {
            throw x;
        }

        public void warning(SAXParseException x) throws SAXException {
            throw x;
        }
    }
    private static URIResolver resolver = new URIResolver() {
        public Source resolve(String href, String base)
                throws TransformerException {
            System.out.println("resolving: " + href);
            return new StreamSource(this.getClass().getResourceAsStream(href));
        }
    };

    SAXParser getSAXParser(boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD, boolean notIncGeneralEntity, boolean notIncParameterEntity)
            throws ParserConfigurationException, SAXException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        if (secure) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        if (disallowDTD) {
            spf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, disallowDTD);
        }
        if (notLoadExternalDTD) {
            spf.setValidating(false);
            spf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
        }
        if (notIncGeneralEntity) {
            spf.setFeature(EXTERNAL_GENERAL_ENTITIES_FEATURE, false);
        }
        if (notIncParameterEntity) {
            spf.setFeature(EXTERNAL_PARAMETER_ENTITIES_FEATURE, false);
        }
        SAXParser parser = spf.newSAXParser();

        return parser;
    }
}
