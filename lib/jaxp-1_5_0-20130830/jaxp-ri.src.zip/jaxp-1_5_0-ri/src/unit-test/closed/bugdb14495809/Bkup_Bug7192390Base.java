/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.bugdb14495809;

import java.io.*;
import java.net.URL;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Bug6954738_Test;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * accessExternalDTD: an Oracle implementation property. Allow specifying the
 * method of accessing external DTD Value: local, remote; default is local Error
 * message: External DTD: [local or remote] access not allowed.
 *
 * Relationship with existing features:
 *
 * 1. FEATURE FOR SECURE PROCESSING If this feature is on, accessExternalDTD is
 * default to local only; However, it can overwrite the default if it is set
 * after the secure feature.
 *
 * 2. disallow-doctype-decl for SAX and DOM and SUPPORT_DTD for StAX If these
 * features are set, the accessExternalDTD feature has no effect
 *
 * 3. load-external-dtd if this feature is turned off for non-validating
 * parsing, the accessExternalDTD feature has no effect.
 *
 *
 * This change is required by CR 7192390.
 *
 * @author huizhe.wang@oracle.com
 */
public class Bkup_Bug7192390Base extends TestCase {

    public static final String ACCESS_EXTERNAL_DTD = "http://www.oracle.com/xml/jaxp/properties/accessExternalDTD";
    public static final String ACCESS_EXTERNAL_SCHEMA = "http://www.oracle.com/xml/jaxp/properties/accessExternalSchema";
    public static final String DISALLOW_DOCTYPE_DECL_FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
    public static final String LOAD_EXTERNAL_DTD_FEATURE = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
    public static final String EXTERNAL_GENERAL_ENTITIES_FEATURE = "http://xml.org/sax/features/external-general-entities";
    public static final String EXTERNAL_PARAMETER_ENTITIES_FEATURE = "http://xml.org/sax/features/external-parameter-entities";

    public static final String IGNORE_EXTERNAL_ENTITY_ERROR = "http://www.oracle.com/xml/jaxp/features/ignoreAccessExternalDTDError";
    public static final String SP_ACCESS_EXTERNAL_DTD = "jdk.xml.accessExternalDTD";
    public static final String SP_ACCESS_EXTERNAL_SCHEMA = "jdk.xml.accessExternalSchema";
    public static final String SP_ACCESS_EXTERNAL_STYLESHEET = "jdk.xml.accessExternalStylesheet";
    public static final boolean SECURE_PROCESSING_TRUE = true;
    public static final boolean SECURE_PROCESSING_FALSE = false;
    public static final boolean DISALLOWDTD_TRUE = true;
    public static final boolean DISALLOWDTD_FALSE = false;
    public static final boolean NOTLOADEXTERNALDTD_TRUE = true;
    public static final boolean NOTLOADEXTERNALDTD_FALSE = false;
    public static final boolean IGNORE_ERROR_TRUE = true;
    public static final boolean IGNORE_ERROR_FALSE = false;
    static final String ACCESS_DEFAULT = "file";
    static final String ACCESS_DEFAULT_WSECURE = "";
    final boolean DEBUG = false;
    String _external_dtd_file = getClass().getResource("toys2.xml").getPath();
    
    //http://10.229.188.203:8080/tests/bugdb14495809/
    /**
    final String _external_dtd_http = "<?xml version='1.0' encoding ='utf-8'?>"
            + "<!DOCTYPE properties SYSTEM \"http://java.sun.com/dtd/properties.dtd\">"
            + "<properties>"
            + "<comment>java.util.Properties</comment>"
            + "<entry key=\"key1\">&mkm;</entry>"
            + "</properties>";
    */
    final String _external_dtd_http = "<?xml version='1.0' encoding ='utf-8'?>"
            + "<!DOCTYPE properties SYSTEM \"http://10.229.188.203:8080/tests/bugdb14495809/properties.dtd\">"
            + "<properties>"
            + "<comment>java.util.Properties</comment>"
            + "<entry key=\"key1\">&mkm;</entry>"
            + "</properties>";
    final String _external_entity = "<?xml version='1.0' encoding ='utf-8'?>"
            + "<!DOCTYPE document "
            + "[ <!ENTITY foo SYSTEM \"C:\\Test\\test.txt\"> ]"
            + ">"
            + "<document>"
            + "<name>&foo;</name>"
            + "</document>";
    String _external_entity_remote;
    final String _public_external_dtd = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
            + "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\""
            + " \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\" ["
            + "<!-- an internal subset can be embedded here -->"
            + "]>"
            + "<!-- the XHTML document body starts here-->"
            + "<html>"
            + "..."
            + "</html>";

    /**
     * Creates a new instance of StreamReader
     */
    public Bkup_Bug7192390Base(String name) {
        super(name);
    }

    @Override
    protected void setUp() {
        _external_entity_remote = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder "
                + "[ <!ENTITY item SYSTEM \""
                + Bkup_Bug7192390Base.class.getResource("Bug7192390_item.xml").getPath()
                + "\"> ]"
                + ">"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "&item;"
                + "</SupplierOrder>";

    }

    SAXParser getSAXParser(boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD, boolean ignoreError)
            throws ParserConfigurationException, SAXException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        if (secure) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        if (disallowDTD) {
            spf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, disallowDTD);
        }
        if (notLoadExternalDTD) {
            spf.setValidating(false);
            spf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
        }
        if (ignoreError) {
            spf.setFeature(IGNORE_EXTERNAL_ENTITY_ERROR, ignoreError);
        }
        SAXParser parser = spf.newSAXParser();

        return parser;
    }

    void externalDTDDenied(Exception e, String protocol) {
        String err = e.getMessage();
        if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
            //expected before this patch
            System.out.println("Property accessExternalDTD not supported");
        } else if (err.indexOf("External DTD: \"" + protocol + "\" access is not allowed") > -1) {
            //expected error
            System.out.println(protocol + " access not allowed");
        } else {
            System.out.println("Failure:  " + e.getMessage());
            fail("Failure: " + e.getMessage());
        }
    }

    void externalDTDAllowed(Exception e) {
        String err = e.getMessage();
        if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
            //expected before this patch
            System.out.println("Property accessExternalDTD not supported");
        } else if (err.indexOf("Connection timed out: connect") > -1) {
            //sometimes we get this error when http://java.sun.com/dtd/properties.dtd is not accessible
            System.out.println("Connection timed out: connect");
        } else {
            System.out.println("Failure:  " + e.getMessage());
            fail("Failure: " + e.getMessage());
        }
    }

    void print(String s) {
        if (DEBUG) {
            System.out.println(s);
        }
    }

    public class MyHandler extends DefaultHandler2 implements ErrorHandler {

        StringBuffer currentValue = new StringBuffer();

        public void startDocument() throws SAXException {
        }

        public void endDocument() throws SAXException {
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            currentValue.delete(0, currentValue.length());
            try {
                System.out.println("Element: " + uri + ":" + localName + " " + qName);
            } catch (Exception e) {
                throw new SAXException(e);
            }

        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
            System.out.println("Text: \n" + currentValue.toString() + "\n");
            System.out.println("End Element: " + uri + ":" + localName + " " + qName);
        }

        public void characters(char ch[], int start, int length) throws SAXException {
            currentValue.append(ch, start, length);
        }

        public void internalEntityDecl(String name, String value) throws SAXException {
            super.internalEntityDecl(name, value);
            System.out.println("internalEntityDecl() is invoked for entity : " + name);
        }

        public void externalEntityDecl(String name, String publicId, String systemId) throws SAXException {
            super.externalEntityDecl(name, publicId, systemId);
            System.out.println("externalEntityDecl() is invoked for entity : " + name);
        }

        public void startEntity(String name) throws SAXException {
            super.startEntity(name);
//		System.out.println("startEntity() is invoked for entity : " + name) ;
        }

        public void endEntity(String name) throws SAXException {
            super.endEntity(name);
//		System.out.println("endEntity() is invoked for entity : " + name) ;
        }

        public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
            System.out.println("resolveEntity(publicId, systemId) is invoked");
            return super.resolveEntity(publicId, systemId);
        }

        public InputSource resolveEntity(String name, String publicId, String baseURI, String systemId) throws SAXException, IOException {
            System.out.println("resolveEntity(name, publicId, baseURI, systemId) is invoked");
            return super.resolveEntity(name, publicId, baseURI, systemId);
        }

        public InputSource getExternalSubset(String name, String baseURI) throws SAXException, IOException {
            System.out.println("getExternalSubset() is invoked");
            return super.getExternalSubset(name, baseURI);
        }
    }
}
