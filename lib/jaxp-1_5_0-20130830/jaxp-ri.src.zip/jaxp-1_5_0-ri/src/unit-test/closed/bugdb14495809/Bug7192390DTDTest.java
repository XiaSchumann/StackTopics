/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.bugdb14495809;

import java.io.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * http://www.oracle.com/xml/jaxp/properties/accessExternalDTD: restrict access
 * to external DTDs, external Entity References to the protocols specified.
 *
 * Relationship with existing features:
 *
 * 1. FEATURE FOR SECURE PROCESSING If this feature is on, accessExternalDTD is
 * default to local only; However, it can overwrite the default if it is set
 * after the secure feature.
 *
 * 2. disallow-doctype-decl for SAX and DOM and SUPPORT_DTD for StAX If these
 * features are set, the accessExternalDTD feature has no effect
 *
 * 3. load-external-dtd if this feature is turned off for non-validating
 * parsing, the accessExternalDTD feature has no effect.
 *
 *
 * This change is required by CR 7192390.
 *
 * @author huizhe.wang@oracle.com
 */
public class Bug7192390DTDTest extends Bug7192390Base {

    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390DTDTest(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bug7192390DTDTest.class);
    }

    /////////////////////////////////////////////////
    ///////////External DTD 
    /////////////////////////////////////////////////
    /**
     * SAX
     */
    /**
     * For JDK7 and 8, there's no restriction by default
     */
    public void testSAXDefault() {

        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
            checkDefaultBehavior(TEST_EXTERNALDTD, "testSAXDefault", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
            checkDefaultBehavior(TEST_EXTERNALDTD, "testSAXDefault", "file");
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, "file");
        }
    }

    /**
     * System Property javax.xml.accessExternalDTD may be used to override the
     * default
     */
    public void testSAXSP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            SAXParser parser = getSAXParser(false, false, false);
            //file access is allowed
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
            parser.reset();
            //http access is allowed
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * JAXP Property always takes preference
     */
    public void testJAXPProperty() {
        SAXParser parser = null;
        
        try {
            parser = getSAXParser(false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            
            //property is set to allow file access only
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        }
        try {
            //SAXParser is reset to the same state as when it was created with SAXParserFactory.newSAXParser().
            parser.reset();
            
            //property such as ACCESS_EXTERNAL_DTD would need to be set explicitly after reset
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            //http access should be denied
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testJAXPProperty", PROTOCOL_HTTP);
        } catch (Exception e) {
            denyExternalAccess(e, PROTOCOL_HTTP);
        }
    }

    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testSAX_Secure() {
        try {
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
            checkFSPBehavior(TEST_EXTERNALDTD, "testSAX_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testSAXSP_Secure() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * JAXP properties always take preference
     */
    public void testSAXSP_SecureOR() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            //secure processing denies external access
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            //reset ACCESS_EXTERNAL_DTD to allow access
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * if disallow DTD is specified, protocol restriction has no effect
     */
    public void testSAXDefault_disallowDTD() {

        try {
            SAXParser parser = getSAXParser(false, DISALLOWDTD_TRUE, false);
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testSAXDefault_disallowDTD", PROTOCOL_HTTP);
        } catch (Exception e) {
            //e.printStackTrace();
            disallowDTD(e);
        }
        try {
            SAXParser parser = getSAXParser(false, DISALLOWDTD_TRUE, false);
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testSAXDefault_disallowDTD", PROTOCOL_FILE);
        } catch (Exception e) {
            //e.printStackTrace();
            disallowDTD(e);
        }
    }

    /**
     * if http://apache.org/xml/features/nonvalidating/load-external-dtd is
     * false, the access restriction should have no effect
     */
    public void testSAXDefault_notLoadDTD() {

        try {
            SAXParser parser = getSAXParser(false, false, NOTLOADEXTERNALDTD_TRUE);
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testSAXDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            SAXParser parser = getSAXParser(false, false, NOTLOADEXTERNALDTD_TRUE);
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testSAXDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    public void testSAXAccess_notLoadDTD() {

        try {
            SAXParser parser = getSAXParser(false, false, NOTLOADEXTERNALDTD_TRUE);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "x");
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testSAXAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            SAXParser parser = getSAXParser(false, false, NOTLOADEXTERNALDTD_TRUE);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "x");
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testSAXAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    /**
     * public identifier. default behavior
     */
    public void testPublicIdentifier() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.parse(new InputSource(new StringReader(_public_external_dtd)), new MyHandler());
            checkDefaultBehavior(TEST_EXTERNALDTD, "testPublicIdentifier", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }

    public void testPublicIdentifierSP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.parse(new InputSource(new StringReader(_public_external_dtd)), new MyHandler());

        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testPublicIdentifierJAXPProperty() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
            parser.parse(new InputSource(new StringReader(_public_external_dtd)), new MyHandler());

        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testPublicIdentifier_Secure() {
        try {
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            parser.parse(new InputSource(new StringReader(_public_external_dtd)), new DefaultHandler());
            checkFSPBehavior(TEST_EXTERNALDTD, "testPublicIdentifier_Secure", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testPublicIdentifierSP_Secure() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            parser.parse(new InputSource(new StringReader(_public_external_dtd)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * JAXP properties always take preference
     */
    public void testPublicIdentifierSP_SecureOR() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            //secure processing denies external access
            SAXParser parser = getSAXParser(SECURE_PROCESSING_TRUE, false, false);
            //reset ACCESS_EXTERNAL_DTD to allow access
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
            parser.parse(new InputSource(new StringReader(_public_external_dtd)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * DOM -- similar tests as SAX
     */
    public void testDOMDefault() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDOMDefault", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDOMDefault", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    public void testDOMSP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testDOMJAXPProperty() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "file, http");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }
    public void testDOMJAXPPropertySFP() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "file, http");
            // setting FSP should not change anything since ACCESS_EXTERNAL_DTD
            // takes precedence
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
            success("testDOMJAXPPropertySFP passed");
        } catch (Exception e) {
            allowExternalAccess("testDOMJAXPPropertySFP", e);
        }

        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
            success("testDOMJAXPPropertySFP passed");
        } catch (Exception e) {
            allowExternalAccess("testDOMJAXPPropertySFP", e);
        }
    }
    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testDOM_Secure() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
            checkFSPBehavior(TEST_EXTERNALDTD, "testDOM_Secure", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }

        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
            checkFSPBehavior(TEST_EXTERNALDTD, "testDOM_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testDOMSP_Secure() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }

        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * JAXP properties always take preference
     */
    public void testDOM_SecureOR() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "file, http");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testDOMDefault_notLoadDTD() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    public void testDOMAccess_notLoadDTD() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "x");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    /**
     * StAX
     */
    public void testStAXDefault() {
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
            readDTD(xsr);
            checkDefaultBehavior(TEST_EXTERNALDTD, "testStAXDefault", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(_external_dtd_file, new FileInputStream(new File(_external_dtd_file)));
            readDTD(xsr);
            checkDefaultBehavior(TEST_EXTERNALDTD, "testStAXDefault", PROTOCOL_FILE);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    public void testStAXSP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
            readDTD(xsr);
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(_external_dtd_file, new FileInputStream(new File(_external_dtd_file)));
            readDTD(xsr);
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testStAXJAXPProperties() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "");

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
            readDTD(xsr);
        } catch (Exception e) {
            allowExternalAccess(e);
        }

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(ACCESS_EXTERNAL_DTD, "file");
            XMLStreamReader xsr = xif.createXMLStreamReader(_external_dtd_file, new FileInputStream(new File(_external_dtd_file)));
            readDTD(xsr);
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testStAXDefault_notLoadDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        } catch (Exception e) {
            ignoreAccessRestriction("testStAXDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
            readDTD(xsr);
        } catch (Exception e) {
            ignoreAccessRestriction("testStAXDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    public void testStAXAccess_notLoadDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
            xif.setProperty(ACCESS_EXTERNAL_DTD, "x");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(_external_dtd_http));
            readDTD(xsr);
        } catch (Exception e) {
            ignoreAccessRestriction("testStAXAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    /////////////////////////////////////////////////
    ///////////External DTD in XSD
    /////////////////////////////////////////////////
    public void testDTDinXSD() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390DTDTest.class.getResourceAsStream("Bug7192390_valWDTD.xsd")));
            Schema schema = schemaFactory.newSchema(new StreamSource(new StringReader(_xsd_external_dtd_http)));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDTDinXSD", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }

    public void testDTDinXSD_SysProperty() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(new StringReader(_xsd_external_dtd_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void testDTDinXSD_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            Schema schema = schemaFactory.newSchema(new StreamSource(new StringReader(_xsd_external_dtd_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }
    public void testDTDinXSD_SAX_JAXPProperty_allow() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");

            SAXSource schemaSource = new SAXSource(new InputSource(new StringReader(_xsd_external_dtd_http)));
            Schema schema = schemaFactory.newSchema(schemaSource);

        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    public void testDTDinXSD_SAX_JAXPProperty_deny() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "");

            SAXSource schemaSource = new SAXSource(new InputSource(new StringReader(_xsd_external_dtd_http)));
            Schema schema = schemaFactory.newSchema(schemaSource);
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testDTDinXSD_SAX_JAXPProperty_deny", PROTOCOL_HTTP);

        } catch (Exception e) {
            denyExternalAccess(e, PROTOCOL_HTTP);
        }
    }

    public void testDTDinXSD_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(ACCESS_EXTERNAL_DTD, "file,http");
            // Setting SFP shouldn't change anything since ACCESS_EXTERNAL_DTD already set.
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            Schema schema = schemaFactory.newSchema(new StreamSource(new StringReader(_xsd_external_dtd_http)));
            success("testDTDinXSD_JAXPPropertySFP passed");
        } catch (Exception e) {
            allowExternalAccess("testDTDinXSD_JAXPPropertySFP", e);
        }
    }

    /**
     * Setting FSP explicitly:
     * JDK7: no effect
     * JDK8: override the default, allow no access
     */
    public void testDTDinXSD_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new StringReader(_xsd_external_dtd_http)));
            checkFSPBehavior(TEST_EXTERNALDTD, "testDTDinXSD_Secure", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }
    
    /**
     * System property will override that set by FSP
     */
    public void testDTDinXSDSP_Secure() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, PROTOCOL_HTTP);
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new StringReader(_xsd_external_dtd_http)));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * The access restriction should be ignored if the inputsource is created by
     * a resolver. 
     */      
    public void testDOM_wEntity_JAXPProperty() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "");
            docBuilder = dbf.newDocumentBuilder();
            docBuilder.setEntityResolver(new myExternalDTDResolver());
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOM_wEntity_JAXPProperty", e, "should not throw error since inputsource is created by a resolver.", null);
        }

        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOM_wEntity_JAXPProperty", e, "should not throw error since inputsource is created by a resolver.", null);
        }
    }
        
}
