package closed.bugdb14495809;

import java.io.StringReader;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * author huizhe.wangoracle.com
 */
public class Bug7192390Test2 extends TestCase {
    public static final String ACCESS_XSL_PI = "http://java.sun.com/xml/jaxp/properties/accessXSLPI";

    private static final String XSL_PI_FILE = ""
            + "<?xml version='1.0'?>"
            + "<?xml-stylesheet href=\"../target.xsl\" type=\"text/xml\"?>"
            + "<xsl:stylesheet "
            + "    xmlns:xsl='http://www.w3.org/1999/XSL/Transform' "
            + "    version='1.0'>"
            + "</xsl:stylesheet> ";
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<doc/>";

    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390Test2(String name) {
        super(name);
    }

    /**
     * param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bug7192390Test2.class);
    }

    /**
     * PI
     */
    public void testStylesheetPI_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Transformer transformer = factory.newTransformer(new StreamSource(new StringReader(XSL_PI_FILE)));
            transformer.transform(new StreamSource(new StringReader(SRC)), new StreamResult(System.out));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
    public void testStylesheetPI_FileDenied() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(ACCESS_XSL_PI, "");
            Transformer transformer = factory.newTransformer(new StreamSource(new StringReader(XSL_PI_FILE)));
            transformer.transform(new StreamSource(new StringReader(SRC)), new StreamResult(System.out));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
    public void xtestStylesheetPI1() {
        try {
            javax.xml.parsers.SAXParserFactory saxFactory =
                    javax.xml.parsers.SAXParserFactory.newInstance();


            saxFactory.setFeature(
                    javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING,
                    true);

            javax.xml.parsers.SAXParser parser = saxFactory.newSAXParser();
            org.xml.sax.XMLReader xmlReader = parser.getXMLReader();
            xmlReader.setEntityResolver(new org.xml.sax.EntityResolver() {
                public org.xml.sax.InputSource resolveEntity(
                        String publicId, String systemId) throws org.xml.sax.SAXException, java.io.IOException {
                    throw new org.xml.sax.SAXException(
                            "Will not resolve entities (for stylesheet)");
                }
            });

            javax.xml.transform.TransformerFactory factory =
                    javax.xml.transform.TransformerFactory.newInstance();

            factory.setURIResolver(new javax.xml.transform.URIResolver() {
                public javax.xml.transform.Source resolve(
                        String href, String base) throws javax.xml.transform.TransformerException {
                    throw new RuntimeException //javax.xml.transform.TransformerException
                            (
                            "Will not resolve URIs");
                }
            });

            factory.setFeature(
                    javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING,
                    true);
            javax.xml.transform.Transformer transformer = factory.newTransformer(
                    new javax.xml.transform.sax.SAXSource(
                    xmlReader,
                    new org.xml.sax.InputSource(new java.io.StringReader(XSL_PI_FILE))));

            transformer.transform(
                    new javax.xml.transform.stream.StreamSource(
                    new java.io.StringReader(SRC)),
                    new javax.xml.transform.stream.StreamResult(
                    System.out));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
