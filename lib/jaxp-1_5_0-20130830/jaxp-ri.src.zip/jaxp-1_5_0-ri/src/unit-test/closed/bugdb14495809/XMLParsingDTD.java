package closed.bugdb14495809;

import java.io.*;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author huizhe.wang@oracle.com
 */
public class XMLParsingDTD extends Bug7192390Base {

    private static String XSL_INC_FILE = null;
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<book>"
            + "<chapter>"
            + "<title>Introduction</title>"
            + "<para>Paragraph 1</para>"
            + "<para>Paragraph 2</para>"
            + "</chapter>"
            + "</book>";

    /**
     * Creates a new instance of StreamReader
     */
    public XMLParsingDTD(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(XMLParsingDTD.class);
    }
    private static final String PROPS_DTD_URI =
            "http://java.sun.com/dtd/properties.dtd";
    private static final String PROPS_DTD =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<!-- DTD for properties -->"
            + "<!ELEMENT properties ( comment?, entry* ) >"
            + "<!ATTLIST properties"
            + " version CDATA #FIXED \"1.0\">"
            + "<!ELEMENT comment (#PCDATA) >"
            + "<!ELEMENT entry (#PCDATA) >"
            + "<!ATTLIST entry "
            + " key CDATA #REQUIRED>";

    String _unsafexml_wEntity = getClass().getResource("unsafe.xml").getPath();
    
    
    public void xtestDOM_disallowDTD() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, true);
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "x");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            e.printStackTrace();
            //ignoreAccessRestriction("testDOMDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            e.printStackTrace();
            //ignoreAccessRestriction("testDOMDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

//####current test
    
    
    public void xtestDOM_notLoadExternalDTD() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "x");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMDefault_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }
    
    public void testDOM_notExpandEntity() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setExpandEntityReferences(true);
//            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "x");
            docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(_unsafexml_wEntity);
            printDOMTree(document);
        } catch (Exception e) {
            e.printStackTrace();
            //ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }

    }        
    /**
     * not expand entity, but parameter entity is still resolved?
     */
    
    public void xtestDOM_notExpandEntity_parameter() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setExpandEntityReferences(false);
            dbf.setAttribute(ACCESS_EXTERNAL_DTD, "x");
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_parameter_entity_http)));
            printDOMTree(document);
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_parameter_entity_file)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }            
    public void xtestDOM_ignoreDTD_resolver() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            docBuilder = dbf.newDocumentBuilder();
            docBuilder.setEntityResolver(new EntityResolver() {
                @Override
                public InputSource resolveEntity(String publicId, String systemId)
                        throws SAXException, IOException {
                    //ignore DTD
                    return new InputSource(new StringReader(""));
                }
            });
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_resolver)));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDOM_wEntityResolver_Default", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }
    

    //-------------------------
    Document getLoadingDoc(InputSource in)
            throws SAXException, IOException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setIgnoringElementContentWhitespace(true);
        dbf.setValidating(true);
        dbf.setCoalescing(true);
        dbf.setIgnoringComments(true);
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            db.setEntityResolver(new Resolver());
            db.setErrorHandler(new EH());
            //InputSource is = new InputSource(in);
            return db.parse(in);
        } catch (ParserConfigurationException x) {
            throw new Error(x);
        }
    }

    private static class Resolver implements EntityResolver {

        public InputSource resolveEntity(String pid, String sid)
                throws SAXException {
            if (sid.indexOf("properties.dtd") > 0) {
                InputSource is;
                is = new InputSource(new StringReader(PROPS_DTD));
                is.setSystemId(PROPS_DTD_URI);
                return is;
            }
            throw new SAXException("Invalid system identifier: " + sid);
        }
    }

    private static class EH implements ErrorHandler {

        public void error(SAXParseException x) throws SAXException {
            throw x;
        }

        public void fatalError(SAXParseException x) throws SAXException {
            throw x;
        }

        public void warning(SAXParseException x) throws SAXException {
            throw x;
        }
    }
    private static URIResolver resolver = new URIResolver() {
        public Source resolve(String href, String base)
                throws TransformerException {
            System.out.println("resolving: " + href);
            return new StreamSource(this.getClass().getResourceAsStream(href));
        }
    };

    SAXParser getSAXParser(boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD, boolean notIncGeneralEntity, boolean notIncParameterEntity)
            throws ParserConfigurationException, SAXException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        if (secure) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        if (disallowDTD) {
            spf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, disallowDTD);
        }
        if (notLoadExternalDTD) {
            spf.setValidating(false);
            spf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
        }
        if (notIncGeneralEntity) {
            spf.setFeature(EXTERNAL_GENERAL_ENTITIES_FEATURE, false);
        }
        if (notIncParameterEntity) {
            spf.setFeature(EXTERNAL_PARAMETER_ENTITIES_FEATURE, false);
        }
        SAXParser parser = spf.newSAXParser();

        return parser;
    }
}
