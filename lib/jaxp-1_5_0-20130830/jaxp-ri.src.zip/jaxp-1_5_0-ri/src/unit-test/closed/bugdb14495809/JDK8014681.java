package closed.bugdb14495809;

import java.io.*;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author huizhe.wang@oracle.com
 */
public class JDK8014681 extends Bug7192390Base {

    private static String XSL_INC_FILE = null;
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<book>"
            + "<chapter>"
            + "<title>Introduction</title>"
            + "<para>Paragraph 1</para>"
            + "<para>Paragraph 2</para>"
            + "</chapter>"
            + "</book>";

    /**
     * Creates a new instance of StreamReader
     */
    public JDK8014681(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(JDK8014681.class);
    }
    private static final String PROPS_DTD_URI =
            "http://java.sun.com/dtd/properties.dtd";
    private static final String PROPS_DTD =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<!-- DTD for properties -->"
            + "<!ELEMENT properties ( comment?, entry* ) >"
            + "<!ATTLIST properties"
            + " version CDATA #FIXED \"1.0\">"
            + "<!ELEMENT comment (#PCDATA) >"
            + "<!ELEMENT entry (#PCDATA) >"
            + "<!ATTLIST entry "
            + " key CDATA #REQUIRED>";

//####current test
    //### DTDTest ###/
    /**
     * JAXP Property always takes preference
     */
    public void xtestJAXPProperty() {
        SAXParser parser = null;
        
        try {
            parser = getSAXParser(false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            
            //property is set to allow file access only
            parser.parse(new File(_external_dtd_file), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        }
        try {
            //SAXParser is reset to the same state as when it was created with SAXParserFactory.newSAXParser().
            parser.reset();
            
            //property such as ACCESS_EXTERNAL_DTD would need to be set explicitly after reset
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            //http access should be denied
            parser.parse(new InputSource(new StringReader(_external_dtd_http)), new DefaultHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testJAXPProperty", PROTOCOL_HTTP);
        } catch (Exception e) {
            denyExternalAccess(e, PROTOCOL_HTTP);
        }
    }

    //### EntityTest ###/
    /**
     * JAXP Property always takes preference
     */
    public void xtestEER_JAXPProperty() {
        SAXParser parser = null;
        try {
            parser = getSAXParser(false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            
            //file access is allowed by the property
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        }
        try {
            //SAXParser is reset to the same state as when it was created with SAXParserFactory.newSAXParser().
            parser.reset();
            
            //property such as ACCESS_EXTERNAL_DTD would need to be set explicitly after reset
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            //http access should be denied
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testEER_JAXPProperty", PROTOCOL_HTTP);
        } catch (Exception e) {
            denyExternalAccess(e, PROTOCOL_HTTP);
        }
    }    
    public void xtestEER_EGEF() {
        SAXParser parser = null;
        try {
            parser = getSAXParser(false, false, false, NOTINCGENENTITY_TRUE, false);
            //file access is allowed
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            parser.parse(new InputSource(new StringReader(_external_entity_file)), new DefaultHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testEER_EGEF", e, "if EXTERNAL_GENERAL_ENTITIES_FEATURE is set to false, the access restriction should have no effect", null);
        }
        try {
            //SAXParser is reset to the same state as when it was created with SAXParserFactory.newSAXParser().
            parser.reset();            
            //properties such as ACCESS_EXTERNAL_DTD need to be set explicitly after reset
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            //http not allowed by access property, however it has no effect since external entities are not resolved
            parser.parse(new InputSource(new StringReader(_external_entity_http)), new DefaultHandler());
            success("testEER_EGEF passed");
        } catch (Exception e) {
            ignoreAccessRestriction("testEER_EGEF", e, "if EXTERNAL_GENERAL_ENTITIES_FEATURE is set to false, the access restriction should have no effect", null);
        }
    }    
    //### ParameterEntityTest ###/
    /**
     * JAXP Property always takes preference
     */
    public void xtestEPEF_JAXPProperty() {
        SAXParser parser = null;
        try {
            parser = getSAXParser(false, false, false, false, false);
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            //file access is allowed

            //parser.parse(this.getClass().getResource("toys2.xml").getFile(), new DefaultHandler());
            parser.parse(new InputSource(new StringReader(_external_parameter_entity_file)), new MyHandler());
        } catch (Exception e) {
            allowExternalAccess(e);
        }
        try {
            //SAXParser is reset to the same state as when it was created with SAXParserFactory.newSAXParser().
            parser.reset();
            
            //property such as ACCESS_EXTERNAL_DTD would need to be set explicitly after reset
            parser.setProperty(ACCESS_EXTERNAL_DTD, "file");
            //http access should be denied
            parser.parse(new InputSource(new StringReader(_external_parameter_entity_http)), new MyHandler());
            reportFailToDenyAccess(TEST_EXTERNALDTD, "testEPEF_JAXPProperty", PROTOCOL_HTTP);
        } catch (Exception e) {
            denyExternalAccess(e, PROTOCOL_HTTP);
        }
    }
    public void testEPEF_EPEF() {
        SAXParser parser = null;
        try {
            parser = getSAXParser(false, false, false, false, NOTINCPARAMETERENTITY_TRUE);
            //file access is allowed
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            parser.parse(new InputSource(new StringReader(_external_parameter_entity_file)), new MyHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testEER_EGEF", e, "if EXTERNAL_GENERAL_ENTITIES_FEATURE is set to false, the access restriction should have no effect", "quantity");
        }
        try {
            //SAXParser is reset to the same state as when it was created with SAXParserFactory.newSAXParser().
            parser.reset();            
            //properties such as ACCESS_EXTERNAL_DTD need to be set explicitly after reset
            parser.setProperty(ACCESS_EXTERNAL_DTD, PROTOCOL_FILE);
            //http not allowed by access property, however it has no effect since external entities are not resolved
            parser.parse(new InputSource(new StringReader(_external_parameter_entity_http)), new MyHandler());
        } catch (Exception e) {
            ignoreAccessRestriction("testEPEF_EPEF", e, "if EXTERNAL_PARAMETER_ENTITIES_FEATURE is set to false, the access restriction should have no effect", "quantity");

        }
    }
    
    //-------------------------
    Document getLoadingDoc(InputSource in)
            throws SAXException, IOException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setIgnoringElementContentWhitespace(true);
        dbf.setValidating(true);
        dbf.setCoalescing(true);
        dbf.setIgnoringComments(true);
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            db.setEntityResolver(new Resolver());
            db.setErrorHandler(new EH());
            //InputSource is = new InputSource(in);
            return db.parse(in);
        } catch (ParserConfigurationException x) {
            throw new Error(x);
        }
    }

    private static class Resolver implements EntityResolver {

        public InputSource resolveEntity(String pid, String sid)
                throws SAXException {
            if (sid.indexOf("properties.dtd") > 0) {
                InputSource is;
                is = new InputSource(new StringReader(PROPS_DTD));
                is.setSystemId(PROPS_DTD_URI);
                return is;
            }
            throw new SAXException("Invalid system identifier: " + sid);
        }
    }

    private static class EH implements ErrorHandler {

        public void error(SAXParseException x) throws SAXException {
            throw x;
        }

        public void fatalError(SAXParseException x) throws SAXException {
            throw x;
        }

        public void warning(SAXParseException x) throws SAXException {
            throw x;
        }
    }
    private static URIResolver resolver = new URIResolver() {
        public Source resolve(String href, String base)
                throws TransformerException {
            System.out.println("resolving: " + href);
            return new StreamSource(this.getClass().getResourceAsStream(href));
        }
    };

    SAXParser getSAXParser(boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD, boolean notIncGeneralEntity, boolean notIncParameterEntity)
            throws ParserConfigurationException, SAXException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        if (secure) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        if (disallowDTD) {
            spf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, disallowDTD);
        }
        if (notLoadExternalDTD) {
            spf.setValidating(false);
            spf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
        }
        if (notIncGeneralEntity) {
            spf.setFeature(EXTERNAL_GENERAL_ENTITIES_FEATURE, false);
        }
        if (notIncParameterEntity) {
            spf.setFeature(EXTERNAL_PARAMETER_ENTITIES_FEATURE, false);
        }
        SAXParser parser = spf.newSAXParser();

        return parser;
    }
}
