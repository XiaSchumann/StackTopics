package closed.bugdb14495809;

import java.io.StringReader;
import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import junit.textui.TestRunner;
import org.xml.sax.InputSource;

/**
 * Tests for XSL PI, Document() function, Import and Include
 *
 * author huizhe.wang@oracle.com
 */
public class Bug7192390_XSLT_Test extends Bug7192390Base {

    private static String XSL_INC_FILE = null;
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<book>"
            + "<chapter>"
            + "<title>Introduction</title>"
            + "<para>Paragraph 1</para>"
            + "<para>Paragraph 2</para>"
            + "</chapter>"
            + "</book>";
    private static URIResolver resolver = new URIResolver() {
        public Source resolve(String href, String base)
                throws TransformerException {
            System.out.println("resolving: " + href);
            return new StreamSource(this.getClass().getResourceAsStream(href));
        }
    };

    /**
     * Creates a new instance of StreamReader
     */
    public Bug7192390_XSLT_Test(String name) {
        super(name);
    }

    /**
     * param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(Bug7192390_XSLT_Test.class);
    }

    @Override
    protected void setUp() {
        super.setUp();

        XSL_INC_FILE = ""
                + "<?xml version='1.0'?>"
                + "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"1.0\">"
                + "<xsl:include href=\""
                + Bug7192390_XSLT_Test.class.getResource("Bug7192390_XSLInclude.xsl").getPath()
                + "\"/>"
                + "<xsl:template match=\"para\">"
                + "<p><xsl:apply-templates/></p>"
                + "</xsl:template>"
                + "</xsl:stylesheet> ";
        XSL_INC_FILE = ""
                + "<?xml version='1.0'?>"
                + "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"1.0\">"
                + "<xsl:include href=\"Bug7192390_XSLInclude.xsl\"/>"
                + "<xsl:template match=\"para\">"
                + "<p><xsl:apply-templates/></p>"
                + "</xsl:template>"
                + "</xsl:stylesheet> ";

    }

    /////////////////////////////////////////////////
    ///////////Stylesheet Processing Instruction
    /////////////////////////////////////////////////
    /**
     * all access is allowed by default
     */
    public void xtestStylesheetPI_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            fail(e.toString());
        }
    }

    /**
     * all access is allowed by default
     */
    public void xtestStylesheetPI_httpDeniedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            StreamSource xslSource = new StreamSource(new StringReader(_xsl_pi_xslhttp));
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
            checkDefaultBehavior(TEST_EXTERNALSTYLESHEET, "testStylesheetPI_httpDeniedByDefault", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALSTYLESHEET, e, "http");
        }
    }

    /**
     * Setting FSP explicitly: JDK7: no effect JDK8: override the default, allow
     * no access
     */
    public void xtestStylesheetPI_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
            checkFSPBehavior(TEST_EXTERNALDTD, "testStylesheetPI_secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void xtestStylesheetPI_secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_STYLESHEET, "file,http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        }
    }

    public void xtestStylesheetPI_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_STYLESHEET, "file,http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        }
    }

    /**
     * jaxp property will take preference
     */
    public void xtestStylesheetPI_Override() {
        System.setProperty(SP_ACCESS_EXTERNAL_STYLESHEET, "file,http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setAttribute(ACCESS_EXTERNAL_STYLESHEET, "");
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
            reportFailToDenyAccess(TEST_EXTERNALSTYLESHEET, "testStylesheetPI_Override", PROTOCOL_FILE);
        } catch (Exception e) {
            denyExternalAccess(e, "file");
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        }
    }

    public void xtestStylesheetPI_JAXPProperty() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(ACCESS_EXTERNAL_STYLESHEET, "all");
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLPI.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    public void xtestInclude_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            fail(e.toString());
        }
    }

    /**
     * Setting FSP explicitly: JDK7: no effect JDK8: override the default, allow
     * no access
     */
    public void xtestInclude_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
            checkFSPBehavior(TEST_EXTERNALDTD, "testInclude_secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void xtestInclude_secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_STYLESHEET, "file,http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        }
    }

    public void xtestInclude_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_STYLESHEET, "file,http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void xtestInclude_Preference() {
        System.setProperty(SP_ACCESS_EXTERNAL_STYLESHEET, "file,http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        }
    }

    /**
     * secure processing, access is restricted However, paths handled by a
     * resolver are not restricted
     */
    public void xtestInclude_Secure_Resolver() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setURIResolver(resolver);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLInclude_main.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("XSLPI.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }
    }

    /////////////////////////////////////////////////
    ///////////Document() Function
    /////////////////////////////////////////////////    
    /**
     * By default, file access is allowed
     */
    public void xtestDocFunc() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("DocumentFunc.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }
    }

    public void testDocFunc_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_STYLESHEET, "");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("DocumentFunc.xml")), new StreamResult(System.out));
            reportFailToDenyAccess(TEST_EXTERNALSTYLESHEET, "testDocFunc_SP", PROTOCOL_FILE);
        } catch (Exception e) {
            denyExternalAccess(TEST_EXTERNALSTYLESHEET, e, "file");
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        }
    }

    /**
     * Setting FSP explicitly: JDK7: no effect JDK8: override the default, allow
     * no access
     */
    public void xtestDocFunc_Secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("DocumentFunc.xml")), new StreamResult(System.out));
            checkFSPBehavior(TEST_EXTERNALDTD, "testDocFunc_Secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void xtestDocFunc_Secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_STYLESHEET, "file,http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("DocumentFunc.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        }
    }

    /**
     * JAXP Property takes preference
     */
    public void xtestDocFunc_JAXPProperty() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(ACCESS_EXTERNAL_STYLESHEET, "file");
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("DocumentFunc.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    /**
     * JAXP Property takes preference even though FSP is set afterwards
     */
    public void testDocFunc_JAXPPropertySFP() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setAttribute(ACCESS_EXTERNAL_STYLESHEET, "file");
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("DocumentFunc.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }    

    /**
     * secure processing, access is restricted However, paths handled by a
     * resolver are not restricted
     */
    public void xtestDocFunc_Resolver() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setURIResolver(resolver);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("DocumentFunc.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }
    }

    /**
     * secure processing, access is restricted However, paths handled by a
     * resolver are not restricted
     */
    public void xtestDocFunc_Resolver1() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("DocumentFunc.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.setURIResolver(resolver);
            transformer.transform(new StreamSource(Bug7192390_XSLT_Test.class.getResourceAsStream("DocumentFunc.xml")), new StreamResult(System.out));
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }
    }

    /////////////////////////////////////////////////
    ///////////external DTD in xml source file
    /////////////////////////////////////////////////        
    /**
     * by default, file access is allowed
     */
    public void xtestSourceWDTD_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLSourceDTD.xml").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLSourceDTD.xml").toExternalForm());
            transformer.transform(xslSource, new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    /**
     * Setting FSP explicitly: 
     * JDK7: no effect 
     * JDK8: override the default, allow
     * no access
     */
    public void testSourceWDTD_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLSourceDTD.xml").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLSourceDTD.xml").toExternalForm());
            transformer.transform(xslSource, new StreamResult(System.out));
            checkFSPBehavior(TEST_EXTERNALDTD, "testSourceWDTD_secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testSourceWDTD_secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file, http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLSourceDTD.xml").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLSourceDTD.xml").toExternalForm());
            transformer.transform(xslSource, new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    /**
     * The JAXP properties override any that set by System property or FSP
     */
    public void xtestSourceWDTD_JAXPProperty() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(ACCESS_EXTERNAL_STYLESHEET, "all");
            factory.setAttribute(ACCESS_EXTERNAL_DTD, "all");
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLSourceDTD.xml").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLSourceDTD.xml").toExternalForm());
            transformer.transform(xslSource, new StreamResult(System.out));
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }
    /////////////////////////////////////////////////
    ///////////external DTD in XSL file
    /////////////////////////////////////////////////        

    public void xtestXSLWDTD_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLDTD.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLDTD.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    /**
     * Setting FSP explicitly: JDK7: no effect JDK8: override the default, allow
     * no access
     */
    public void testXSLWDTD_secure() {
        String x = System.getProperty(SP_ACCESS_EXTERNAL_STYLESHEET);
        System.out.println("X=" + x);
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLDTD.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLDTD.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
            checkFSPBehavior(TEST_EXTERNALDTD, "testXSLWDTD_secure", PROTOCOL_FILE);
        } catch (Exception e) {
            checkFSPBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_FILE);
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void xtestXSLWDTD_secure_SP() {
        System.setProperty(SP_ACCESS_EXTERNAL_DTD, "file,http");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLDTD.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLDTD.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
        } catch (Exception e) {
            allowExternalAccess(e);
        } finally {
            System.clearProperty(SP_ACCESS_EXTERNAL_DTD);
        }
    }

    public void xtestXSLWDTD_JAXPProperty() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(ACCESS_EXTERNAL_STYLESHEET, "all");
            factory.setAttribute(ACCESS_EXTERNAL_DTD, "all");
            SAXSource xslSource = new SAXSource(new InputSource(Bug7192390_XSLT_Test.class.getResource("XSLDTD.xsl").toExternalForm()));
            xslSource.setSystemId(Bug7192390_XSLT_Test.class.getResource("XSLDTD.xsl").toExternalForm());
            Transformer transformer = factory.newTransformer(xslSource);
        } catch (Exception e) {
            allowExternalAccess(e);
        }
    }

    public void xtestStylesheetPI1() {
        try {
            javax.xml.parsers.SAXParserFactory saxFactory =
                    javax.xml.parsers.SAXParserFactory.newInstance();


            saxFactory.setFeature(
                    javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING,
                    true);

            javax.xml.parsers.SAXParser parser = saxFactory.newSAXParser();
            org.xml.sax.XMLReader xmlReader = parser.getXMLReader();
            xmlReader.setEntityResolver(new org.xml.sax.EntityResolver() {
                public org.xml.sax.InputSource resolveEntity(
                        String publicId, String systemId) throws org.xml.sax.SAXException, java.io.IOException {
                    throw new org.xml.sax.SAXException(
                            "Will not resolve entities (for stylesheet)");
                }
            });

            javax.xml.transform.TransformerFactory factory =
                    javax.xml.transform.TransformerFactory.newInstance();

            factory.setURIResolver(new javax.xml.transform.URIResolver() {
                public javax.xml.transform.Source resolve(
                        String href, String base) throws javax.xml.transform.TransformerException {
                    throw new RuntimeException //javax.xml.transform.TransformerException
                            (
                            "Will not resolve URIs");
                }
            });

            factory.setFeature(
                    javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING,
                    true);
            javax.xml.transform.Transformer transformer = factory.newTransformer(
                    new javax.xml.transform.sax.SAXSource(
                    xmlReader,
                    new org.xml.sax.InputSource(new java.io.StringReader(XSL_INC_FILE))));

            transformer.transform(
                    new javax.xml.transform.stream.StreamSource(
                    new java.io.StringReader(SRC)),
                    new javax.xml.transform.stream.StreamResult(
                    System.out));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
