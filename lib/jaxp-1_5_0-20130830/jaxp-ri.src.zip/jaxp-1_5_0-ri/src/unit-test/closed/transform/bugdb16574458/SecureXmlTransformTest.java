/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.transform.bugdb16574458;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.Policy;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class SecureXmlTransformTest extends TestCase {

    /**
     * search .getXMLReader(), and add secure feature
     */
    public static void main(String[] args) throws TransformerException, JAXBException, FileNotFoundException {
        //new SecureXmlTransformTest().testXSLT();
        TestRunner.run(SecureXmlTransformTest.class);
    }
    private String _filepath;
    private boolean hasSM;
    private String _curdir;
    private Policy _orig;
    private String _xml, _xsl, _unsafe;

    @Override
    protected void setUp() {
        String temp = SecureXmlTransformTest.class.getResource("document.xml").getPath();
        _filepath = temp.substring(0, temp.lastIndexOf('/'));

        //System.out.println("_filepath=" + _filepath);
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length() - 1);
        _orig = Policy.getPolicy();

        _xml = _filepath + "/document.xml";
        _xsl = _filepath + "/stylesheet.xsl";
        _unsafe = _filepath + "/unsafe.xml";
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    /**
     * StAX is not safe by default, need to use property such as
     */
    public void xtestTransform_stax() throws FileNotFoundException, XMLStreamException {
        XMLInputFactory ifactory = XMLInputFactory.newInstance();
        ifactory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        Source src = new StAXSource(ifactory.createXMLStreamReader(_unsafe, new FileInputStream(_unsafe)));
        Source xsl = new StreamSource(new FileInputStream(_xsl));
        transformXml(src, xsl, "unsafe source document");
    }

    public void xtestTransform_stax1() throws FileNotFoundException, XMLStreamException {
        XMLInputFactory ifactory = XMLInputFactory.newInstance();
        ifactory.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        Source src = new StAXSource(ifactory.createXMLStreamReader(_unsafe, new FileInputStream(_unsafe)));
        Source xsl = new StreamSource(new FileInputStream(_xsl));
        transformXml(src, xsl, "unsafe source document");
    }

    /**
     * DOM is safe by default
     */
    public void xtestTransform_dom() {
        try {
            DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = df.newDocumentBuilder();
            //exception will be thrown before transform
            Document doc = db.parse(new FileInputStream(_unsafe));
            Source src = new DOMSource(doc);
            Source xsl = new StreamSource(new FileInputStream(_xsl));
            transformXml(src, xsl, "unsafe source document");
        } catch (SAXException e) {
            String msg = e.getMessage();
            if (msg.contains("The parser has encountered more than \"64,000\" entity expansions in this document")) {
                //DOMSource
            } else {
                e.printStackTrace();
            }
        } catch (ParserConfigurationException e) {
            fail("Configuration error");
        } catch (IOException e) {
            fail("Configuration error");
        }
    }

    public void testTransform_sax() throws FileNotFoundException {
        Source src = new SAXSource(new InputSource(new FileInputStream(_unsafe)));
        Source xsl = new StreamSource(new FileInputStream(_xsl));
        transformXml(src, xsl, "unsafe source document");
    }

    public void xtestTransform_stream() throws FileNotFoundException {
        FileInputStream xml=null;
        try {
        xml = new FileInputStream(_unsafe);
        Source src = new StreamSource(xml);
        Source xsl = new StreamSource(new FileInputStream(_xsl));
        transformXml(src, xsl, "unsafe source document");
        } catch (FileNotFoundException e) {
            fail("Configuration error");
        } finally {
            if (xml !=null) {
                try {
                    xml.close();
                } catch (IOException ex) {}
            }
        }
    }

    public void transformXml(Source src, Source xsl, String message) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            tf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

            Result result = new DOMResult();
            System.out.println("Testing case [" + message + "] start");
            Transformer transformer = tf.newTemplates(xsl).newTransformer();
            transformer.transform(src, result);
            System.out.println("end");
        } catch (java.lang.OutOfMemoryError e) {
            fail("Out of memory!");
        } catch (Throwable t) {
            String msg = t.getMessage();
            if (msg.contains("The entity \"x1\" was referenced, but not declared")) {
                //StAX SUPPORT_DTD=false
            } else if (msg.contains("JAXP0001")) {
                //SAX or StreamSource
            } else {
                t.printStackTrace();
            }
        }
    }

    public void xtestIdTransform_sax() throws FileNotFoundException {
        Source src = new SAXSource(new InputSource(new FileInputStream(_unsafe)));
        transformIdentity(src, "unsafe source document");
    }

    public void xtestIdTransform_stream() throws FileNotFoundException {
        Source src = new StreamSource(new FileInputStream(_unsafe));
        Source xsl = new StreamSource(new FileInputStream(_xsl));
        transformIdentity(src, "unsafe source document");
    }

    public void transformIdentity(Source src, String message) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            tf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

            Result result = new DOMResult();
            System.out.println("Testing case [" + message + "] start");
            Transformer transformer = tf.newTransformer();
            transformer.transform(src, result);
            System.out.println("end");
        } catch (OutOfMemoryError e) {
            fail("Out of memory!");
        } catch (Throwable t) {
            String msg = t.getMessage();
            if (msg.contains("The entity \"x1\" was referenced, but not declared")) {
                //StAX SUPPORT_DTD=false
            } else if (msg.contains("The parser has encountered more than \"64,000\" entity expansions in this document")) {
                //SAX or StreamSource
            } else {
                t.printStackTrace();
            }
        }
    }

    public void xtestSAXSecureProcessing() {
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            //spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            spf.setValidating(true);
            System.setProperty("maxOccurLimit", "2");
            //Get the parser
            SAXParser parser = spf.newSAXParser();
            XMLReader reader = parser.getXMLReader();
        } catch (Exception e) {
            fail("Exception occured: " + e.getMessage());
        }
    }
}
