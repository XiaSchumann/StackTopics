/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.transform;

import com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl;
import com.sun.org.apache.xalan.internal.xsltc.trax.TestClass;
import java.io.*;
import java.lang.reflect.ReflectPermission;
import java.security.AccessController;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.security.Policy;
import java.security.PrivilegedAction;
import java.security.ProtectionDomain;
import java.util.PropertyPermission;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;

import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * <p>Test {@link javax.xml.transform.Transformer} for CR 6657673 : Test
 * transformation after adding package access </p>
 *
 * @author Joe Wang <huizhe.wang@oracle.com>
 *
 */
public class CR6657673_deTest1 extends TestCase {

    private static final String XSL = ""
            + "<xsl:stylesheet "
            + "    xmlns:xsl='http://www.w3.org/1999/XSL/Transform' "
            + "    version='1.0'>"
            + "</xsl:stylesheet> ";
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<doc/>";
    
    
    private boolean hasSM;
    Policy _orig;


    public static void main(String[] args) {
        TestRunner.run(CR6657673_deTest1.class);
    }

    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            //System.setSecurityManager(null);
        }

       // _orig = Policy.getPolicy();

    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        //System.setSecurityManager(null);
        //Policy.setPolicy(_orig);
        if (hasSM) {
        //    System.setSecurityManager(new SecurityManager());
        }
    }

    public void testClassLoading() {
        final ClassLoader cl = getContextClassLoader();
        Class testCls;
        try {
            testCls = (Class)java.security.AccessController.doPrivileged(
                    new java.security.PrivilegedAction() {
                        public java.lang.Object run() {
                            try {
                            Class testCls = cl.loadClass("com.sun.org.apache.xalan.internal.xsltc.trax.TestClass");
                            return testCls;
                            } catch (Exception e) {
                                return null;
                            }
                        }
                    });            
            Object instance = testCls.newInstance();
            ((TestClass)instance).testReadClass();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    static ClassLoader getContextClassLoader() {
        return (ClassLoader) AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                ClassLoader cl = null;
                try {
                    cl = Thread.currentThread().getContextClassLoader();
                } catch (SecurityException ex) {
                }
                return cl;
            }
        });
    }
    
    public void test() {
        Class clz = (Class) java.security.AccessController.doPrivileged(
                    new java.security.PrivilegedAction() {
                        public Object run() {
                            return TemplatesImpl.class;
                        }
                    });        

 
        getPkgName(clz);
    }
    String getPkgName(Class clz) {
        Package pkg = clz.getPackage();
        String packageName = pkg.getName().replace('.', '/');
        System.out.println("package name: " + packageName);
        return packageName;
    }
    /**
     * Serialize the templates without Security Manager; Use the serialized templates
     * to test that deserialization will be rejected.
     */
    public void xtestDeserializingTemplates() {
        
        //serialize without Security Manager
        byte[] serialTemplates = null;
        try {
            //serialTemplates = createSerialTemplates();

        } catch (Exception ex) {
            //ex.printStackTrace();
            String errmsg = ex.getMessage();
            //access to com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl will be denied:
            if (errmsg.indexOf("\"java.lang.RuntimePermission\" \"accessClassInPackage.com.sun.org.apache.xalan.internal.xsltc.trax\"") > -1) {
                System.out.println("Expected error: " + errmsg);
            } else {
                ex.printStackTrace();
                fail(ex.getMessage());
            }
        }

        //enable security manager
        //Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"));
        //Policy.setPolicy(p);
        //System.setSecurityManager(new SecurityManager());        

        java.io.ObjectInputStream in;
        try {          
            in = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(serialTemplates));
            com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl templates =
                    (com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl) in.readObject();
            templates.newTransformer();
            System.setSecurityManager(null);     
            fail("Should throw exception");
        } catch (java.lang.NullPointerException exc) {
            // Don't care.
            System.err.println("(NPE caught)");
        } catch (Exception ex) {
            ex.printStackTrace();
        }        
    }

    private static byte[] createSerialTemplates() throws Exception {
        javax.xml.transform.TransformerFactory factory =
                javax.xml.transform.TransformerFactory.newInstance();
        com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl templates =
                (com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl) factory.newTemplates(
                new javax.xml.transform.stream.StreamSource(
                new java.io.StringReader(XSL)));
        java.lang.reflect.Field field =
                com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl.class
                .getDeclaredField("_bytecodes");
        field.setAccessible(true);
        byte[][] bytecodes = (byte[][]) field.get(templates);
        //bytecodes[0] = bytecode;

        java.io.ByteArrayOutputStream byteOut =
                new java.io.ByteArrayOutputStream();
        java.io.ObjectOutputStream out =
                new java.io.ObjectOutputStream(byteOut);
        out.writeObject(templates);
        out.flush();
        return byteOut.toByteArray();
    }

    /**
     * Simple policy implementation that grants a set of permissions to all code
     * sources and protection domains.
     */
    static class SimplePolicy extends Policy {

        private final Permissions perms;

        public SimplePolicy(Permission... permissions) {
            perms = new Permissions();
            for (Permission permission : permissions) {
                perms.add(permission);
            }
        }

        @Override
        public PermissionCollection getPermissions(CodeSource cs) {
            return perms;
        }

        @Override
        public PermissionCollection getPermissions(ProtectionDomain pd) {
            return perms;
        }

        @Override
        public boolean implies(ProtectionDomain pd, Permission p) {
            return perms.implies(p);
        }
    }
}
