/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2012 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.transform;

import common.SimplePolicy;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.*;
import java.io.*;
import java.net.URL;
import java.security.AllPermission;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.security.Policy;
import java.security.ProtectionDomain;
import java.util.PropertyPermission;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSParser;
import org.w3c.dom.ls.LSSerializer;

/**
 * Test {@link javax.xml.transform.Transformer} for CR 6618782: Additional
 * changes: 1. Report compilation exception with cause that was missing 2.
 *
 *
 * @author Joe Wang <huizhe.wang@oracle.com>
 *
 */
public class CRxxTest extends TestCase {

    private static final String XSL = ""
            + "<xsl:stylesheet "
            + "    xmlns:xsl='http://www.w3.org/1999/XSL/Transform' "
            + "    version='1.0'>"
            + "</xsl:stylesheet> ";
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<doc/>";
    Policy _orig;
    private String _filepath;

    public static void main(String[] args) {
        TestRunner.run(CRxxTest.class);
    }
    private boolean hasSM;
    private String _curdir;

    @Override
    public void setUp() {
        String temp = CRxxTest.class.getResource("CRxx.xsl").getPath();
        _filepath = temp.substring(0, temp.lastIndexOf('/'));

        System.out.println("_filepath=" + _filepath);
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length() - 1);
        _orig = Policy.getPolicy();
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                new FilePermission(_filepath + "/-", "read,write,delete"),
                new FilePermission(_curdir + "/-", "read,write,delete"),
                new PropertyPermission("*", "read"));
        if (hasSM) {
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        if (hasSM) {
            // turn off security manager and restore policy
            System.setSecurityManager(null);
            Policy.setPolicy(_orig);
            System.setSecurityManager(new SecurityManager());
        }
    }
    /*
     * javax.xml.jaxp14.ptests.FactoryTest
     */
    String className = null;
    ClassLoader CL = null;
    /* 
     test for DatatypeFactory.newInstance(java.lang.String factoryClassName, java.lang.ClassLoader classLoader)
     classloader is null and factoryClassName is null ,
     should throw DatatypeConfigurationException
     */

    public void test02() {
        try {
            DatatypeFactory dtf = DatatypeFactory.newInstance(className, CL);
            System.out.println("Failed : expected DatatypeConfigurationException not thrown in test02 ");
            fail("test02() failed ");

        } catch (DatatypeConfigurationException dtce) {
            System.out.println("Passed : expected DatatypeConfigurationException thrown in test02 ");
            dtce.printStackTrace();
        } catch (Exception e) {
            System.out.println("Failed : Exception in test02 " + e);
            fail("test02() failed ");
        }
    }
    
    /**
     * test.auctionportal.UserController
     */

    /**
     * This checks for namespace normalization
     *
     * @see <a href="content/screenName.xml">screenName.xml </a> us prefix of
     * userName is bound to "http://hibid.com/user" namespace normalization will
     * create a namespace of prefix us and attach userEmail
     */
    public void xtestCheckScreenNameExists() {
        //different from the sqe test: these paths are moved inside the method
        String SCREEN_NAMES_FILE = _filepath + "/screenName.xml";
        String SCREEN_NAMES_OUTPUT = _filepath + "/screenNameOut.xml";
        String SCREEN_NAMES_GOLD = _filepath + "/screenNameGold.xml";

    boolean status = true;

        //since the user does not exist adding the email id
        try {

            //Create DOM document using DOM level 3 check for screenname

            DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
            DOMImplementationLS impl = (DOMImplementationLS) registry.getDOMImplementation("LS");
            LSSerializer writer = impl.createLSSerializer();
            LSParser builder = impl.createLSParser(
                    DOMImplementationLS.MODE_SYNCHRONOUS,
                    null);
            Document document = builder.parseURI(SCREEN_NAMES_FILE);
            Element screenName = (Element) document.getElementsByTagNameNS(
                    "http://hibid.com/screenName",
                    "screen-name").item(0);
            Element userEmail = document.createElementNS(
                    "http://hibid.com/user", "userEmail");

            // must return true;
            status = userEmail.isDefaultNamespace("http://hibid.com/user");
            System.err.println("status" + status);

            Text email = document.createTextNode("myid@hibid.com");
            userEmail.appendChild(email);
            screenName.appendChild(userEmail);
            document.normalizeDocument();

            FileOutputStream output = new FileOutputStream(SCREEN_NAMES_OUTPUT);

            //writer.writeNode(System.out,document);
            MyDOMOutput domoutput = new MyDOMOutput();
            domoutput.setByteStream(output);

            writer.write(document, domoutput);
/**
            URL source = new URL("file", "", SCREEN_NAMES_GOLD);
            URL out = new URL("file", "", SCREEN_NAMES_OUTPUT);
            status &= FileInfo.isXMLEqual(source, out);
*/
            File source = new File(SCREEN_NAMES_GOLD);
            File out = new File(SCREEN_NAMES_OUTPUT);
            status &= isXMLEqual(source, out);

            if (!status) {
                fail("output does not match gold file");
            }
        } catch (Exception e) {
            e.printStackTrace();
            status = false;
        }
    }

    public final void xtestTransform() {
        try {

            String inFilename = _filepath + "/CR6618782.xml";
            String xslFilename = _filepath + "/XSLInclude_main.xsl";
            String outFilename = _filepath + "/CR6618782.out";

            StringWriter sw = new StringWriter();
            // Create transformer factory
            TransformerFactory factory = TransformerFactory.newInstance();
            // set the translet name
            factory.setAttribute("translet-name", "myTranslet");

            // set the destination directory
            factory.setAttribute("destination-directory", _curdir);
            factory.setAttribute("generate-translet", Boolean.TRUE);

            // Use the factory to create a template containing the xsl file
            Templates template = factory.newTemplates(new StreamSource(new FileInputStream(xslFilename)));
            // Use the template to create a transformer
            Transformer xformer = template.newTransformer();
            // Prepare the input and output files
            Source source = new StreamSource(new FileInputStream(inFilename));
            //Result result = new StreamResult(new FileOutputStream(outFilename));
            Result result = new StreamResult(sw);
            // Apply the xsl file to the source file and write the result to the output file
            xformer.transform(source, result);

            String out = sw.toString();

        } catch (Exception e) {
            // unexpected failure
            //e.printStackTrace();
            Throwable cause = e.getCause();
            if (cause instanceof FileNotFoundException) {
                //expected
                System.out.println(cause.getMessage());
            } else {
                fail(e.toString());
            }
        }

    }

    boolean isXMLEqual(File file1, File file2) {
        boolean status = false;
        try {
            DocumentBuilderFactory aDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder xmlParser = aDocumentBuilderFactory.newDocumentBuilder();

            Document doc1 = xmlParser.parse(file1);
            Document doc2 = xmlParser.parse(file2);
            if (doc1.getDocumentElement().toString().equals(doc2.getDocumentElement().toString())) {
                status = true;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    class MyDOMOutput implements LSOutput {

        private OutputStream bytestream;
        private String encoding;
        private String sysId;
        private Writer writer;

        public OutputStream getByteStream() {
            return bytestream;
        }

        public Writer getCharacterStream() {
            return writer;
        }

        public String getEncoding() {
            return encoding;
        }

        public String getSystemId() {
            return sysId;
        }

        public void setByteStream(OutputStream bs) {
            bytestream = bs;
        }

        public void setCharacterStream(Writer cs) {
            writer = cs;
        }

        public void setEncoding(String enc) {
            encoding = enc;
        }

        public void setSystemId(String sysId) {
            sysId = sysId;
        }
    }
}
