/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.transform.bugdb16574458;

import bug6309988.MyErrorHandler;
import java.io.File;
import junit.framework.TestCase;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.stream.StreamSource;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.security.Policy;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.validation.ErrorHandlerImpl;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.validation.ValidatorTest;
import junit.textui.TestRunner;
import org.xml.sax.ErrorHandler;

public class ValidationTest extends TestCase {

/** 
 * search .getXMLReader(), and add secure feature
 */
    
    public static void main(String[] args) throws TransformerException, JAXBException, FileNotFoundException {
        //new SecureXmlTransformTest().testXSLT();
        TestRunner.run(ValidationTest.class);
    }
    private String _filepath;
    private boolean hasSM;
    private String _curdir;
    private Policy _orig;
    private String _xml, _xsl, _malicious;

    @Override
    protected void setUp() {
        String temp = ValidationTest.class.getResource("document.xml").getPath();
        _filepath = temp.substring(0, temp.lastIndexOf('/'));

        //System.out.println("_filepath=" + _filepath);
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length() - 1);
        _orig = Policy.getPolicy();

        _xml = _filepath + "/document.xml";
        _xsl = _filepath + "/stylesheet.xsl";
        _malicious = _filepath + "/unsafe.xml";
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }
    /**
     * Test validating a Stream.
     */
    public void testValidateStream() {

        File resultFile = null;
        try {
            resultFile = new File("stax.result");
            if (resultFile.exists()) {
                resultFile.delete();
            }

            // Validate this instance document against the
            // Instance document supplied
            Result xmlResult = new javax.xml.transform.stream.StreamResult(
                    resultFile);
            Source xmlSource = new javax.xml.transform.stream.StreamSource(
                    new File(ValidatorTest.class.getResource(
                        "toys.xml").toURI()));

            validate("toys.xsd", xmlSource, xmlResult);
            assertTrue("result file is not created", resultFile.exists());
        } catch (Exception ex) {
           ex.printStackTrace();
           fail("Exception : " + ex.getMessage());
       } finally {
           if (resultFile != null && resultFile.exists()) {
               resultFile.delete();
           }
       }
    }
    /**
     * Validate the f]given src against xsdFile producing result.
     *
     * @param xsdFile XSD to validate against.
     * @param src Source to validate
     * @param result Result of validation.
     *
     * @throws Exception If error processing source.
     */
    private void validate(
            final String xsdFile,
            final Source src,
            final Result result)
        throws Exception {
        try {
            SchemaFactory sf = SchemaFactory.newInstance(
                    XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = sf.newSchema(
                    new File(ValidatorTest.class.getResource(xsdFile).toURI()));

            // Get a Validator which can be used to validate instance document
            // against this grammar.
            Validator validator = schema.newValidator();
            ErrorHandler eh = new ErrorHandlerImpl();
            validator.setErrorHandler(eh);

            // Validate this instance document against the
            // Instance document supplied
            validator.validate(src, result);
        } catch (Exception ex) {
            throw ex;
        }
    }

    /**
     * Get the XMLEventReader for a given file.
     *
     * @param filename Filename to create reader for.
     *
     * @return XMLEventReader for given filename.
     */
    private XMLEventReader getXMLEventReader(final String filename) {

        XMLInputFactory xmlif = null;
        XMLEventReader xmlr = null;
        try {
            xmlif = XMLInputFactory.newInstance();
            xmlif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES,
                    Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES,
                    Boolean.FALSE);
            xmlif.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.TRUE);
            xmlif.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);

            //FileInputStream fis = new FileInputStream(filename);
            FileInputStream fis = new FileInputStream(
                    new File(
                        ValidatorTest.class.getResource(filename).toURI()));
            xmlr =  xmlif.createXMLEventReader(filename, fis);
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Exception : " + ex.getMessage());
        }
        return xmlr;
    }
}
