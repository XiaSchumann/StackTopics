/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.transform.bugdb16574458;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.Policy;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class SecureXmlValidationTest extends TestCase {

    /**
     * search .getXMLReader(), and add secure feature
     */
    public static void main(String[] args) throws TransformerException, JAXBException, FileNotFoundException {
        //new SecureXmlTransformTest().testXSLT();
        TestRunner.run(SecureXmlValidationTest.class);
    }
    private String _filepath;
    private boolean hasSM;
    private String _curdir;
    private Policy _orig;
    private String _xml, _xsl, _unsafe, _xsd, _xsdImport;

    @Override
    protected void setUp() {
        String temp = SecureXmlValidationTest.class.getResource("document.xml").getPath();
        _filepath = temp.substring(0, temp.lastIndexOf('/'));

        //System.out.println("_filepath=" + _filepath);
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length() - 1);
        _orig = Policy.getPolicy();

        _xml = _filepath + "/document.xml";
        _xsl = _filepath + "/stylesheet.xsl";
        _unsafe = _filepath + "/unsafe.xml";
        _xsd = _filepath + "/test.xsd";
        _xsdImport = _filepath + "/XSDImport_company.xsd";
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    /**
     * StAX is not safe by default, need to use property such as
     */
    public void xtestValidation_stax() throws FileNotFoundException, XMLStreamException {
        XMLInputFactory ifactory = XMLInputFactory.newInstance();
        ifactory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        Source src = new StAXSource(ifactory.createXMLStreamReader(_unsafe, new FileInputStream(_unsafe)));
        validate(src);
    }

    public void xtestValidation_stax1() throws FileNotFoundException, XMLStreamException {
        XMLInputFactory ifactory = XMLInputFactory.newInstance();
        ifactory.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        Source src = new StAXSource(ifactory.createXMLStreamReader(_unsafe, new FileInputStream(_unsafe)));
        validate(src);
    }

    /**
     * DOM is safe by default
     */
    public void xtestValidation_dom() throws FileNotFoundException {
        try {
            DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = df.newDocumentBuilder();
            //exception will be thrown before transform
            Document doc = db.parse(new FileInputStream(_unsafe));
            Source src = new DOMSource(doc);
            validate(src);
        } catch (SAXException e) {
            String msg = e.getMessage();
            if (msg.contains("The parser has encountered more than \"64,000\" entity expansions in this document")) {
                //DOMSource
                System.out.println("Test pass: excessive entity expansion rejected.");                
            } else {
                e.printStackTrace();
            }
        } catch (ParserConfigurationException e) {
            fail("Configuration error");
        } catch (IOException e) {
            fail("Configuration error");
        }
    }
    
    public void testSchemaImport_SAXSource() {
        try{
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            SAXSource xsdSource = new SAXSource(new InputSource(_xsdImport));
            Schema schema = schemaFactory.newSchema(xsdSource);
        } catch (SAXException e) {
            e.printStackTrace();
            String msg = e.getMessage();
            if (msg.contains("The parser has encountered more than \"64,000\" entity expansions in this document")) {
                System.out.println("Test pass: excessive entity expansion rejected.");
            } else {
                e.printStackTrace();
            }
        }
    }    
    /**
     * SAXSource
     */
    public void xtestValidation_SAX() throws FileNotFoundException {
        Source src = new SAXSource(new InputSource(new FileInputStream(_unsafe)));
        validate(src);
    }

    public void xtestValidation_stream() throws FileNotFoundException {
        Source src = new StreamSource(new FileInputStream(_unsafe));
        validate(src);
    }

    public void validate(Source src) {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Source xsd = new StreamSource(new FileInputStream(_xsd));
            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("Bug7192390_val.xsd")));
            Schema schema = schemaFactory.newSchema(xsd);
            Validator validator = schema.newValidator();
            validator.validate(src);

        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg.contains("The entity \"x1\" was referenced, but not declared")) {
                //StAX SUPPORT_DTD=false
            } else if (msg.contains("The parser has encountered more than \"64,000\" entity expansions in this document")) {
                //SAX or StreamSource
                System.out.println("Test pass: excessive entity expansion rejected.");
            } else {
                e.printStackTrace();
            }
        }
    }
}
