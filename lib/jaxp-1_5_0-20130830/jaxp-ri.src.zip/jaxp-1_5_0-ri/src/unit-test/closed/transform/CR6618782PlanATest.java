/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.transform;

import java.io.*;
import java.lang.reflect.ReflectPermission;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.security.Policy;
import java.security.ProtectionDomain;
import java.util.PropertyPermission;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;

import javax.xml.transform.stream.StreamSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * <p>Test {@link javax.xml.transform.Transformer} for CR 6657673 : Test
 * transformation after adding package access </p>
 *
 * @author Joe Wang <huizhe.wang@oracle.com>
 *
 */
public class CR6618782PlanATest extends TestCase {

    private static final String XSL = ""
            + "<xsl:stylesheet "
            + "    xmlns:xsl='http://www.w3.org/1999/XSL/Transform' "
            + "    version='1.0'>"
            + "</xsl:stylesheet> ";
    private static final String SRC = ""
            + "<?xml version='1.0'?>"
            + "<doc/>";
    private boolean hasSM;
    Policy _orig;
    private String _filepath;
    private String _curdir;

    public static void main(String[] args) {
        TestRunner.run(CR6618782PlanATest.class);
    }

    @Override
    public void setUp() {
        String temp = CR6618782PlanATest.class.getResource("CR6618782.xsl").getPath();
        _filepath = temp.substring(0, temp.lastIndexOf('/'));

        System.out.println("_filepath=" + _filepath);
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length() - 1);
        _orig = Policy.getPolicy();

    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void testCreateTemplate() {
        createTemplate(false);
    }
    public void testCreateTemplate_sm() {
        createTemplate(true);
    }

    void createTemplate(boolean enableSM) {
        if (enableSM) {
            Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new FilePermission(_filepath + "/-", "read,write,delete"),
                    new FilePermission(_curdir + "/-", "read,write,delete"),
                    new PropertyPermission("*", "read"),
                    new RuntimePermission("accessDeclaredMembers"),
                    new ReflectPermission("suppressAccessChecks"));
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
        try {
            byte[] serialTemplates = createSerialTemplates();
        } catch (Exception ex) {
            //ex.printStackTrace();
            String errmsg = ex.getMessage();
            //access to com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl will be denied:
            if (errmsg.indexOf("\"java.lang.RuntimePermission\" \"accessClassInPackage.com.sun.org.apache.xalan.internal.xsltc.trax\"") > -1) {
                System.out.println("Expected error: " + errmsg);
            } else {
                ex.printStackTrace();
                fail(ex.getMessage());
            }
        }
        if (enableSM) {
            System.setSecurityManager(null);
        }
    }

    private static byte[] createSerialTemplates() throws Exception {
        javax.xml.transform.TransformerFactory factory =
                javax.xml.transform.TransformerFactory.newInstance();
        com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl templates =
                (com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl) factory.newTemplates(
                new javax.xml.transform.stream.StreamSource(
                new java.io.StringReader(XSL)));
        java.lang.reflect.Field field =
                com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl.class
                .getDeclaredField("_bytecodes");
        field.setAccessible(true);
        byte[][] bytecodes = (byte[][]) field.get(templates);
        //bytecodes[0] = bytecode;

        java.io.ByteArrayOutputStream byteOut =
                new java.io.ByteArrayOutputStream();
        java.io.ObjectOutputStream out =
                new java.io.ObjectOutputStream(byteOut);
        out.writeObject(templates);
        out.flush();
        return byteOut.toByteArray();
    }

    public final void testTransform() {
        try {

            String inFilename = _filepath + "/CR6618782.xml";
            String xslFilename = _filepath + "/CR6618782.xsl";
            String outFilename = _filepath + "/CR6618782.out";

            StringWriter sw = new StringWriter();
            // Create transformer factory
            TransformerFactory factory = TransformerFactory.newInstance();
            // set the translet name
            factory.setAttribute("translet-name", "myTranslet");

            // set the destination directory
            factory.setAttribute("destination-directory", _curdir);
            factory.setAttribute("generate-translet", Boolean.TRUE);

            // Use the factory to create a template containing the xsl file
            Templates template = factory.newTemplates(new StreamSource(new FileInputStream(xslFilename)));
            // Use the template to create a transformer
            Transformer xformer = template.newTransformer();
            // Prepare the input and output files
            Source source = new StreamSource(new FileInputStream(inFilename));
            //Result result = new StreamResult(new FileOutputStream(outFilename));
            Result result = new StreamResult(sw);
            // Apply the xsl file to the source file and write the result to the output file
            xformer.transform(source, result);

            String out = sw.toString();
            if (out.indexOf("<p>") < 0) {
                fail(out);
            }
        } catch (Exception e) {
            // unexpected failure
            //e.printStackTrace();
            fail(e.toString());
        }

    }

    /**
     * Simple policy implementation that grants a set of permissions to all code
     * sources and protection domains.
     */
    static class SimplePolicy extends Policy {

        private final Permissions perms;

        public SimplePolicy(Permission... permissions) {
            perms = new Permissions();
            for (Permission permission : permissions) {
                perms.add(permission);
            }
        }

        @Override
        public PermissionCollection getPermissions(CodeSource cs) {
            return perms;
        }

        @Override
        public PermissionCollection getPermissions(ProtectionDomain pd) {
            return perms;
        }

        @Override
        public boolean implies(ProtectionDomain pd, Permission p) {
            return perms.implies(p);
        }
    }
}
