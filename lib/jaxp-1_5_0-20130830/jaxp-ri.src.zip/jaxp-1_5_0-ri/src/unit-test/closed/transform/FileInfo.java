/**
 * $Id: FileInfo.java,v 1.2 2003/08/11 22:02:49 bhakti Exp $
 * Copyright (c) 2002 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
package closed.transform;

import org.jdom.*;
import org.jdom.input.SAXBuilder;
import org.vmguys.vmtools.utils.DomFactory;
import org.vmguys.vmtools.utils.CostOps;
import org.vmguys.vmtools.utils.DifferenceFinder2;

import java.io.File;
import java.net.URL;

/**
 * This is the class used to define all constants to be
 * used in the auction portal application
 * @author Bhakti Mehta
 */


public class FileInfo {
    static File file;

    static{
        file = new File(".");
    }

    public static String getPath() {
         try {
             String path =  file.getAbsolutePath();
             return path;
         } catch (Exception e )  {
            e.printStackTrace();    
             return null;
         }
    }


    /* Reused code from the JAXBUtil
     */ 
    public static boolean isXMLEqual(URL url1, URL url2) {
      try {
         SAXBuilder sb = new SAXBuilder();
         sb.setFactory(new DomFactory());

         org.jdom.Document doc1 = sb.build(url1);
         org.jdom.Document doc2 = sb.build(url2);
         DifferenceFinder2 df = new DifferenceFinder2();
         CostOps diff = df.findDifferences(doc1.getRootElement(),
                    doc2.getRootElement());
         System.err.println("[XMLDiffs]" + diff.getCost());

         return (diff.getCost()==0)?true:false;

      } catch (Exception e) {
         e.printStackTrace();
      }
      return false;
   }


}
