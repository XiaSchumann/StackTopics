package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test that the new properties are supported properly in validation
 * @run main/othervm ValidationTest
 */
import java.io.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.SAXParser;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * These tests 
 *
 * @author huizhe.wang@oracle.com
 */
public class ValidationTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public ValidationTest(String name) {
        super(name);
    }
    String _xmlFile, _xsdFile, _xmlValFile, _xsdValFile, _xsdImport, _xsdInclude;
    String _xmlFileId, _xmlValFileId;
    
    protected void setUp() {
        super.setUp();
        _xmlFile = _filepath + "/val_test.xml";
        _xsdFile = _filepath + "/val_test.xsd";
        _xmlValFile = _filepath + "/validation.xml";
        _xsdValFile = _filepath + "/validation.xsd";
        _xsdImport = _filepath + "/XSDImport_company.xsd";
        _xsdInclude = _filepath + "/XSDInclude_company.xsd";
        
        if (isWindows) {
            _xmlFile = "/" + _xmlFile;
            _xsdFile = "/" + _xsdFile;
            _xmlValFile = "/" + _xmlValFile;
            _xsdValFile = "/" + _xsdValFile;
            _xsdImport = "/" + _xsdImport;
            _xsdInclude = "/" + _xsdInclude;
        }        
        
        _xmlFileId = "file://" + _xmlFile;
        _xmlValFileId = "file://" + _xmlValFile;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        ValidationTest test = new ValidationTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();
test.testSchemaLocation_default();
/**
            test.testSchemaImport_JAXPProperty();
            test.testSchemaImport_JAXPPropertySFP();
            test.testSchemaImport_SP();
            test.testSchemaImport_Secure();
            test.testSchemaImport_default();
            test.testSchemaInclude_JAXPProperty();
            test.testSchemaInclude_JAXPPropertySFP();
            test.testSchemaInclude_SP();
            test.testSchemaInclude_Secure();
            test.testSchemaInclude_default();
            test.testSchemaLoading_JAXPProperty();
            test.testSchemaLoading_JAXPPropertySFP();
            test.testSchemaLoading_Validator_JAXPPropertySFP();
            test.testSchemaLoading_JAXPProperty1();
            test.testSchemaLoading_JAXPProperty1SFP();
            test.testSchemaLoading_Validator_JAXPProperty1SFP();
            test.testSchemaLoading_SAX_JAXPProperty();
            test.testSchemaLoading_SAX_JAXPPropertySFP();
            test.testSchemaLoading_SAX_Validator_JAXPPropertySFP();
            test.testSchemaLoading_SAX_JAXPProperty1();
            test.testSchemaLoading_SAX_JAXPProperty1SFP();
            test.testSchemaLoading_SAX_Validator_JAXPProperty1SFP();
            test.testSchemaLoading_SP();
            test.testSchemaLoading_SAX_SP();
            test.testSchemaLoading_Secure();
            test.testSchemaLoading_SAX_Secure();
            test.testSchemaLoading_Validator_Secure(); // This test is failing!
            test.testSchemaLoading_Validator_SAX_Secure(); // This test is failing!
            test.testSchemaLoading_default();
            test.testSchemaLoading_SAX_default();

            test.testSchemaLocationSAX_JAXPProperty(); // SFP already set
            test.testSchemaLocationSAX_SP();
            test.testSchemaLocationSAX_Secure();
            test.testSchemaLocationSAX_default();
            test.testSchemaLocationSAXSP_Secure();
            test.testSchemaLocationDOM_default();
            test.testSchemaLocationDOM_SP();

            test.testSchemaLocationDOM_Secure();
            test.testSchemaLocationDOM_JAXPProperty();
            //test.testSchemaLocationDOM_JAXPPropertySFP();

            test.testSchemaLocation_JAXPProperty();
            test.testSchemaLocation_SAX_JAXPProperty();
            test.testSchemaLocation_JAXPPropertySFP();
            test.testSchemaLocation_SAX_JAXPPropertySFP();
            test.testSchemaLocation_Validator_JAXPPropertySFP();
            test.testSchemaLocation_Validator_SAX_JAXPPropertySFP();
            test.testSchemaLocation_JAXPProperty1();
            test.testSchemaLocation_SAX_JAXPProperty1();
            test.testSchemaLocation_JAXPProperty1SFP();
            test.testSchemaLocation_SAX_JAXPProperty1SFP();
            test.testSchemaLocation_Validator_JAXPProperty1SFP();
            test.testSchemaLocation_Validator_SAX_JAXPProperty1SFP();
            test.testSchemaLocation_SP();
            test.testSchemaLocation_SAX_SP();
            test.testSchemaLocation_DOM_SP();
            test.testSchemaLocation_StAX_SP();
            test.testSchemaLocation_Secure();
            test.testSchemaLocation_SAX_Secure();
            test.testSchemaLocation_DOM_Secure(); // This test is failing!
            test.testSchemaLocation_StAX_Secure();
            test.testSchemaLocation_Validator_Secure(); // This test is failing!
            test.testSchemaLocation_Validator_SAX_Secure(); // This test is failing!
            test.testSchemaLocation_Validator_DOM_Secure(); // This test is failing!
            test.testSchemaLocation_Validator_StAX_Secure(); // This test is failing!
            test.testSchemaLocation_default();
            test.testSchemaLocation_SAX_default();
            test.testSchemaLocation_SAX2_default();
            test.testSchemaLocation_schema();
            test.testSchemaLocation_SAX_schema();

            //test.testSchemaLocationSAXSP_Secure2();
            test.testSchemaLocationDOM_Secure_SP();
            test.testSchemaLocation_Secure_SP();
            test.testSchemaLocation_SAX_Secure_SP();
            test.testSchemaLocation_DOM_Secure_SP();
            test.testSchemaLocation_StAX_Secure_SP();
            test.testSchemaLocation_Validator_Secure_SP();
            test.testSchemaLocation_Validator_SAX_Secure_SP();
            test.testSchemaLocation_Validator_DOM_Secure_SP();
            test.testSchemaLocation_Validator_StAX_Secure_SP();
            test.testSchemaLoading_Secure_SP();
            test.testSchemaLoading_SAX_Secure_SP();
            test.testSchemaLoading_Validator_Secure_SP();
            test.testSchemaLoading_Validator_SAX_Secure_SP();
            test.testSchemaLoading_Secure_SP2();
            test.testSchemaLoading_SAX_Secure_SP2();
            test.testSchemaLoading_Validator_Secure_SP2();
            test.testSchemaLoading_Validator_SAX_Secure_SP2();
            test.testSchemaImport_Secure_SP();
            test.testSchemaInclude_Secure_SP();
*/
            test.tearDown();
        }

    }
    
/////////////////////////////////////////////////
///////////SchemaLocation
/////////////////////////////////////////////////

    /**
     * uses are within the default limits
     */
    public void testSchemaLocationSAX_default() {
        try {
            SAXParser parser = createValidatingParser(false);
            parser.parse(
                    new File(_xmlFile),
                    new DefaultHandler());
            success("testSchemaLocationSAX_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocationSAX_default", e, "entity");
        }
    }

    /**
     * Use SP to set a limit
     */
    public void testSchemaLocationSAX_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SAXParser parser = createValidatingParser(false);
            parser.parse(
                    new File(_xmlFile),
                    new DefaultHandler());
            fail("testSchemaLocationSAX_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocationSAX_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * Same as default 
     */
    public void testSchemaLocationSAX_Secure() {
        try {
            SAXParser parser = createValidatingParser(SECURE_PROCESSING_TRUE);
            parser.parse(
                    new File(_xmlFile),
                    new DefaultHandler());
            success("testSchemaLocationSAX_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocationSAX_Secure", e, "entity");
        }
    }
    /**
     * System property will override that set by SFP 
     */
    public void testSchemaLocationSAXSP_Secure() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SAXParser parser = createValidatingParser(SECURE_PROCESSING_TRUE);
            parser.parse(
                    new File(_xmlFile),
                    new DefaultHandler());
            fail("testSchemaLocationSAXSP_Secure failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocationSAXSP_Secure", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * Use the property to set a limit
     */
    public void testSchemaLocationSAX_JAXPProperty() {
        try {
            SAXParser parser = createValidatingParser(SECURE_PROCESSING_TRUE);
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            parser.parse(
                    new File(_xmlFile),
                    new DefaultHandler());
            fail("testSchemaLocationSAX_JAXPProperty failed, overlimit shall be caught");
        } catch (Exception e) {
            expectedException("testSchemaLocationSAX_JAXPProperty", e, "PE");
        }
    }

    /**
     * uses are within the default limits
     */
    public void testSchemaLocationDOM_default() {
        try {
            DocumentBuilder docBuilder = createValidatingDOM(false, null, null);
            Document document = docBuilder.parse(new File(_xmlFile));
            success("testSchemaLocationDOM_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocationDOM_default", e, "entity");
        }
    }

    /**
     * Use SP to set a limit
     */
    public void testSchemaLocationDOM_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            DocumentBuilder docBuilder = createValidatingDOM(false, null, null);
            Document document = docBuilder.parse(new File(_xmlFile));
            fail("testSchemaLocationDOM_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocationDOM_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }
    /**
     * Setting FSP explicitly, same as default
     */
    public void testSchemaLocationDOM_Secure() {
        try {
            DocumentBuilder docBuilder = createValidatingDOM(SECURE_PROCESSING_TRUE, null, null);
            Document document = docBuilder.parse(new File(_xmlFile));
            success("testSchemaLocationDOM_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocationDOM_Secure", e, "entity");
        }
    }

    /**
     * Use SP to set a limit
     */
    public void testSchemaLocationDOM_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            DocumentBuilder docBuilder = createValidatingDOM(SECURE_PROCESSING_TRUE, null, null);
            Document document = docBuilder.parse(new File(_xmlFile));
            fail("testSchemaLocationDOM_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocationDOM_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * Set a limit using API property
     */
    public void testSchemaLocationDOM_JAXPProperty() {
        try {
            //set secure processing, and then allow external schema
            DocumentBuilder docBuilder = createValidatingDOM(SECURE_PROCESSING_TRUE, JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");;
            Document document = docBuilder.parse(new File(_xmlFile));
            fail("testSchemaLocationDOM_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocationDOM_JAXPProperty", e, "PE");
        }
    }

    /**
     * The file is within the default limit
     */
    public void testSchemaLocation_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_default", e, "entity");
        }
    }

    public void testSchemaLocation_SAX_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(new FileInputStream(_xmlFile)));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_default", e, "entity");
        }
    }

    public void testSchemaLocation_SAX2_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_SAX2_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_SAX2_default", e, "entity");
        }
    }

    public void testSchemaLocation_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_SAX_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            fail("testSchemaLocation_SAX_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_SAX_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_DOM_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();

            //exception will be thrown at trying to get DOM source
            DOMSource source = getDOMSource(_xmlFile, _xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_DOM_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_DOM_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    
    public void testSchemaLocation_StAX_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StAXSource source = staxSourceFor(_xmlFileId, _xmlFile);
            validator.validate(source);
            fail("testSchemaLocation_StAX_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_StAX_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_Secure", e, "entity");
        }
    }

    public void testSchemaLocation_SAX_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            success("testSchemaLocation_SAX_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_SAX_Secure", e, "entity");
        }
    }

    public void testSchemaLocation_DOM_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            DOMSource source = getDOMSource(_xmlFile, _xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_DOM_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_DOM_Secure", e, "entity");
        }
    }

    public void testSchemaLocation_StAX_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StAXSource source = staxSourceFor(_xmlFileId, _xmlFile);
            validator.validate(source);
            success("testSchemaLocation_StAX_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_StAX_Secure", e, "entity");
        }
    }

    public void testSchemaLocation_Validator_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_Validator_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_Validator_Secure", e, "entity");
        }
    }

    public void testSchemaLocation_Validator_SAX_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            success("testSchemaLocation_Validator_SAX_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_Validator_SAX_Secure", e, "entity");
        }
    }

    public void testSchemaLocation_Validator_DOM_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            DOMSource source = getDOMSource(_xmlFile, _xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_Validator_DOM_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_Validator_DOM_Secure", e, "entity");
        }
    }

    public void testSchemaLocation_Validator_StAX_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            StAXSource source = staxSourceFor(_xmlFileId, _xmlFile);
            validator.validate(source);
            success("testSchemaLocation_Validator_StAX_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_Validator_StAX_Secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testSchemaLocation_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_SAX_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(new FileInputStream(_xmlFile)));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_SAX_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_SAX_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_DOM_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            DOMSource source = getDOMSource(_xmlFile, _xmlFileId);
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_DOM_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_DOM_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_StAX_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StAXSource source = staxSourceFor(_xmlFileId, _xmlFile);
            validator.validate(source);
            fail("testSchemaLocation_StAX_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_StAX_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_Validator_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_Validator_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Validator_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_Validator_SAX_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            fail("testSchemaLocation_Validator_SAX_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Validator_SAX_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_Validator_DOM_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            //exception will be thrown at trying to get DOM source
            DOMSource source = getDOMSource(_xmlFile, _xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_Validator_DOM_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Validator_DOM_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_Validator_StAX_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            StAXSource source = staxSourceFor(_xmlFileId, _xmlFile);
            validator.validate(source);
            fail("testSchemaLocation_Validator_StAX_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Validator_StAX_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLocation_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_JAXPProperty", e, "PE");
        }
    }

    public void testSchemaLocation_SAX_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            fail("testSchemaLocation_SAX_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_SAX_JAXPProperty", e, "PE");
        }
    }

    public void testSchemaLocation_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_JAXPPropertySFP", e, "PE");
        }
    }

    public void testSchemaLocation_SAX_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            fail("testSchemaLocation_SAX_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_SAX_JAXPPropertySFP", e, "PE");
        }
    }

    public void testSchemaLocation_Validator_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("validation.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_Validator_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Validator_JAXPPropertySFP", e, "PE");
        }
    }

    public void testSchemaLocation_Validator_SAX_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            //Schema schema = schemaFactory.newSchema(new StreamSource(Bug7192390EntityTest.class.getResourceAsStream("validation.xsd")));
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            fail("testSchemaLocation_Validator_SAX_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Validator_SAX_JAXPPropertySFP", e, "PE");
        }
    }

    public void testSchemaLocation_JAXPProperty1() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_JAXPProperty1 failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_JAXPProperty1", e, "PE");
        }
    }

    public void testSchemaLocation_SAX_JAXPProperty1() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            fail("testSchemaLocation_SAX_JAXPProperty1 failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_SAX_JAXPProperty1", e, "PE");
        }
    }

    public void testSchemaLocation_JAXPProperty1SFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_JAXPProperty1SFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_JAXPProperty1SFP", e, "PE");
        }
    }

    public void testSchemaLocation_SAX_JAXPProperty1SFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            fail("testSchemaLocation_SAX_JAXPProperty1SFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_SAX_JAXPProperty1SFP", e, "PE");
        }
    }

    public void testSchemaLocation_Validator_JAXPProperty1SFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            // Setting SFP should not change anything since ACCESS_EXTERNAL_DTD
            // is already set.
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            fail("testSchemaLocation_Validator_JAXPProperty1SFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Validator_JAXPProperty1SFP", e, "PE");
        }
    }

    public void testSchemaLocation_Validator_SAX_JAXPProperty1SFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            // Setting SFP should not change anything since ACCESS_EXTERNAL_DTD
            // is already set.
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            fail("testSchemaLocation_Validator_SAX_JAXPProperty1SFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLocation_Validator_SAX_JAXPProperty1SFP", e, "PE");
        }
    }

/////////////////////////////////////////////////
///////////noNamespaceSchemaLocation
/////////////////////////////////////////////////
    /**
     * within default limit
     */
    public void testSchemaLoading_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            success("testSchemaLoading_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLoading_default", e, "entity");
        }
    }

    public void testSchemaLoading_SAX_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlValFileId));
            validator.validate(source);
            success("testSchemaLoading_SAX_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLoading_SAX_default", e, "entity");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaLoading_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLoading_SAX_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlValFileId));
            validator.validate(source);
            fail("testSchemaLoading_SAX_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * in limit
     */
    public void testSchemaLoading_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            success("testSchemaLoading_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLoading_Secure", e, "entity");
        }
    }

    public void testSchemaLoading_SAX_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlValFileId));
            validator.validate(source);
            success("testSchemaLoading_SAX_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLoading_SAX_Secure", e, "entity");
        }
    }

    public void testSchemaLoading_Validator_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            success("testSchemaLoading_Validator_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLoading_Validator_Secure", e, "entity");
        }
    }

    public void testSchemaLoading_Validator_SAX_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource source = new SAXSource(new InputSource(_xmlValFileId));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            success("testSchemaLoading_Validator_SAX_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLoading_Validator_SAX_Secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testSchemaLoading_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLoading_SAX_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlValFileId));
            validator.validate(source);
            fail("testSchemaLoading_SAX_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLoading_Validator_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_Validator_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_Validator_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLoading_Validator_SAX_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource source = new SAXSource(new InputSource(_xmlValFileId));
            validator.validate(source);
            fail("testSchemaLoading_Validator_SAX_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_Validator_SAX_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * System property will override that set by FSP, but there is one which will
     * deny access...
     */
    public void testSchemaLoading_Secure_SP2() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_Secure_SP2 failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_Secure_SP2", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLoading_SAX_Secure_SP2() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlValFileId));
            validator.validate(source);
            fail("testSchemaLoading_SAX_Secure_SP2 failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_Secure_SP2", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLoading_Validator_Secure_SP2() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_Validator_Secure_SP2 failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_Validator_Secure_SP2", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testSchemaLoading_Validator_SAX_Secure_SP2() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource source = new SAXSource(new InputSource(_xmlValFileId));
            validator.validate(source);
            fail("testSchemaLoading_Validator_SAX_Secure_SP2 failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_Validator_SAX_Secure_SP2", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }

    }
    
    public void testSchemaLoading_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_JAXPProperty", e, "PE");
        }
    }

    public void testSchemaLoading_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_JAXPPropertySFP", e, "PE");
        }
    }

    public void testSchemaLoading_Validator_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_Validator_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_Validator_JAXPPropertySFP", e, "PE");
        }
    }


    public void testSchemaLoading_JAXPProperty1() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_JAXPProperty1 failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_JAXPProperty1", e, "PE");
        }
    }

    public void testSchemaLoading_JAXPProperty1SFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_JAXPProperty1SFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_JAXPProperty1SFP", e, "PE");
        }
    }

    public void testSchemaLoading_Validator_JAXPProperty1SFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_Validator_JAXPProperty1SFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_Validator_JAXPProperty1SFP", e, "PE");
        }
    }

    /**
     * SAXSource
     */
    public void testSchemaLoading_SAX_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlValFile));
            validator.validate(source);
            fail("testSchemaLoading_SAX_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_JAXPProperty", e, "PE");
        }
    }

    public void testSchemaLoading_SAX_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlValFile));
            validator.validate(source);
            fail("testSchemaLoading_SAX_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_JAXPPropertySFP", e, "PE");
        }
    }

    public void testSchemaLoading_SAX_Validator_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            SAXSource source = new SAXSource(new InputSource(_xmlValFile));
            validator.validate(source);
            fail("testSchemaLoading_SAX_Validator_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_Validator_JAXPPropertySFP", e, "PE");
        }
    }

    public void testSchemaLoading_SAX_JAXPProperty1() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            SAXSource source = new SAXSource(new InputSource(_xmlValFile));
            validator.validate(source);
            fail("testSchemaLoading_SAX_JAXPProperty1 failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_JAXPProperty1", e, "PE");
        }
    }

    public void testSchemaLoading_SAX_JAXPProperty1SFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            SAXSource source = new SAXSource(new InputSource(_xmlValFile));
            validator.validate(source);
            fail("testSchemaLoading_SAX_JAXPProperty1SFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_JAXPProperty1SFP", e, "PE");
        }
    }

    public void testSchemaLoading_SAX_Validator_JAXPProperty1SFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            schemaFactory.setProperty(ACCESS_EXTERNAL_SCHEMA, "file,http");
            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            validator.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            validator.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            SAXSource source = new SAXSource(new InputSource(_xmlValFile));
            validator.validate(source);
            fail("testSchemaLoading_SAX_Validator_JAXPProperty1SFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_SAX_Validator_JAXPProperty1SFP", e, "PE");
        }
    }

    /**
     * within limit
     */
    public void testSchemaLocation_schema() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(new FileInputStream(_xsdFile)));
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new FileInputStream(_xmlFile));
            source.setSystemId(_xmlFileId);
            validator.validate(source);
            success("testSchemaLocation_schema: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_schema", e, "entity");
        }
    }

    public void testSchemaLocation_SAX_schema() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(new FileInputStream(_xsdFile)));
            Validator validator = schema.newValidator();
            SAXSource source = new SAXSource(new InputSource(_xmlFileId));
            validator.validate(source);
            success("testSchemaLocation_SAX_schema: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaLocation_SAX_schema", e, "entity");
        }
    }

/////////////////////////////////////////////////
///////////XSD Import
/////////////////////////////////////////////////
    public void testSchemaImport_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdImport)));
            success("testSchemaImport_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaImport_default", e, "entity");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaImport_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdImport)));
            fail("testSchemaImport_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaImport_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * jaxp property takes preference
     */
    public void testSchemaImport_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdImport)));
            fail("testSchemaImport_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaImport_JAXPProperty", e, "PE");
        }
    }

    public void testSchemaImport_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdImport)));
            fail("testSchemaImport_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaImport_JAXPPropertySFP", e, "PE");
        }
    }

    /**
     * within limit
     */
    public void testSchemaImport_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdImport)));
            success("testSchemaImport_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaImport_Secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testSchemaImport_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdImport)));
            fail("testSchemaImport_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaImport_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

/////////////////////////////////////////////////
///////////XSD Include
/////////////////////////////////////////////////
    public void testSchemaInclude_default() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdInclude)));
            success("testSchemaInclude_default: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaInclude_default", e, "entity");
        }
    }

    /**
     * access may be granted using system property
     */
    public void testSchemaInclude_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdInclude)));
            fail("testSchemaInclude_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaInclude_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * jaxp property takes preference
     */
    public void testSchemaInclude_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdInclude)));
            fail("testSchemaInclude_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaInclude_JAXPProperty", e, "PE");
        }
    }

    public void testSchemaInclude_JAXPPropertySFP() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, SECURE_PROCESSING_TRUE);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdInclude)));
            fail("testSchemaInclude_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaInclude_JAXPPropertySFP", e, "PE");
        }
    }

    /**
     * in limit
     */
    public void testSchemaInclude_Secure() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdInclude)));
            success("testSchemaInclude_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testSchemaInclude_Secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testSchemaInclude_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdInclude)));
            fail("testSchemaInclude_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaInclude_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

}
