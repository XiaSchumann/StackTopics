package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary these tests require increase memory to pass
 * @run main/othervm -Xmx 500M IncreasedMemoryTest
 */
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import org.w3c.dom.Document;
import org.xml.sax.helpers.DefaultHandler;

/**
 * These tests would require increase memory to pass if without the fix limit; 
 * Compare with those in DefaultMemoryTest. 300M would have been enough for these 
 * tests to pass if limit is set to 20% of max memory
 * 
 * @author huizhe.wang@oracle.com
 */
public class OverLimitTest extends TestBase {
    final static String FIXEDTOTALLIMIT = "50000000";
    /**
     * Creates a new instance of StreamReader
     */
    public OverLimitTest(String name) {
        super(name);
    }
    
    protected void setUp() {
        super.setUp();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        OverLimitTest test = new OverLimitTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();
            test.testSAXPESL_5M_Overlimit();
            test.testSAXPESL_2M_Overlimit();
            test.testSAXPESL_100K_Overlimit();
            
            test.testDOMPESL_5M_Overlimit();
            test.tearDown();
        }

    }
    

    //////////////////////////////////////////////////////////////
    ///////////These tests are executed with increased memory/////
    //////////////////////////////////////////////////////////////
    //maxParameterEntitySizeLimit tests
    
    /**
     * within a limit of 5,000,000, 9x7x10 would have caused OOME 
     */
    public void testSAXPESL_10x10_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "90000000");
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "5000000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE10x10), new DefaultHandler());
            fail("testSAXPESL_5M_Overlimit failed: maxParameterEntitySizeLimit: shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXPESL_5M_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }    

    /**
     * within a limit of 5,000,000, 9x7x10 would have caused OOME 
     */
    public void testSAXPESL_5M_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, FIXEDTOTALLIMIT);
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "5000000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE9x7x11), new DefaultHandler());
            fail("testSAXPESL_5M_Overlimit failed: maxParameterEntitySizeLimit: shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXPESL_5M_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }    
    
    /**
     * within a limit of 2,000,000, 11x6x32 would have caused OOME but for 
     * increased memory
     */
    public void testSAXPESL_2M_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, FIXEDTOTALLIMIT);
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "2000000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE11x6x32), new DefaultHandler());
            fail("testSAXPESL_2M_Overlimit: maxParameterEntitySizeLimit: shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXPESL_2M_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }    
    
    /**
     * within a limit of 100,000, 5x7x655 would have caused OOME but for 
     * increased memory
     */
    public void testSAXPESL_100K_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, FIXEDTOTALLIMIT);
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "100000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE5x7x655), new DefaultHandler());
            fail("testSAXPESL_100K_Overlimit: maxParameterEntitySizeLimit: shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXPESL_100K_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }    

    /**
     * within a limit of 5,000,000, 9x7x10 would have caused OOME 
     */
    public void testDOMPESL_5M_Overlimit() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(JDK_TOTAL_ENTITY_SIZE_LIMIT, FIXEDTOTALLIMIT);
            dbf.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "5000000");
            dbf.setAttribute(JDK_ENTITY_COUNT_INFO, "yes");
            docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new File(_xmlPE9x7x11));            
            fail("testSAXPESL_5M_Overlimit failed: maxParameterEntitySizeLimit: shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXPESL_5M_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }   
    
    public void testDOMPESL_2M_Overlimit() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(JDK_TOTAL_ENTITY_SIZE_LIMIT, FIXEDTOTALLIMIT);
            dbf.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "2000000");
            dbf.setAttribute(JDK_ENTITY_COUNT_INFO, "yes");
            docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new File(_xmlPE11x6x32));            
            fail("testDOMPESL_2M_Overlimit failed: maxParameterEntitySizeLimit: shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMPESL_2M_Overlimit", e, "maxParameterEntitySizeLimit");
        }

    }   

    public void testDOMPESL_100k_Overlimit() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(JDK_TOTAL_ENTITY_SIZE_LIMIT, FIXEDTOTALLIMIT);
            dbf.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "100000");
            dbf.setAttribute(JDK_ENTITY_COUNT_INFO, "yes");
            docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new File(_xmlPE5x7x655));            
            fail("testDOMPESL_100k_Overlimit failed: maxParameterEntitySizeLimit: shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMPESL_100k_Overlimit", e, "maxParameterEntitySizeLimit");
        }

    }   
    
}
