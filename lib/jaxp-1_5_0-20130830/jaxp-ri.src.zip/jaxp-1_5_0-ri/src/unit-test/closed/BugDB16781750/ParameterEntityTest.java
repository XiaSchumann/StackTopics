package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test entity expansion limit
 * @run main/othervm OneTest
 */
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.SAXParser;
import org.w3c.dom.Document;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Total entity size limit tests
 *
 * @author huizhe.wang@oracle.com
 */
public class ParameterEntityTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public ParameterEntityTest(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        ParameterEntityTest test = new ParameterEntityTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();
            test.testSAXPESL_Default();
            test.testSAXPESL_FSPOn();
            test.testSAXPESL_FSPOff();
            test.testSAXPESL_SP_OverLimit();
            test.testSAXPESL_API_Overlimit();
            test.testSAXPESL_API_SP();
            
            test.testDOMPESL_Default();
            test.testDOMPESL_FSPOn();
            test.testDOMPESL_FSPOff();
            test.testDOMPESL_SP_OverLimit();
            test.testDOMPESL_API_Overlimit();
            test.testDOMPESL_API_SP();
            test.tearDown();
        }

    }
    
    /////////////////////////////////////////////////
    ///////////General Entity Reference
    /////////////////////////////////////////////////
    
    //maxParameterEntitySizeLimit tests
    /**
     * By default, the limit is 1,000,000
     */
    public void testSAXPESL_Default() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE5x5), new DefaultHandler());
            success("testSAXPESL_Default passed: maxParameterEntitySizeLimit");
        } catch (Exception e) {
            unexpectedException("testSAXPESL_Default", e, "maxParameterEntitySizeLimit");
        }
    }

    /**
     * By default, FEATURE_SECURE_PROCESSING is true, setting FSP therefore 
     * does not make any difference
     */
    public void testSAXPESL_FSPOn() {

        try {
            SAXParser parser = getSAXParser(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_TRUE);
            parser.parse(new File(_xmlPE5x5), new DefaultHandler());
            success("testSAXGESL_FSPOn: maxParameterEntitySizeLimit test passed");
        } catch (Exception e) {
            unexpectedException("testSAXGESL_FSPOn", e, "entityExpansion");
        }
    }

    /**
     * Set FEATURE_SECURE_PROCESSING to false, no limit
     */
    public void testSAXPESL_FSPOff() {

        try {
            SAXParser parser = getSAXParser(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_FALSE);
            parser.parse(new File(_xmlPE5x5), new DefaultHandler());
            success("testSAXGESL_FSPOff: maxParameterEntitySizeLimit test passed: no limit");
        } catch (Exception e) {
            unexpectedException("testSAXGESL_FSPOff", e, "entityExpansion");
        }
    }
    
    /**
     * Use system property to set a limit
     */
    public void testSAXPESL_SP_OverLimit() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");

        try {
            SAXParser parser = getSAXParser();
            parser.parse(new File(_xmlPE5x5), new DefaultHandler());
            fail("testSAXPESL_SP_OverLimit failed: over the maxParameterEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXPESL_SP_OverLimit", e, "maxParameterEntitySizeLimit");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }    
    
    /**
     * Use API property to set a limit
     */
    public void testSAXPESL_API_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE5x5), new DefaultHandler());
            fail("testSAXPESL_API_Overlimt failed: maxParameterEntitySizeLimit test failed");
        } catch (Exception e) {
            expectedException("testSAXPESL_API_Overlimt", e, "maxParameterEntitySizeLimit");
        }
    }
    /**
     * The API property override any that may be set by other means
     */
    public void testSAXPESL_API_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE5x5), new DefaultHandler());
            success("testSAXPESL_API_SP: maxParameterEntitySizeLimit test passed");
        } catch (Exception e) {
            unexpectedException("testSAXPESL_API_SP", e, "maxParameterEntitySizeLimit");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }
    
    /**
     * By default, the limit is 1,000,000
     */
    public void testDOMPESL_Default() {

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlPE5x5));
            success("testDOMPESL_Default: maxParameterEntitySizeLimit passed");
        } catch (Exception e) {
            unexpectedException("testDOMPESL_Default", e, "maxParameterEntitySizeLimit");
        }
    }
    
        
    /**
     * By default, FEATURE_SECURE_PROCESSING is already true, but let's still
     * test setting FSP explicitly 
     */
    public void testDOMPESL_FSPOn() {

        DocumentBuilder docBuilder = getDOMBuilder(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_TRUE);
        try {
            Document document = docBuilder.parse(new File(_xmlPE5x5));
            success("testDOMPESL_FSPOn: maxParameterEntitySizeLimit test passed");
        } catch (Exception e) {
            expectedException("testDOMPESL_FSPOn", e, "entityExpansion");
        }
    }

    /**
     * Set FEATURE_SECURE_PROCESSING to false, no limit
     */
    public void testDOMPESL_FSPOff() {

        DocumentBuilder docBuilder = getDOMBuilder(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_FALSE);
        try {
            Document document = docBuilder.parse(new File(_xmlPE5x5));
            success("testDOMPESL_FSPOff: maxParameterEntitySizeLimit test passed: no limit");
        } catch (Exception e) {
            unexpectedException("testDOMPESL_FSPOff", e, "maxParameterEntitySizeLimit");
        }
    }   
    
    /**
     * Use system property to set a limit
     */
    public void testDOMPESL_SP_OverLimit() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlPE5x5));
            fail("testDOMPESL_SP_OverLimit failed: over the maxParameterEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMPESL_SP_OverLimit", e, "maxParameterEntitySizeLimit");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }    
    /**
     * Use API property to set a limit
     */
    public void testDOMPESL_API_Overlimit() {

        DocumentBuilder docBuilder = getDOMBuilder(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            Document document = docBuilder.parse(new File(_xmlPE5x5));            
            fail("testDOMPESL_API_Overlimit failed: over the maxParameterEntitySizeLimitLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMPESL_API_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }    
        
    /**
     * The API property overrides any that may be set by other means
     */
    public void testDOMPESL_API_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");

        DocumentBuilder docBuilder = getDOMBuilder(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3500");
        try {
            Document document = docBuilder.parse(new File(_xmlPE5x5));            
            success("testDOMPESL_API_SP: maxParameterEntitySizeLimitLimit test passed");
        } catch (Exception e) {
            unexpectedException("testDOMPESL_API_SP", e, "maxParameterEntitySizeLimit");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }    
        
}
