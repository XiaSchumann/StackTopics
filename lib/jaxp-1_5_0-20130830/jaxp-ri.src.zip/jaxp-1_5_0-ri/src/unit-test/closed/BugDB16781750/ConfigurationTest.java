/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.BugDB16781750;

import javax.xml.transform.*;
import com.sun.org.apache.xerces.internal.impl.Constants;
import com.sun.org.apache.xerces.internal.parsers.*;
import java.io.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;

import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

/**
 * <p>Test {@link javax.xml.transform.Transformer} for JDK-8022548: SPECJVM2008
 * has errors introduced in 7u40-b34 </p>
 *
 * @author Joe Wang <huizhe.wang@oracle.com>
 *
 */
public class ConfigurationTest  extends TestBase {
    static final String SECURITY_MANAGER = Constants.XERCES_PROPERTY_PREFIX + Constants.SECURITY_MANAGER_PROPERTY;
    public ConfigurationTest(String name) {
        super(name);
    }
    
    String inFilename = "./jaxp-ri/src/unit-test/javax/xml/transform/JDK8022548.xml";
    String xslFilename = "./jaxp-ri/src/unit-test/javax/xml/transform/JDK8022548.xsl";
    String outFilename = "./jaxp-ri/src/unit-test/javax/xml/transform/JDK8022548.out";

    public static void main(String[] args) throws Exception {
        ConfigurationTest test = new ConfigurationTest("OneTest");

            test.setUp();

            //test.testSAXDefault();
            //test.testDOMGE_Default();
            //test.testStAXGE_API_OverLimit();
            test.testSchemaImport_JAXPProperty();
            test.tearDown();

    }

    String _xmlFile, _xsdFile, _xmlValFile, _xsdValFile, _xsdImport, _xsdInclude;
    String _xmlFileId, _xmlValFileId;
    
    protected void setUp() {
        super.setUp();
        _xmlFile = _filepath + "/val_test.xml";
        _xsdFile = _filepath + "/val_test.xsd";
        _xmlValFile = _filepath + "/validation.xml";
        _xsdValFile = _filepath + "/validation.xsd";
        _xsdImport = _filepath + "/XSDImport_company.xsd";
        _xsdInclude = _filepath + "/XSDInclude_company.xsd";
        
        if (isWindows) {
            _xmlFile = "/" + _xmlFile;
            _xsdFile = "/" + _xsdFile;
            _xmlValFile = "/" + _xmlValFile;
            _xsdValFile = "/" + _xsdValFile;
            _xsdImport = "/" + _xsdImport;
            _xsdInclude = "/" + _xsdInclude;
        }        
        
        _xmlFileId = "file://" + _xmlFile;
        _xmlValFileId = "file://" + _xmlValFile;
    }
    
    public void testSAXDefault() {
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            javax.xml.parsers.SAXParser parser = spf.newSAXParser();
            com.sun.org.apache.xerces.internal.util.SecurityManager manager =
                    new com.sun.org.apache.xerces.internal.util.SecurityManager();
            parser.setProperty(SECURITY_MANAGER, manager);
            parser.parse(new File(_xmlGE9), new DefaultHandler());

            System.out.println("passed");
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }

    public void testDOMGE_Default() {
            com.sun.org.apache.xerces.internal.util.SecurityManager manager =
                    new com.sun.org.apache.xerces.internal.util.SecurityManager();
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setAttribute(SECURITY_MANAGER, manager);
            docBuilder = dbf.newDocumentBuilder();
            Document document = docBuilder.parse(new File(_xmlGE64005));
            success("testDOMGE_Default: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGE_Default", e, "entityExpansion");
        }
    }
    
    public void testStAXGE_API_OverLimit() {
            com.sun.org.apache.xerces.internal.util.SecurityManager manager =
                    new com.sun.org.apache.xerces.internal.util.SecurityManager();
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(SECURITY_MANAGER, manager);
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testSAXGE_API_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGE_API_OverLimit", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    
    
    public void testSchemaImport_JAXPProperty() {
            com.sun.org.apache.xerces.internal.util.SecurityManager manager =
                    new com.sun.org.apache.xerces.internal.util.SecurityManager();

        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(SECURITY_MANAGER, manager);
            Schema schema = schemaFactory.newSchema(new StreamSource(new File(_xsdImport)));
            fail("testSchemaImport_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaImport_JAXPProperty", e, "PE");
        }
    }
    
    public final void testTransform() {

        try {



            StringWriter sw = new StringWriter();
            // Create transformer factory
            TransformerFactory factory = TransformerFactory.newInstance();
            // set the translet name
//            factory.setAttribute("translet-name", "myTranslet");

            // set the destination directory
//            factory.setAttribute("destination-directory", "c:\\temp");
//            factory.setAttribute("generate-translet", Boolean.TRUE);

            // Use the factory to create a template containing the xsl file
            Templates template = factory.newTemplates(new StreamSource(new FileInputStream(xslFilename)));
            // Use the template to create a transformer
            Transformer xformer = template.newTransformer();
            // Prepare the input and output files
            Source source = new StreamSource(new FileInputStream(inFilename));
            Result result = new StreamResult(new FileOutputStream(outFilename));
            //Result result = new StreamResult(sw);
            // Apply the xsl file to the source file and write the result to the output file
            xformer.transform(source, result);

            /**
             * String out = sw.toString(); if (out.indexOf("<p>") < 0 ) {
             * fail(out); }
             */
            String canonicalizedFileName = outFilename + ".canonicalized";
            canonicalize(outFilename, canonicalizedFileName);
        } catch (Exception e) {
            // unexpected failure
            e.printStackTrace();
            fail(e.toString());
        }
    }

    public void canonicalize(String inName, String outName) {
        try {
            //FileOutputStream outStream = new FileOutputStream(outName);
            FileInputStream inputStream = new FileInputStream(inName);
            JDK15XML1_0Parser parser = new JDK15XML1_0Parser();
            parser.parse(new InputSource(inputStream));

            inputStream.close();
            System.out.println("passed");
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }

    class JDK15XML1_0Parser extends SAXParser {

        JDK15XML1_0Parser() throws org.xml.sax.SAXException {

            super(new DTDConfiguration());
            // workaround for Java 1.5 beta 2 bugs
            com.sun.org.apache.xerces.internal.util.SecurityManager manager =
                    new com.sun.org.apache.xerces.internal.util.SecurityManager();
            setProperty(Constants.XERCES_PROPERTY_PREFIX + Constants.SECURITY_MANAGER_PROPERTY, manager);

        }
    }
}
