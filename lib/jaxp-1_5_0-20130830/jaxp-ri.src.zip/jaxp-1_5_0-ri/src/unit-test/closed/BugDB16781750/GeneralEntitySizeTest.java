package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test entity expansion limit
 * @run main/othervm OneTest
 */
import com.sun.org.apache.xerces.internal.impl.Constants;
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.SAXParser;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import org.w3c.dom.Document;
import org.xml.sax.helpers.DefaultHandler;

/**
 * General entity size tests
 *
 * @author huizhe.wang@oracle.com
 */
public class GeneralEntitySizeTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public GeneralEntitySizeTest(String name) {
        super(name);
    }
    String _xmlGENotDeclared;
    String _xmlGE9; 
    String _xmlGE64005, _xmlGE64005Id;
    String _xmlGE64006, _xmlGE64005_10000;
    
    protected void setUp() {
        super.setUp();
        _xmlGENotDeclared = _filepath + "/testGENotDeclared.xml";
        _xmlGE9 = _filepath + "/testGE9.xml";
        _xmlGE64005 = _filepath + "/testGE64005.xml";
        _xmlGE64006 = _filepath + "/testGE64006.xml";
        _xmlGE64005_10000 = _filepath + "/testGE64005_10000.xml";
        
        if (isWindows) {
            _xmlGENotDeclared = "/" + _xmlGENotDeclared;
            _xmlGE9 = "/" + _xmlGE9;
            _xmlGE64005 = "/" + _xmlGE64005;
            _xmlGE64006 = "/" + _xmlGE64006;
            _xmlGE64005_10000 = "/" + _xmlGE64005_10000;
        }        
        
        _xmlGE64005Id = "file:" + _xmlGE64005;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        GeneralEntitySizeTest test = new GeneralEntitySizeTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();
test.testStAXER_GESL_API_OverLimit();

/**
            test.testSAXGESL_Default();
            test.testSAXGESL_FSPOn();
            test.testSAXGESL_FSPOff();
            test.testSAXGESL_SP_OverLimit();
            test.testSAXGESL_API_Overlimit();
            test.testSAXGESL_API_SP();
            
            test.testDOMGESL_Default();
            test.testDOMGESL_FSPOn();
            test.testDOMGESL_FSPOff();
            test.testDOMGESL_SP_OverLimit();
            test.testDOMGESL_API_Overlimit();
            test.testDOMGESL_API_SP();

            test.testStAXGESL_Default();
            test.testStAXGESL_SP_OverLimit();
            test.testStAXGESL_API_OverLimit();
            test.testStAXGESL_NotSupportDTD();
            test.testStAXGESL_isReplacingEntityReferences();      
            */
            test.tearDown();
        }

    }
    
    /////////////////////////////////////////////////
    ///////////General Entity Reference
    /////////////////////////////////////////////////
    
    //GeneralEntitySizeLimit tests
    /**
     * By default, there's no limit on entity size
     */
    public void testSAXGESL_Default() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlGE64005), new DefaultHandler());
            success("testSAXGESL_Default: GeneralEntitySizeLimit test passed");
        } catch (Exception e) {
            unexpectedException("testSAXGESL_Default", e, "GeneralEntitySizeLimit");
        }
    }

    /**
     * By default, FEATURE_SECURE_PROCESSING is true, setting FSP therefore 
     * does not make any difference
     */
    public void testSAXGESL_FSPOn() {

        try {
            SAXParser parser = getSAXParser(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_TRUE);
            parser.parse(new File(_xmlGE64005), new DefaultHandler());
            success("testSAXGESL_FSPOn: generalEntitySize test passed");
        } catch (Exception e) {
            unexpectedException("testSAXGESL_FSPOn", e, "generalEntitySize");
        }
    }

    /**
     * Set FEATURE_SECURE_PROCESSING to false, no limit
     */
    public void testSAXGESL_FSPOff() {

        try {
            SAXParser parser = getSAXParser(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_FALSE);
            parser.parse(new File(_xmlGE64006), new DefaultHandler());
            success("testSAXGESL_FSPOff: generalEntitySize test passed");
        } catch (Exception e) {
            unexpectedException("testSAXGESL_FSPOff", e, "generalEntitySize");
        }
    }
    
    /**
     * Use system property to set a limit
     */
    public void testSAXGESL_SP_OverLimit() {
        System.setProperty(SP_GENEAL_ENTITY_SIZE_LIMIT, "150");

        try {
            SAXParser parser = getSAXParser();
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            fail("testSAXGESL_SP_OverLimit failed: over the GeneralEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGESL_SP_OverLimit", e, "GeneralEntitySizeLimit");
        } finally {
            System.clearProperty(SP_GENEAL_ENTITY_SIZE_LIMIT);
        }
    }    
    
    /**
     * Use API property to set a limit
     */
    public void testSAXGESL_API_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_GENEAL_ENTITY_SIZE_LIMIT, "150");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            fail("testSAXGE_SP_OverLimit failed: GeneralEntitySizeLimit test failed");
        } catch (Exception e) {
            expectedException("testSAXGE_SP_OverLimit", e, "GeneralEntitySizeLimit");
        }
    }
    /**
     * The API property override any that may be set by other means
     */
    public void testSAXGESL_API_SP() {
        System.setProperty(SP_GENEAL_ENTITY_SIZE_LIMIT, "150");

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_GENEAL_ENTITY_SIZE_LIMIT, "250");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            success("testSAXGESL_API_SP: GeneralEntitySizeLimit test passed");
        } catch (Exception e) {
            unexpectedException("testSAXGE_SP_OverLimit", e, "GeneralEntitySizeLimit");
        } finally {
            System.clearProperty(SP_GENEAL_ENTITY_SIZE_LIMIT);
        }
    }
    
    /**
     * By default, there's no limit on entity size
     */
    public void testDOMGESL_Default() {

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));
            success("testDOMGESL_Default: GeneralEntitySizeLimit test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGESL_Default", e, "GeneralEntitySizeLimit");
        }
    }
    /**
     * By default, FEATURE_SECURE_PROCESSING is already true, but let's still
     * test setting FSP explicitly 
     */
    public void testDOMGESL_FSPOn() {

        DocumentBuilder docBuilder = getDOMBuilder(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_TRUE);
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));
            success("testDOMGESL_FSPOn: GeneralEntitySizeLimit test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGESL_FSPOn", e, "GeneralEntitySizeLimit");
        }
    }

    /**
     * Set FEATURE_SECURE_PROCESSING to false, no limit
     */
    public void testDOMGESL_FSPOff() {

        DocumentBuilder docBuilder = getDOMBuilder(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_FALSE);
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));
            success("testDOMGESL_FSPOff: GeneralEntitySizeLimit test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGESL_FSPOff", e, "GeneralEntitySizeLimit");
        }
    }    
    /**
     * Use system property to set a limit
     */
    public void testDOMGESL_SP_OverLimit() {
        System.setProperty(SP_GENEAL_ENTITY_SIZE_LIMIT, "150");

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));
            fail("testDOMGESL_SP_OverLimit failed: over the GeneralEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMGESL_SP_OverLimit", e, "GeneralEntitySizeLimit");
        } finally {
            System.clearProperty(SP_GENEAL_ENTITY_SIZE_LIMIT);
        }
    }    
    /**
     * Use API property to set a limit
     */
    public void testDOMGESL_API_Overlimit() {

        DocumentBuilder docBuilder = getDOMBuilder(JDK_GENEAL_ENTITY_SIZE_LIMIT, "150");
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));            
            fail("testDOMGESL_API_Overlimit failed: over the GeneralEntitySizeLimitLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMGESL_API_Overlimit", e, "GeneralEntitySizeLimit");
        }
    }    
        
    /**
     * The API property overrides any that may be set by other means
     */
    public void testDOMGESL_API_SP() {
        System.setProperty(SP_GENEAL_ENTITY_SIZE_LIMIT, "150");

        DocumentBuilder docBuilder = getDOMBuilder(JDK_GENEAL_ENTITY_SIZE_LIMIT, "250");
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));            
            success("testDOMGESL_API_SP: GeneralEntitySizeLimitLimit test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGESL_API_SP", e, "GeneralEntitySizeLimit");
        } finally {
            System.clearProperty(SP_GENEAL_ENTITY_SIZE_LIMIT);
        }
    }    
        
    /**
     * StAX
     */
    /**
     * By default, there's no limit on entity size
     */
    public void testStAXGESL_Default() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE64005, new FileInputStream(new File(_xmlGE64005)));
            readDTD(xsr);
            success("testSAXDefault_OverLimit: generalEntitySize test passed");
        } catch (Exception e) {
            unexpectedException("testSAXDefault_OverLimit", e, "generalEntitySize");
            e.printStackTrace();
        }
    }
    /**
     * Largest entity = 200, 
     */
    public void testStAXGESL_SP_OverLimit() {
        System.setProperty(SP_GENEAL_ENTITY_SIZE_LIMIT, "150");
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testStAXGESL_SP_OverLimit: over the generalEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testStAXGESL_SP_OverLimit", e, "generalEntitySize");
        } finally {
            System.clearProperty(SP_GENEAL_ENTITY_SIZE_LIMIT);
        }
    }    

    /**
     * Parsing a file that contains an entity of size 200 with a limit set to 150 through the
     * API property; API property always take preference
     */
    public void testStAXGESL_API_OverLimit() {
        System.setProperty(SP_GENEAL_ENTITY_SIZE_LIMIT, "250");

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(JDK_GENEAL_ENTITY_SIZE_LIMIT, "150");
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testSAXGE_API_OverLimit: over the generalEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGE_API_OverLimit", e, "generalEntitySize");
        } finally {
            System.clearProperty(SP_GENEAL_ENTITY_SIZE_LIMIT);
        }
    }    
    
    /**
     * When SupportDTD=false, entity reference will result in an error
     */
    public void testStAXGESL_NotSupportDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testStAXGESL_NotSupportDTD: SupportDTD=false, shall throw exception");
        } catch (Exception e) {
            expectedException("testStAXGESL_NotSupportDTD", e, "generalEntitySize");
        }
    }

    /**
     * When IS_REPLACING_ENTITY_REFERENCES=false, entity will not be started. The parser
     * returns entity reference without resolving it
     */
    public void testStAXGESL_isReplacingEntityReferences() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            success("testStAXGESL_isReplacingEntityReferences: IS_REPLACING_ENTITY_REFERENCES=false, passed");
        } catch (Exception e) {
            unexpectedException("testStAXGESL_isReplacingEntityReferences", e, "generalEntitySize");
        }
    }
    
    /**
     * By default, there's no limit on entity size
     */
    public void testStAXER_GESL_Default() {

        try {
            XMLInputFactory inputFactory = XMLInputFactory.newInstance();
            XMLEventReader er = inputFactory.createXMLEventReader(_xmlGE64005, new FileInputStream(_xmlGE64005));
            
            readEvent(er);
            success("testSAXDefault_OverLimit: generalEntitySize test passed");
        } catch (Exception e) {
            unexpectedException("testSAXDefault_OverLimit", e, "generalEntitySize");
        }
    }

    public void testStAXER_GESL_SP_OverLimit() {
        System.setProperty(SP_GENEAL_ENTITY_SIZE_LIMIT, "150");

        try {
            XMLInputFactory inputFactory = XMLInputFactory.newInstance();
            XMLEventReader er = inputFactory.createXMLEventReader(_xmlGE64005, new FileInputStream(_xmlGE64005));
            
            readEvent(er);
            fail("testStAXER_GESL_SP_OverLimit: over the generalEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testStAXER_GESL_SP_OverLimit", e, "generalEntitySize");
        } finally {
            System.clearProperty(SP_GENEAL_ENTITY_SIZE_LIMIT);
        }
    }
    
    /**
     * Parsing a file that contains an entity of size 200 with a limit set to 150 through the
     * API property; API property always take preference
     */
    public void testStAXER_GESL_API_OverLimit() {
        System.setProperty(SP_GENEAL_ENTITY_SIZE_LIMIT, "250");

        try {
            XMLInputFactory inputFactory = XMLInputFactory.newInstance();
            inputFactory.setProperty(JDK_GENEAL_ENTITY_SIZE_LIMIT, "150");
            XMLEventReader er = inputFactory.createXMLEventReader(_xmlGE9, new FileInputStream(_xmlGE9));
            
            readEvent(er);
            fail("testSAXGE_API_OverLimit: over the generalEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGE_API_OverLimit", e, "generalEntitySize");
        } finally {
            System.clearProperty(SP_GENEAL_ENTITY_SIZE_LIMIT);
        }
    }    
    
    /**
     * When SupportDTD=false, entity reference will result in an error
     */
    public void testStAXER_GESL_NotSupportDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLEventReader er = xif.createXMLEventReader(_xmlGE9, new FileInputStream(_xmlGE9));            
            readEvent(er);
            fail("testStAXGESL_NotSupportDTD: SupportDTD=false, shall throw exception");
        } catch (Exception e) {
            expectedException("testStAXGESL_NotSupportDTD", e, "generalEntitySize");
        }
    }

    /**
     * When IS_REPLACING_ENTITY_REFERENCES=false, entity will not be started. The parser
     * returns entity reference without resolving it
     */
    public void testStAXER_GESL_isReplacingEntityReferences() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLEventReader er = xif.createXMLEventReader(_xmlGE9, new FileInputStream(_xmlGE9));            
            readEvent(er);
            success("testStAXGESL_isReplacingEntityReferences: IS_REPLACING_ENTITY_REFERENCES=false, passed");
        } catch (Exception e) {
            unexpectedException("testStAXGESL_isReplacingEntityReferences", e, "generalEntitySize");
        }
    }
}
