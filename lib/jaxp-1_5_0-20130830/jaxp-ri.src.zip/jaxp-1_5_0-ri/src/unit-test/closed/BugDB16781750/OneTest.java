package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test XSLT portion of external reference restriction
 * @run main/othervm OneTest
 */
import com.sun.org.apache.xerces.internal.impl.Constants;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * One test
 * 
 * @author huizhe.wang@oracle.com
 */
public class OneTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public OneTest(String name) {
        super(name);
    }
    
    String _xmlSample_Templates, _xmlPE11x6x32;
    String _xmlFile, _xsdFile, _xmlValFile, _xsdValFile, _xsdImport, _xsdInclude;
    String _xmlFileId, _xmlValFileId;
    

    protected void setUp() {
        super.setUp();
        _xmlSample_Templates = _filepath + "/Templates.xml";    
        if (isWindows) {
            _xmlSample_Templates = "/" + _xmlSample_Templates;
        }    
        _xmlFile = _filepath + "/val_test.xml";
        _xsdFile = _filepath + "/val_test.xsd";
        _xmlValFile = _filepath + "/validation.xml";
        _xsdValFile = _filepath + "/validation.xsd";
        _xsdImport = _filepath + "/XSDImport_company.xsd";
        _xsdInclude = _filepath + "/XSDInclude_company.xsd";
        
        if (isWindows) {
            _xmlFile = "/" + _xmlFile;
            _xsdFile = "/" + _xsdFile;
            _xmlValFile = "/" + _xmlValFile;
            _xsdValFile = "/" + _xsdValFile;
            _xsdImport = "/" + _xsdImport;
            _xsdInclude = "/" + _xsdInclude;
        }        
        
        _xmlFileId = "file://" + _xmlFile;
        _xmlValFileId = "file://" + _xmlValFile;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        OneTest test = new OneTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();

            //test.testSAXGETESL_Default();
            test.testSchemaLoading_JAXPProperty();
            test.tearDown();
        }

    }
    public void testSchemaLoading_JAXPProperty() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");

            Schema schema = schemaFactory.newSchema();
            Validator validator = schema.newValidator();
            StreamSource source = new StreamSource(new File(_xmlValFile));
            source.setSystemId(_xmlValFileId);
            validator.validate(source);
            fail("testSchemaLoading_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSchemaLoading_JAXPProperty", e, "PE");
        }
    }

    /**
     * By default, no limit 
     */
    public void testMemoryUsage() {
        reportMemUsuage("before test:");
        long mem0 = startMemory();
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            //dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            //dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, Boolean.TRUE);
            dbf.setNamespaceAware(true);
            dbf.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "5000000");
            dbf.setAttribute(JDK_ENTITY_COUNT_INFO, "yes");
            DocumentBuilder db = dbf.newDocumentBuilder();

//            InputSource is = new InputSource(new FileInputStream(file));
//            is.setSystemId(file);
//            Document doc = db.parse(new FileInputStream(_xmlPE3by3), _xmlPE3by3id);
//            Document doc = db.parse(new File(_xmlSchemaXSD)); 
            Document doc = db.parse(new File(_xmlPE10by10)); 
            //printDOMTree(doc);
        } catch (OutOfMemoryError oom) {
            oom.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            long memUsed1 = mem0 - endMemory();
            System.out.println("Memory used: " + memUsed1 / 1024 / 1024 + "MB");
            final long usedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            System.out.println("Memory used: usedMem=" + usedMem / 1024 / 1024 + "MB");
        }
    }

    public void printDOMTree(Document doc) {
        OutputStreamWriter outWriter = null;
        try {
            outWriter = new OutputStreamWriter(System.out, DOMEcho.outputEncoding);
            PrintWriter writer = new PrintWriter(outWriter, true);
            DOMEcho echo = new DOMEcho(writer);
            new DOMEcho(new PrintWriter(outWriter, true)).echo(doc);
        } catch (UnsupportedEncodingException ex) {        
            ex.printStackTrace();
        } finally {
            try {
                outWriter.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    protected void setUp1() {
        super.setUp();
System.out.println("\n filepath: " + _filepath);
        if (isWindows) {
            _filepath = _filepath.replace('\\', '/');
System.out.println("is windows, replace \\ with /, _filepath: " +_filepath);
        _xmlGENotDeclared = "/" + _filepath + "/testGENotDeclared.xml";
        _xmlGE9 = "/" + _filepath + "/testGE9.xml";
        _xmlGE64005 = "/" + _filepath + "/testGE64005.xml";
System.out.println("is windows?, _xmlGE64005: " +_xmlGE64005);
        _xmlGE64006 = "/" + _filepath + "/testGE64006.xml";
        } else {
        _xmlGE9 = _filepath + "/testGE9.xml";
        _xmlGE64005 = _filepath + "/testGE64005.xml";
System.out.println("not windows?, _filepath" +_filepath);
System.out.println("not windows?, _xmlGE64005" +_xmlGE64005);
        _xmlGE64006 = _filepath + "/testGE64006.xml";
        }        
        _xmlGE64005Id = "file:" + _xmlGE64005;
        
System.out.println("is windows?, _xmlGE64005Id: " +_xmlGE64005Id);
        
      
    }

    long startMemory() {
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        long memFree = Runtime.getRuntime().freeMemory();
        return memFree;
    }

    long endMemory() {
        long memFree = Runtime.getRuntime().freeMemory();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        return memFree;
    }

    void reportMemUsuage(String msg) {
        System.out.println(msg);
        long memTotal = Runtime.getRuntime().totalMemory();
        long memFree = Runtime.getRuntime().freeMemory();
        long maxBytes = Runtime.getRuntime().maxMemory();
        System.out.println("Memory in JVM: \nMax: " + maxBytes / 1024 / 1024 + "MB \nTotal available: " + memTotal / 1024 / 1024 + "MB \nFree: " + memFree / 1024 / 1024 + "M");
    }
    
}
