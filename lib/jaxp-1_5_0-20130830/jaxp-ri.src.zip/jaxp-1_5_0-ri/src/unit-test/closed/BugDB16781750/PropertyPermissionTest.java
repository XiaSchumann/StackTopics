package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test that permissions are granted for reading the new properties 
 * @run main/othervm PropertyPermissionTest
 */
import java.io.*;
import javax.xml.parsers.SAXParser;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Compare with those in Increased Memory test
 * 
 * @author huizhe.wang@oracle.com
 */
public class PropertyPermissionTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public PropertyPermissionTest(String name) {
        super(name);
    }
    
    protected void setUp() {
        super.setUp();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        PropertyPermissionTest test = new PropertyPermissionTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();

            
            test.testSAXPESL_5M();
            test.testSAXPESL_2M();
            test.testSAXPESL_100K();
            test.tearDown();
        }

    }
    

    //////////////////////////////////////////////////////////////
    ///////////These tests are executed with increased memory/////
    //////////////////////////////////////////////////////////////

    
    //maxParameterEntitySizeLimit tests
    
    /**
     * within a limit of 5,000,000, 9x7x9 are ok with default memory on
     * client VM
     */
    public void testSAXPESL_5M() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "62000000");
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "5000000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE9x7x10), new DefaultHandler());
            success("testSAXPESL_5M: maxParameterEntitySizeLimit");
        } catch (Exception e) {
            unexpectedException("testSAXPESL_5M", e, "maxParameterEntitySizeLimit");
        }
    }    
    
    /**
     * within a limit of 2,000,000, 11x6x31 are ok with default memory on
     * client VM
     */
    public void testSAXPESL_2M() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "62000000");
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "2000000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE11x6x31), new DefaultHandler());
            success("testSAXPESL_2M: maxParameterEntitySizeLimit");
        } catch (Exception e) {
            unexpectedException("testSAXPESL_2M", e, "maxParameterEntitySizeLimit");
        }
    }    

    /**
     * within a limit of 100,000, 5x7x654 are ok with default memory on
     * client VM
     */
    public void testSAXPESL_100K() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "64000000");
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "100000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE5x7x654), new DefaultHandler());
            success("testSAXPESL_100K passed: maxParameterEntitySizeLimit");
        } catch (Exception e) {
            e.printStackTrace();
            unexpectedException("testSAXPESL_100K", e, "maxParameterEntitySizeLimit");
        }
    }    
    

    
}
