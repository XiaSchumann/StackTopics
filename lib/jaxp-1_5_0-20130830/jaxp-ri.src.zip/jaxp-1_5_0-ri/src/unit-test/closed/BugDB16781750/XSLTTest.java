package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test XSLT portion of external reference restriction
 * @run main/othervm XSLTTest
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.StringReader;
import java.util.EnumSet;
import javax.xml.XMLConstants;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.xml.sax.InputSource;

/**
 * Tests for XSL PI, Document() function, Import and Include
 *
 * author huizhe.wang@oracle.com
 */
public class XSLTTest extends TestBase {

    private URIResolver resolver = new URIResolver() {
        @Override
        public Source resolve(String href, String base)
                throws TransformerException {
            debugPrint("resolving: " + href);
            return new StreamSource(_filepath + "/" + href);
        }
    };

    static enum SourceType { STREAM, SAX, STAX, DOM };
    SourceType sourceType = null;

    String _xslFile, _xmlFile, _xslIncFile, _xslDocFile, _xmlDocFile;
    String _sourceDTD, _xslDTD;
    String _xslFileId, _xslIncFileId, _xslDocFileId;
    /**
     * Creates a new instance of StreamReader
     */
    public XSLTTest(String name) {
        super(name);
    }


    /**
     * Build a Source for _xmlFile depending on the value of sourceType.
     * @return
     * @throws FileNotFoundException
     * @throws XMLStreamException
     */
    private Source _xmlFileSource() throws FileNotFoundException, XMLStreamException {
        if (sourceType == null) {
            throw new Error("Test Bug: Please check that sourceType is set");
        }
        switch(sourceType) {
            case SAX: return new SAXSource(new InputSource(_xmlFile));
            case STAX: return new StAXSource(XMLInputFactory.newFactory()
                    .createXMLEventReader(_xmlFile, new FileInputStream(_xmlFile)));
            case DOM: return new DOMSource(null,_xmlFile);
            default: return new StreamSource(_xmlFile);
        }
    }
    /**
     * param args the command line arguments
     */
    public static void main1(String[] args) {
        XSLTTest test = new XSLTTest("XSLT");
        test.sourceType = null;
        if (test.isNewPropertySupported()) {
            test.setUp();
/**
 * add the following, the test would pass!
 System.setProperty("org.xml.sax.driver", "bogus");        

 */            
            test.testDocFunc_JAXPProperty();
            test.testDocFunc();  //test JDK-8021148 Regression in SAXParserImpl in 7u40 b34 (NPE)
            test.testDocFunc_SP(); // Failing!

            test.tearDown();
        }

    }
    public static void main(String[] args) {
        XSLTTest test = new XSLTTest("XSLT");
        test.sourceType = null;
        if (test.isNewPropertySupported()) {
            test.setUp();
            
            test.testDocFunc();
            test.testDocFunc_JAXPProperty();
            test.testDocFunc_Resolver();
            test.testDocFunc_Resolver1();
            test.testDocFunc_SP();
            test.testDocFunc_Secure();
            test.testInclude_Preference();
            test.testInclude_SP();
            test.testInclude_Secure_Resolver();
            test.testInclude_secure();

            test.testSourceWDTD_FileAllowedByDefault();
            test.testSourceWDTD_secure();
            test.testSourceWDTD_JAXPProperty();
            test.testXSLWDTD_FileAllowedByDefault();
            test.testXSLWDTD_secure();
            test.testXSLWDTD_JAXPProperty();

            test.testInclude_secure_SP();
            test.testDocFunc_Secure_SP();
            test.testSourceWDTD_secure_SP();
            test.testXSLWDTD_secure_SP();

            // Tests that use sourceType should be put into that loop,
            // otherwise they will fail in Error (which is good because
            // it helps detect that the test has not been moved inside
            // the loop)
            for (SourceType source : EnumSet.allOf(SourceType.class)) {
                test.sourceType = source;
                test.testInclude_FileAllowedByDefault();
                test.testStylesheetPI_FileAllowedByDefault();
                test.testInclude_FileAllowedByDefault();
                test.testStylesheetPI_JAXPProperty();
                test.testStylesheetPI_Override();
                test.testStylesheetPI_SP();
                test.testStylesheetPI_secure_SP();
                test.testStylesheetPI_secure();
            }
            test.sourceType = SourceType.STREAM;
            // this one is failing. move it in the loop above when the failure
            // is fixed. No need to make it fail 4 times...
            test.testStylesheetPI_JAXPPropertySFP(); // Failing!
            test.sourceType = null;
            test.testSourceWDTD_JAXPPropertySFP(); // Failing!
            test.testXSLWDTD_JAXPPropertySFP(); // Failing!
            test.testDocFunc_JAXPPropertySFP(); // Failing!

            test.tearDown();
        }

    }

    //junit @Override
    protected void setUp() {
        super.setUp();
        _xslFile = _filepath + "/XSLPI.xsl";
        _xmlFile = _filepath + "/XSLPI.xml";
        _xslIncFile = _filepath + "/XSLInclude_main.xsl";
        _xslDocFile = _filepath + "/DocumentFunc.xsl";
        _xmlDocFile = _filepath + "/DocumentFunc.xml";
        _sourceDTD = _filepath + "/XSLSourceDTD.xml";
        _xslDTD = _filepath + "/XSLDTD.xsl";
        //system id
        _xslFileId = "file:" + _xslFile;
        _xslIncFileId = "file:" + _xslIncFile;
        _xslDocFileId = "file:" + _xslDocFile;
    }

    @Override
    void success(String msg) {
        if (sourceType == null) {
            super.success(msg);
        } else {
            super.success(sourceType + ": "+ msg);
        }
    }

    @Override
    void fail(String errMsg) {
        if (sourceType == null) {
            super.fail(errMsg);
        } else {
            final String tag = "[" +sourceType + "] ";
            super.fail(tag+errMsg);
        }
    }


    void fail(Throwable t) {
        final String tag = sourceType == null ? "" : "[" +sourceType + "] ";
        System.err.print(tag);
        t.printStackTrace();
        super.fail(tag+t.getMessage());
    }



    /////////////////////////////////////////////////
    ///////////Stylesheet Processing Instruction
    /////////////////////////////////////////////////

    public void testStylesheetPI_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(new StringReader(_xsl_pi_xslfile)));
            xslSource.setSystemId(_xslFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(_xmlFileSource(), new StreamResult(System.out));
            success("testStylesheetPI_FileAllowedByDefault: passed");
        } catch (Exception e) {
            unexpectedException("testStylesheetPI_FileAllowedByDefault", e, "entity");
        }
    }

    public void testStylesheetPI_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(new StringReader(_xsl_pi_xslfile)));
            xslSource.setSystemId(_xslFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(_xmlFileSource(), new StreamResult(System.out));
            success("testStylesheetPI_secure: passed");
        } catch (Exception e) {
            unexpectedException("testStylesheetPI_secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testStylesheetPI_secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(new StringReader(_xsl_pi_xslfile)));
            xslSource.setSystemId(_xslFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(_xmlFileSource(), new StreamResult(System.out));
            fail("testStylesheetPI_secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testStylesheetPI_secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testStylesheetPI_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(new StringReader(_xsl_pi_xslfile)));
            xslSource.setSystemId(_xslFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(_xmlFileSource(), new StreamResult(System.out));
            fail("testStylesheetPI_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testStylesheetPI_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * jaxp property will take preference
     */
    public void testStylesheetPI_Override() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setAttribute(ACCESS_EXTERNAL_STYLESHEET, "");
            SAXSource xslSource = new SAXSource(new InputSource(new StringReader(_xsl_pi_xslfile)));
            xslSource.setSystemId(_xslFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(_xmlFileSource(), new StreamResult(System.out));
            fail("testStylesheetPI_Override failed, over the limit");
        } catch (Exception e) {
            expectedException("testStylesheetPI_Override", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testStylesheetPI_JAXPProperty() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            SAXSource xslSource = new SAXSource(new InputSource(new StringReader(_xsl_pi_xslfile)));
            xslSource.setSystemId(_xslFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(_xmlFileSource(), new StreamResult(System.out));
            fail("testStylesheetPI_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testStylesheetPI_JAXPProperty", e, "PE");
        }
    }

    public void testStylesheetPI_JAXPPropertySFP() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(new StringReader(_xsl_pi_xslfile)));
            xslSource.setSystemId(_xslFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(_xmlFileSource(), new StreamResult(System.out));
            fail("testStylesheetPI_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testStylesheetPI_JAXPPropertySFP", e, "PE");
        }
    }

    public void testInclude_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(_xslIncFile));
            xslSource.setSystemId(_xslIncFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(_xmlFileSource(), new StreamResult(System.out));
            success("testInclude_FileAllowedByDefault: passed");
        } catch (Exception e) {
            unexpectedException("testInclude_FileAllowedByDefault", e, "entity");
        }
    }


    public void testInclude_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslIncFile));
            xslSource.setSystemId(_xslIncFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(_xmlFile), new StreamResult(System.out));
            success("testInclude_secure: passed");
        } catch (Exception e) {
            unexpectedException("testInclude_secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testInclude_secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslIncFile));
            xslSource.setSystemId(_xslIncFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(_xmlFile), new StreamResult(System.out));
            fail("testInclude_secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testInclude_secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testInclude_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(_xslIncFile));
            xslSource.setSystemId(_xslIncFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(_xmlFile), new StreamResult(System.out));
            fail("testInclude_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testInclude_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testInclude_Preference() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslIncFile));
            xslSource.setSystemId(_xslIncFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(_xmlFile), new StreamResult(System.out));
            fail("testInclude_Preference failed, over the limit");
        } catch (Exception e) {
            expectedException("testInclude_Preference", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }


    public void testInclude_Secure_Resolver() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setURIResolver(resolver);
            SAXSource xslSource = new SAXSource(new InputSource(_xslIncFile));
            xslSource.setSystemId(_xslIncFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(_xmlFile), new StreamResult(System.out));
            success("testInclude_Secure_Resolver: passed");
        } catch (Exception e) {
            unexpectedException("testInclude_Secure_Resolver", e, "entity");
        }
    }

    /////////////////////////////////////////////////
    ///////////Document() Function
    /////////////////////////////////////////////////
    public void testDocFunc() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(_xslDocFile));
            xslSource.setSystemId(_xslDocFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(new File(_xmlDocFile)), new StreamResult(System.out));
            success("testDocFunc: passed");
        } catch (Exception e) {
            unexpectedException("testDocFunc", e, "entity");
        }
    }

    public void testDocFunc_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(_xslDocFile));
            xslSource.setSystemId(_xslDocFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(new File(_xmlDocFile)), new StreamResult(System.out));
            fail("testDocFunc_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testDocFunc_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    public void testDocFunc_Secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslDocFile));
            xslSource.setSystemId(_xslDocFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(new File(_xmlDocFile)), new StreamResult(System.out));
            success("testDocFunc_Secure: passed");
        } catch (Exception e) {
            unexpectedException("testDocFunc_Secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testDocFunc_Secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslDocFile));
            xslSource.setSystemId(_xslDocFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(new File(_xmlDocFile)), new StreamResult(System.out));
            fail("testDocFunc_Secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testDocFunc_Secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * JAXP Property takes preference
     */
    public void testDocFunc_JAXPProperty() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            SAXSource xslSource = new SAXSource(new InputSource(_xslDocFile));
            xslSource.setSystemId(_xslDocFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(new File(_xmlDocFile)), new StreamResult(System.out));
            fail("testDocFunc_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testDocFunc_JAXPProperty", e, "PE");
        }
    }

    public void testDocFunc_JAXPPropertySFP() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslDocFile));
            xslSource.setSystemId(_xslDocFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(new File(_xmlDocFile)), new StreamResult(System.out));
            fail("testDocFunc_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testDocFunc_JAXPPropertySFP", e, "PE");
        }
    }

    /**
     * secure processing, access is restricted However, paths handled by a
     * resolver are not restricted
     */
    public void testDocFunc_Resolver() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setURIResolver(resolver);
            SAXSource xslSource = new SAXSource(new InputSource(_xslDocFile));
            xslSource.setSystemId(_xslDocFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.transform(new StreamSource(new File(_xmlDocFile)), new StreamResult(System.out));
            success("testDocFunc_Resolver: passed");
        } catch (Exception e) {
            unexpectedException("testDocFunc_Resolver", e, "entity");
        }
    }

    /**
     * secure processing, access is restricted However, paths handled by a
     * resolver are not restricted
     */
    public void testDocFunc_Resolver1() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslDocFile));
            xslSource.setSystemId(_xslDocFileId);
            Transformer transformer = factory.newTransformer(xslSource);
            transformer.setURIResolver(resolver);
            transformer.transform(new StreamSource(new File(_xmlDocFile)), new StreamResult(System.out));
            success("testDocFunc_Resolver1: passed");
        } catch (Exception e) {
            unexpectedException("testDocFunc_Resolver1", e, "entity");
        }
    }

    /////////////////////////////////////////////////
    ///////////external DTD in xml source file
    /////////////////////////////////////////////////
    public void testSourceWDTD_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(_sourceDTD));
            xslSource.setSystemId(_sourceDTD);
            transformer.transform(xslSource, new StreamResult(System.out));
            success("testSourceWDTD_FileAllowedByDefault: passed");
        } catch (Exception e) {
            unexpectedException("testSourceWDTD_FileAllowedByDefault", e, "entity");
        }
    }

    public void testSourceWDTD_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(_sourceDTD));
            xslSource.setSystemId(_sourceDTD);
            transformer.transform(xslSource, new StreamResult(System.out));
            success("testSourceWDTD_secure: passed");
        } catch (Exception e) {
            unexpectedException("testSourceWDTD_secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testSourceWDTD_secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(_sourceDTD));
            xslSource.setSystemId(_sourceDTD);
            transformer.transform(xslSource, new StreamResult(System.out));
            fail("testSourceWDTD_secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSourceWDTD_secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }

    /**
     * The JAXP properties override any that set by System property or FSP
     */
    public void testSourceWDTD_JAXPProperty() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(_sourceDTD));
            xslSource.setSystemId(_sourceDTD);
            transformer.transform(xslSource, new StreamResult(System.out));
            fail("testSourceWDTD_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testSourceWDTD_JAXPProperty", e, "PE");
        }
    }

    public void testSourceWDTD_JAXPPropertySFP() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            Transformer transformer = factory.newTransformer();
            SAXSource xslSource = new SAXSource(new InputSource(_sourceDTD));
            xslSource.setSystemId(_sourceDTD);
            transformer.transform(xslSource, new StreamResult(System.out));
            fail("testSourceWDTD_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testSourceWDTD_JAXPPropertySFP", e, "PE");
        }
    }

    /////////////////////////////////////////////////
    ///////////external DTD in XSL file
    /////////////////////////////////////////////////

    public void testXSLWDTD_FileAllowedByDefault() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            SAXSource xslSource = new SAXSource(new InputSource(_xslDTD));
            xslSource.setSystemId(_xslDTD);
            Transformer transformer = factory.newTransformer(xslSource);
            success("testXSLWDTD_FileAllowedByDefault: passed");
        } catch (Exception e) {
            unexpectedException("testXSLWDTD_FileAllowedByDefault", e, "entity");
        }
    }

    public void testXSLWDTD_secure() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslDTD));
            xslSource.setSystemId(_xslDTD);
            Transformer transformer = factory.newTransformer(xslSource);
            success("testXSLWDTD_secure: passed");
        } catch (Exception e) {
            unexpectedException("testXSLWDTD_secure", e, "entity");
        }
    }

    /**
     * System property will override that set by FSP
     */
    public void testXSLWDTD_secure_SP() {
        System.setProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslDTD));
            xslSource.setSystemId(_xslDTD);
            Transformer transformer = factory.newTransformer(xslSource);
            fail("testXSLWDTD_secure_SP failed, over the limit");
        } catch (Exception e) {
            expectedException("testXSLWDTD_secure_SP", e, "PE");
        } finally {
            System.clearProperty(SP_PARAMETER_ENTITY_SIZE_LIMIT);
        }
    }
    public void testXSLWDTD_JAXPProperty() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            SAXSource xslSource = new SAXSource(new InputSource(_xslDTD));
            xslSource.setSystemId(_xslDTD);
            Transformer transformer = factory.newTransformer(xslSource);
            fail("testXSLWDTD_JAXPProperty failed, over the limit");
        } catch (Exception e) {
            expectedException("testXSLWDTD_JAXPProperty", e, "PE");
        }
    }

    public void testXSLWDTD_JAXPPropertySFP() {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            factory.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "3000");
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            SAXSource xslSource = new SAXSource(new InputSource(_xslDTD));
            xslSource.setSystemId(_xslDTD);
            Transformer transformer = factory.newTransformer(xslSource);
            fail("testXSLWDTD_JAXPPropertySFP failed, over the limit");
        } catch (Exception e) {
            expectedException("testXSLWDTD_JAXPPropertySFP", e, "PE");
        }
    }

}
