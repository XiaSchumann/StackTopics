package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test entity expansion limit
 * @run main/othervm OneTest
 */
import com.sun.org.apache.xerces.internal.impl.Constants;
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.SAXParser;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import org.w3c.dom.Document;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * EntityExpansionLimit tests
 *
 * @author huizhe.wang@oracle.com
 */
public class EntityExpansionTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public EntityExpansionTest(String name) {
        super(name);
    }
    String _xmlGENotDeclared;
    String _xmlGE9; 
    String _xmlGE64005, _xmlGE64005Id;
    String _xmlGE64006, _xmlGE64005_10000;
    
    protected void setUp() {
        super.setUp();
        _xmlGENotDeclared = _filepath + "/testGENotDeclared.xml";
        _xmlGE9 = _filepath + "/testGE9.xml";
        _xmlGE64005 = _filepath + "/testGE64005.xml";
        _xmlGE64006 = _filepath + "/testGE64006.xml";
        _xmlGE64005_10000 = _filepath + "/testGE64005_10000.xml";
        
        if (isWindows) {
            _xmlGENotDeclared = "/" + _xmlGENotDeclared;
            _xmlGE9 = "/" + _xmlGE9;
            _xmlGE64005 = "/" + _xmlGE64005;
            _xmlGE64006 = "/" + _xmlGE64006;
            _xmlGE64005_10000 = "/" + _xmlGE64005_10000;
        }        
        
        _xmlGE64005Id = "file:" + _xmlGE64005;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        EntityExpansionTest test = new EntityExpansionTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();
            test.testSAXGE_Undeclared();
            test.testSAXGE_Default();
            test.testSAXGE_FSPOn();
            test.testSAXGE_Default_OverLimit();
            test.testSAXGE_FSPOff();
            test.testSAXGE_SP_OverLimit();
            test.testSAXGE_API_OverLimit();
            test.testSAXGE_DisallowDTD();
            test.testSAXGE_NotLoadDTD();
            
            test.testDOMGE_Default();
            test.testDOMGE_Default_OverLimit();
            test.testDOMGE_FSPOn();
            test.testDOMGE_FSPOff();
            test.testDOMGE_SP_OverLimit();
            test.testDOMGE_API_OverLimit();
            test.testDOMGE_DisallowDTD();
            test.testDOMGE_NotLoadDTD();
            
            test.testStAXGE_Default();
            test.testStAXGE_SP_OverLimit();
            test.testStAXGE_API_OverLimit();
            test.testStAXGE_NotSupportDTD();
            test.testStAXGE_isReplacingEntityReferences();
            test.tearDown();
        }

    }
    

    /////////////////////////////////////////////////
    ///////////General Entity Reference
    /////////////////////////////////////////////////
    /**
     * SAX
     */
    /**
     * Undeclared entity
     */
    public void testSAXGE_Undeclared() {

        try {
            SAXParser parser = getSAXParser();
            parser.parse(new File(_xmlGENotDeclared), new DefaultHandler());
            fail("testSAXGE_Undeclared: undeclared entity");
        } catch (Exception e) {
            expectedException("testSAXGE_Undeclared", e, "entityExpansion");
        }
    }

    /**
     * By default, FEATURE_SECURE_PROCESSING is true, entityExpansionLimit = 64,000;
     * Parsing a file that's within the limit (actually allows 64005)
     */
    public void testSAXGE_Default() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlGE64005), new DefaultHandler());
            success("testSAXDefault_OverLimit: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testSAXDefault_OverLimit", e, "entityExpansion");
        }
    }

    /**
     * By default, FEATURE_SECURE_PROCESSING is true, setting FSP therefore 
     * does not make any difference
     */
    public void testSAXGE_FSPOn() {

        try {
            SAXParser parser = getSAXParser(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_TRUE);
            parser.parse(new File(_xmlGE64005), new DefaultHandler());
            success("testSAXGE_FSPOn: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testSAXGE_FSPOn", e, "entityExpansion");
        }
    }

    /**
     * By default, FEATURE_SECURE_PROCESSING is true, entityExpansionLimit = 64,000; 
     * Parsing a file that's over the limit with 64006 expansions
     */
    public void testSAXGE_Default_OverLimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.parse(new File(_xmlGE64006), new DefaultHandler());
            fail("testSAXDefault_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXDefault_OverLimit", e, "entityExpansion");
        }
    }

    /**
     * Set FEATURE_SECURE_PROCESSING to false, no restriction even though
     * the expansions are over 64000
     */
    public void testSAXGE_FSPOff() {

        try {
            SAXParser parser = getSAXParser(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_FALSE);
            parser.parse(new File(_xmlGE64006), new DefaultHandler());
            success("testSAXGE_FSPOff: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testSAXGE_FSPOff", e, "entityExpansion");
        }
    }
    
    /**
     * Parsing a file that contains 9 expansions with a limit set to 8 through the
     * the system property
     */
    public void testSAXGE_SP_OverLimit() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "8");

        try {
            SAXParser parser = getSAXParser();
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            fail("testSAXGE_API_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGE_API_OverLimit", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    

    /**
     * Parsing a file that contains 9 expansions with a limit set to 8 through the
     * API property; API property always take preference
     */
    public void testSAXGE_API_OverLimit() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "10");

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_ENTITY_EXPANSION_LIMIT, "8");            
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            fail("testSAXGE_API_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGE_API_OverLimit", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    
    
    /**
     * DTD is disallowed, expected exception
     */
    public void testSAXGE_DisallowDTD() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "10");

        try {
            SAXParser parser = getSAXParser(false, false, false, DISALLOWDTD_TRUE,false);
            parser.setProperty(JDK_ENTITY_EXPANSION_LIMIT, "8");            
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            fail("testSAXGE_DisallowDTD: not load ");
        } catch (Exception e) {
            expectedException("testSAXGE_DisallowDTD", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    
    
    /**
     * Feature not loadExternalDTD has no effect since the DTD is internal
     */
    public void testSAXGE_NotLoadDTD() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "10");

        try {
            SAXParser parser = getSAXParser(false, false, false, false,NOTLOADEXTERNALDTD_TRUE);
            parser.setProperty(JDK_ENTITY_EXPANSION_LIMIT, "8");            
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            fail("testSAXGE_NotLoadDTD: not load ");
        } catch (Exception e) {
            expectedException("testSAXGE_NotLoadDTD", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    


    /**
     * DOM -- similar tests as SAX
     */
    /**
     * By default, FEATURE_SECURE_PROCESSING is true, entityExpansionLimit = 64,000;
     * Parsing a file that's within the limit (actually allows 64005)
     */
    public void testDOMGE_Default() {

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlGE64005));
            success("testDOMGE_Default: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGE_Default", e, "entityExpansion");
        }
    }
    /**
     * By default, FEATURE_SECURE_PROCESSING is already true, but let's still
     * test setting FSP explicitly 
     */
    public void testDOMGE_FSPOn() {

        DocumentBuilder docBuilder = getDOMBuilder(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_TRUE);
        try {
            Document document = docBuilder.parse(new File(_xmlGE64005));
            success("testDOMGE_Default: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGE_Default", e, "entityExpansion");
        }
    }

    /**
     * By default, FEATURE_SECURE_PROCESSING is true, entityExpansionLimit = 64,000; 
     * Parsing a file that's over the limit with 64006 expansions
     */
    public void testDOMGE_Default_OverLimit() {

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlGE64006));
            fail("testDOMGE_Default_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMGE_Default_OverLimit", e, "entityExpansion");
        }
    }
    /**
     * Set FEATURE_SECURE_PROCESSING to false, no restriction even though
     * the expansions are over 64000
     */
    public void testDOMGE_FSPOff() {

        DocumentBuilder docBuilder = getDOMBuilder(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_FALSE);
        try {
            Document document = docBuilder.parse(new File(_xmlGE64006));
            success("testDOMGE_Default: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGE_Default", e, "entityExpansion");
        }
    }    
    /**
     * Parsing a file that contains 9 expansions with a limit set to 8 through the
     * the system property
     */
    public void testDOMGE_SP_OverLimit() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "8");

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));
            fail("testDOMGE_SP_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMGE_SP_OverLimit", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    

    /**
     * Parsing a file that contains 9 expansions with a limit set to 8 through the
     * API property; API property always take preference
     */
    public void testDOMGE_API_OverLimit() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "10");

        DocumentBuilder docBuilder = getDOMBuilder(JDK_ENTITY_EXPANSION_LIMIT, "8");
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));            
            fail("testSAXGE_API_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGE_API_OverLimit", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    
    
    /**
     * DTD is disallowed, expected exception
     */
    public void testDOMGE_DisallowDTD() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "10");
        DocumentBuilder docBuilder = getDOMBuilder(false, false, false, 
                JDK_ENTITY_EXPANSION_LIMIT, "8", DISALLOWDTD_TRUE, false);
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));            

            fail("testDOMGE_DisallowDTD: not load ");
        } catch (Exception e) {
            expectedException("testDOMGE_DisallowDTD", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    
    
    /**
     * Feature not loadExternalDTD has no effect since the DTD is internal
     */
    public void testDOMGE_NotLoadDTD() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "10");
        DocumentBuilder docBuilder = getDOMBuilder(false, false, false, 
                JDK_ENTITY_EXPANSION_LIMIT, "8", false, NOTLOADEXTERNALDTD_TRUE);
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));            
            fail("testDOMGE_NotLoadDTD: not load ");
        } catch (Exception e) {
            expectedException("testDOMGE_NotLoadDTD", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }
    
    

    /**
     * StAX
     */
    public void testStAXGE_Default() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE64005, new FileInputStream(new File(_xmlGE64005)));
            readDTD(xsr);
            success("testStAXGE_Default: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testStAXGE_Default", e, "entityExpansion");
            e.printStackTrace();
        }
    }
    /**
     * Parsing a file that contains 9 expansions with a limit set to 8 through the
     * the system property
     */
    public void testStAXGE_SP_OverLimit() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "8");
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testStAXGE_SP_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testStAXGE_SP_OverLimit", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    

    /**
     * Parsing a file that contains 9 expansions with a limit set to 8 through the
     * API property; API property always take preference
     */
    public void testStAXGE_API_OverLimit() {
        System.setProperty(SP_ENTITY_EXPANSION_LIMIT, "10");

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(JDK_ENTITY_EXPANSION_LIMIT, "8");
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testSAXGE_API_OverLimit: over the entityExpansionLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGE_API_OverLimit", e, "entityExpansion");
        } finally {
            System.clearProperty(SP_ENTITY_EXPANSION_LIMIT);
        }
    }    
    
    /**
     * When SupportDTD=false, entity reference will result in an error
     */
    public void testStAXGE_NotSupportDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testStAXGE_NotSupportDTD: SupportDTD=false, shall throw exception");
        } catch (Exception e) {
            expectedException("testStAXGE_NotSupportDTD", e, "entityExpansion");
        }
    }

    /**
     * When IS_REPLACING_ENTITY_REFERENCES=false, entity will not be started. The parser
     * returns entity reference without resolving it
     */
    public void testStAXGE_isReplacingEntityReferences() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            success("testStAXGE_isReplacingEntityReferences: IS_REPLACING_ENTITY_REFERENCES=false, passed");
        } catch (Exception e) {
            unexpectedException("testStAXGE_isReplacingEntityReferences", e, "entityExpansion");
        }
    }
        
}
