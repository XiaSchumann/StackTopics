/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package closed.BugDB16781750;

import com.sun.org.apache.xalan.internal.XalanConstants;
import com.sun.org.apache.xerces.internal.impl.Constants;
import java.io.*;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Properties;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLResolver;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.DefaultHandler2;

/**
 *
 *
 * @author huizhe.wang@oracle.com
 */
public class TestBase {
    static final boolean DEBUG = true;
    public static boolean isWindows = false;
    static {
        if (System.getProperty("os.name").indexOf("Windows")>-1) {
            isWindows = true;
        }
    };
    public static final String ACCESS_EXTERNAL_DTD = XMLConstants.ACCESS_EXTERNAL_DTD;
    public static final String ACCESS_EXTERNAL_SCHEMA = XMLConstants.ACCESS_EXTERNAL_SCHEMA;
    public static final String ACCESS_EXTERNAL_STYLESHEET = XMLConstants.ACCESS_EXTERNAL_STYLESHEET;

        public static final String ORACLE_JAXP_PROPERTY_PREFIX =
        "http://www.oracle.com/xml/jaxp/properties/";

    public static final String JDK_ENTITY_EXPANSION_LIMIT = 
            ORACLE_JAXP_PROPERTY_PREFIX + "entityExpansionLimit"; 
    public static final String JDK_ELEMENT_ATTRIBUTE_LIMIT = 
            ORACLE_JAXP_PROPERTY_PREFIX + "elementAttributeLimit"; 
    public static final String JDK_MAX_OCCUR_LIMIT = 
            ORACLE_JAXP_PROPERTY_PREFIX + "maxOccurLimit"; 
    public static final String JDK_TOTAL_ENTITY_SIZE_LIMIT = 
            ORACLE_JAXP_PROPERTY_PREFIX + "totalEntitySizeLimit"; 
    public static final String JDK_GENEAL_ENTITY_SIZE_LIMIT = 
            ORACLE_JAXP_PROPERTY_PREFIX + "maxGeneralEntitySizeLimit"; 
    public static final String JDK_PARAMETER_ENTITY_SIZE_LIMIT = 
            ORACLE_JAXP_PROPERTY_PREFIX + "maxParameterEntitySizeLimit"; 
    public static final String JDK_XML_NAME_LIMIT = 
            ORACLE_JAXP_PROPERTY_PREFIX + "maxXMLNameLimit"; 
    public static final String JDK_ENTITY_COUNT_INFO = 
            ORACLE_JAXP_PROPERTY_PREFIX + "getEntityCountInfo"; 

    //System properties
    public static final String SP_ENTITY_EXPANSION_LIMIT = "jdk.xml.entityExpansionLimit"; 
    public static final String SP_ELEMENT_ATTRIBUTE_LIMIT =  "jdk.xml.elementAttributeLimit"; 
    public static final String SP_MAX_OCCUR_LIMIT = "jdk.xml.maxOccurLimit"; 
    public static final String SP_TOTAL_ENTITY_SIZE_LIMIT = "jdk.xml.totalEntitySizeLimit";     
    public static final String SP_GENEAL_ENTITY_SIZE_LIMIT = "jdk.xml.maxGeneralEntitySizeLimit"; 
    public static final String SP_PARAMETER_ENTITY_SIZE_LIMIT = "jdk.xml.maxParameterEntitySizeLimit"; 
    public static final String SP_XML_NAME_LIMIT = "jdk.xml.maxXMLNameLimit"; 
    
    //legacy System Properties
    public final static String ENTITY_EXPANSION_LIMIT = "entityExpansionLimit";
    public static final String ELEMENT_ATTRIBUTE_LIMIT = "elementAttributeLimit" ;
    public final static String MAX_OCCUR_LIMIT = "maxOccurLimit";
    
    public static final String DISALLOW_DOCTYPE_DECL_FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
    public static final String LOAD_EXTERNAL_DTD_FEATURE = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
    public static final String EXTERNAL_GENERAL_ENTITIES_FEATURE = "http://xml.org/sax/features/external-general-entities";
    public static final String EXTERNAL_PARAMETER_ENTITIES_FEATURE = "http://xml.org/sax/features/external-parameter-entities";
    static final String SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    static final String SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";

    public static final boolean SET_FSP_EXPLICITLY = true;
    public static final boolean SET_FSP_BEFORE = true;
    public static final boolean FSP_NOTSET = true;
    public static final boolean SECURE_PROCESSING_TRUE = true;
    public static final boolean SECURE_PROCESSING_FALSE = false;
    public static final boolean DISALLOWDTD_TRUE = true;
    public static final boolean DISALLOWDTD_FALSE = false;
    public static final boolean NOTLOADEXTERNALDTD_TRUE = true;
    public static final boolean NOTLOADEXTERNALDTD_FALSE = false;
    public static final boolean NOTINCGENENTITY_TRUE = true;
    public static final boolean NOTINCPARAMETERENTITY_TRUE = true;
    public static final boolean IGNORE_ERROR_TRUE = true;
    public static final boolean IGNORE_ERROR_FALSE = false;
    public static final String ACCESS_EXTERNAL_ALL = "all";
    static final String PROTOCOL_FILE = "file";
    static final String PROTOCOL_HTTP = "http";
    static String JAXPProperty_accessExternalDTD;
    static String JAXPProperty_accessExternalSchema;
    static String JAXPProperty_accessExternalStylesheet;
    static final int TEST_EXTERNALDTD = 1;
    static final int TEST_EXTERNALSCHEMA = 2;
    static final int TEST_EXTERNALSTYLESHEET = 3;


    String _filepath;
    String _external_dtd_file;
    //_httpserver/tests/bugdb14495809/
    /**
     * final String _external_dtd_http = "<?xml version='1.0' encoding
     * ='utf-8'?>" + "<!DOCTYPE properties SYSTEM
     * \"http://java.sun.com/dtd/properties.dtd\">" + "<properties>" +
     * "<comment>java.util.Properties</comment>" + "<entry
     * key=\"key1\">value1</entry>" + "</properties>";
     */
    String _external_dtd_http;
    /**
     * static final String _public_external_dtd = "<?xml version=\"1.0\"
     * encoding=\"utf-8\"?>" + "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0
     * Transitional//EN\"" + "
     * \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\" [" + "<!-- an
     * internal subset can be embedded here -->" + "]>" + "<!-- the XHTML
     * document body starts here-->" + "<html>" + "..." + "</html>";
     */
    String _public_external_dtd;
    String _external_entity;
    String _external_entity_file;
    String _external_entity_resolver;
    //only InputStream is supported for StAX's XMLResolver
    String _external_entity_resolver_stax;
    String _external_parameter_entity_file;
    String _xsl_pi_xslfile;
    //test with jaxp.properties
    static final boolean hasJaxpProperties = false;

    static String originalJavaHome;

    String _xmlGENotDeclared;
    String _xmlGE9; 
    String _xmlGE64005, _xmlGE64005Id;
    String _xmlGE64006, _xmlGE64005_10000, _xmlGE64005_2800, _xmlGE64005_1350;

    String _xmlPE5x5, _xmlPE10by10;
    String _xmlPE5x5id, _xmlPE10by10id;
    String _xmlPE5x7x654, _xmlPE5x7x655;
    String _xmlPE7x7x65, _xmlPE7x7x66;
    String _xmlPE9x7x9, _xmlPE9x7x10, _xmlPE9x7x11;
    String _xmlPE11x6x31, _xmlPE11x6x32;
    String _xmlPE10x10;
    
    
    String _xmlSchemaXSD;

    String _testName;

    static String _errMsg;

    int passed = 0, failed = 0;

    /**
     * Creates a new instance of StreamReader
     */
    public TestBase(String name) {
        _testName = name;
    }

    //junit @Override
    protected void setUp() {
        /**
        if (!isNewPropertySupported()) {
            System.exit(0);
        }
        */

        if (hasJaxpProperties) {
            //save original java.home, set it to user.dir
            setJavaHome();
        }

        /** JTREG
        _filepath = System.getProperty("test.src");
        if (_filepath == null) {
            //current directory
            _filepath = System.getProperty("user.dir");
        }
        */
        //_filepath = TestBase.class.getResource("testGE64005.xml").getPath();
        //int pos = _filepath.lastIndexOf('/');
        //_filepath = _filepath.substring(0, pos);
       
        _filepath = "C:\\Projects\\Jaxp\\ws\\jaxp-sources\\jaxp-ri\\src\\unit-test\\closed\\BugDB16781750";
         
        if (isWindows) {
            _filepath = _filepath.replace('\\', '/');
        }
        System.setProperty(Constants.SP_ACCESS_EXTERNAL_DTD, "all");
        System.setProperty(Constants.SP_ACCESS_EXTERNAL_SCHEMA, "all");
        System.setProperty(XalanConstants.SP_ACCESS_EXTERNAL_DTD, "all");
        System.setProperty(XalanConstants.SP_ACCESS_EXTERNAL_STYLESHEET, "all");
        
        initFiles();
    }

    //junit @Override
    protected void tearDown() {
        resetJavaHome();

        System.clearProperty(Constants.SP_ACCESS_EXTERNAL_DTD);
        System.clearProperty(Constants.SP_ACCESS_EXTERNAL_SCHEMA);
        System.clearProperty(XalanConstants.SP_ACCESS_EXTERNAL_DTD);
        System.clearProperty(XalanConstants.SP_ACCESS_EXTERNAL_STYLESHEET);

        System.out.println("\nNumber of tests passed: " + passed);
        System.out.println("Number of tests failed: " + failed + "\n");

        if (_errMsg != null ) {
            throw new RuntimeException(_errMsg);
        }
    }


    void initFiles() {
        _xmlGENotDeclared = _filepath + "/testGENotDeclared.xml";
        _xmlGE9 = _filepath + "/testGE9.xml";
        _xmlGE64005 = _filepath + "/testGE64005.xml";
        _xmlGE64006 = _filepath + "/testGE64006.xml";
        _xmlGE64005_10000 = _filepath + "/testGE64005_10000.xml";
        _xmlGE64005_2800 = _filepath + "/testGE64005_2800.xml";
        _xmlGE64005_1350 = _filepath + "/testGE64005_1350.xml";
        
        _xmlPE5x5 = _filepath + "/testPE5x5.xml";
        _xmlPE10by10 = _filepath + "/testPE10by10.xml";
        _xmlSchemaXSD = _filepath + "/XMLSchema.xsd";
        _xmlPE5x7x654 = _filepath + "/testPE5x7x654.xml";
        _xmlPE5x7x655 = _filepath + "/testPE5x7x655.xml";
        _xmlPE7x7x65 = _filepath + "/testPE7x7x65.xml";
        _xmlPE7x7x66 = _filepath + "/testPE7x7x66.xml";
        _xmlPE9x7x11 = _filepath + "/testPE9x7x11.xml";
        _xmlPE9x7x10 = _filepath + "/testPE9x7x10.xml";
        _xmlPE9x7x9 = _filepath + "/testPE9x7x9.xml";
        _xmlPE11x6x31 = _filepath + "/testPE11x6x31.xml";
        _xmlPE11x6x32 = _filepath + "/testPE11x6x32.xml";    
        _xmlPE10x10 = _filepath + "/testPE10x10.xml";    
        
        if (isWindows) {
            _xmlGENotDeclared = "/" + _xmlGENotDeclared;
            _xmlGE9 = "/" + _xmlGE9;
            _xmlGE64005 = "/" + _xmlGE64005;
            _xmlGE64006 = "/" + _xmlGE64006;
            _xmlGE64005_10000 = "/" + _xmlGE64005_10000;
            _xmlGE64005_1350 = "/" + _xmlGE64005_1350;
            _xmlPE10by10 = "/" + _xmlPE10by10;
            _xmlPE5x5 = "/" + _xmlPE5x5;
            _xmlSchemaXSD = "/" + _xmlSchemaXSD;
            _xmlPE5x7x654 = "/" + _xmlPE5x7x654;
            _xmlPE5x7x655 = "/" + _xmlPE5x7x655;
            _xmlPE7x7x65 = "/" + _xmlPE7x7x65;
            _xmlPE7x7x66 = "/" + _xmlPE7x7x66;
            _xmlPE9x7x11 = "/" + _xmlPE9x7x11;
            _xmlPE9x7x10 = "/" + _xmlPE9x7x10;
            _xmlPE9x7x9 = "/" + _xmlPE9x7x9;
            _xmlPE11x6x31 = "/" + _xmlPE11x6x31;
            _xmlPE11x6x32 = "/" + _xmlPE11x6x32;
            _xmlPE10x10 = "/" + _xmlPE10x10;
        }        
        
        _xmlGE64005Id = "file://" + _xmlGE64005;
        _xmlPE5x5id =  "file://" + _xmlPE5x5id;
        _xmlPE10by10id =  "file://" + _xmlPE10by10id;        
        
        _external_dtd_file = _filepath + "/toys2.xml";
        
        _external_entity_file = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder "
                + "[ <!ENTITY item SYSTEM \""
                + _filepath + "/externalEntity.xml"
                + "\"> ]"
                + ">"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "&item;"
                + "</SupplierOrder>";


        _external_entity = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE document "
                + "[ <!ENTITY foo SYSTEM \"C:\\Test\\test.txt\"> ]"
                + ">"
                + "<document>"
                + "<name>&foo;</name>"
                + "</document>";



        _external_parameter_entity_file = "<?xml version='1.0' encoding ='utf-8'?>"
                + "<!DOCTYPE SupplierOrder ["
                + "<!ENTITY % paraEntity SYSTEM \""
                + _filepath + "/paramEntity.dtd"
                + "\">"
                + "%paraEntity;"
                + "]>"
                + "<SupplierOrder>"
                + "<OrderId>10016</OrderId>"
                + "<LineItems>"
                + "<LineItem categoryId=\"BIRDS\" itemId=\"EST-18\" lineNo=\"0\" productId=\"AV-CB-01\" quantity=\"&quantity;\" unitPrice=\"&unitPrice;\"/>"
                + "</LineItems>"
                + "</SupplierOrder>";


        _xsl_pi_xslfile = ""
                + "<?xml version='1.0'?>"
                + "<!DOCTYPE top SYSTEM 'testPE5x5.dtd'"
                + "["
                + "<!ENTITY % pe0 \"x\">"
                + " <!ENTITY   x4 \"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA100AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA200\">"
                + "<!ENTITY   x3 \"&x4;&x4;\">"
                + "<!ENTITY   x2 \"&x3;&x3;\">"
                + "<!ENTITY   x1 \"&x2;&x2;\">"
                +"]>"
                + "<?xml-stylesheet href=\""
                + _filepath
                + "/XSLPI_target.xsl\" type=\"text/xml\"?>"
                + "<xsl:stylesheet "
                + "    xmlns:xsl='http://www.w3.org/1999/XSL/Transform' "
                + "    version='1.0'>"
                + "</xsl:stylesheet> ";

    }

    StAXSource staxSourceFor(String _xmlFileId, String _xmlFile)
            throws XMLStreamException, FileNotFoundException {
        return new StAXSource(
                    XMLInputFactory.newFactory().createXMLEventReader(
                        _xmlFileId, new FileInputStream(_xmlFile)));
    }
    /**
     * helper method for creating validating SAX parser
     *
     * @param secure
     * @return
     * @throws Exception
     */
    protected SAXParser createValidatingParser(boolean secure) throws Exception {
        if (secure) {
            return getSAXParser(true, true, secure, false, false, true);
        } else {
            return getSAXParser(false, false, false, false, false, true);
        }
    }
    
    SAXParser getSAXParser()
            throws ParserConfigurationException, SAXException {
        return getSAXParser(false, false, false, false, false);
    }
    SAXParser getSAXParser(boolean setFSP, boolean setFSPBefore, boolean secure)
            throws ParserConfigurationException, SAXException {
        return getSAXParser(setFSP, setFSPBefore, secure, false, false);
    }
    
    SAXParser getSAXParser(boolean setFSP, boolean setFSPBefore, boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD)
            throws ParserConfigurationException, SAXException {
        return getSAXParser(setFSP, setFSPBefore, secure, disallowDTD,
            notLoadExternalDTD, false);
    }
    /**
     * Return a SAXParser
     * @param setFSP indicate if FSP is to be set explicitly
     * @param setFSPBefore indicate FSP is set before the properties
     * @param secure secure processing
     * @param disallowDTD set disallowDTD feature
     * @param notLoadExternalDTD set loadExternalDTD feature
     * @return
     * @throws ParserConfigurationException
     * @throws SAXException 
     */
    SAXParser getSAXParser(boolean setFSP, boolean setFSPBefore, boolean secure, boolean disallowDTD,
            boolean notLoadExternalDTD, boolean isValidating)
            throws ParserConfigurationException, SAXException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        if (setFSP && setFSPBefore) {
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
        }
        if (disallowDTD) {
            spf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, disallowDTD);
        }
        if (notLoadExternalDTD) {
            spf.setValidating(false);
            spf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
        }
        
        if (isValidating) {
            spf.setNamespaceAware(true);
            spf.setValidating(true);            
        }
        SAXParser parser = spf.newSAXParser();
        if (isValidating) {
            parser.setProperty(
                    "http://java.sun.com/xml/jaxp/properties/schemaLanguage",
                    "http://www.w3.org/2001/XMLSchema");
        }

        return parser;
    }

    
    public DocumentBuilder getDOMBuilder() {
        return getDOMBuilder(false, false, false, null, null);
    }    
    
    public DocumentBuilder getDOMBuilder(String property, String value) {
        return getDOMBuilder(false, false, false, property, value);
    }    
    
    public DocumentBuilder getDOMBuilder(boolean setFSP, boolean setFSPBefore, boolean secure) {
        return getDOMBuilder(setFSP, setFSPBefore, secure, null, null);
    }    
    /**
     * Return DocumentBuilder
     * @param setFSP indicate if FSP is to be set explicitly
     * @param setFSPBefore indicate FSP is set before the properties
     * @param secure secure processing
     * @param property property to be set
     * @param value value of the property
     * @return 
     */
    public DocumentBuilder getDOMBuilder(boolean setFSP, boolean setFSPBefore, 
            boolean secure, String property, String value) {
        return getDOMBuilder(setFSP, setFSPBefore, secure, property, value, false, false);
    }

    public DocumentBuilder getDOMBuilder(boolean setFSP, boolean setFSPBefore, 
            boolean secure, String property, String value,
            boolean disallowDTD, boolean notLoadExternalDTD) {
        return getDOMBuilder(setFSP, setFSPBefore, 
            secure, property, value,
            disallowDTD, notLoadExternalDTD, false);
    }
    
    public DocumentBuilder getDOMBuilder(boolean setFSP, boolean setFSPBefore, 
            boolean secure, String property, String value,
            boolean disallowDTD, boolean notLoadExternalDTD,
            boolean isValidating) {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            if (setFSP && setFSPBefore) {
                dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, secure);
            }
            if (property != null) {
                dbf.setAttribute(property, value);
            }
            
            if (disallowDTD) {
                dbf.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, true);
            }
            if (notLoadExternalDTD) {
                dbf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
            }

            if (isValidating) {
                dbf.setNamespaceAware(true);
                dbf.setValidating(true);
                dbf.setAttribute(SCHEMA_LANGUAGE, XMLConstants.W3C_XML_SCHEMA_NS_URI);
                dbf.setFeature("http://apache.org/xml/features/validation/schema", true);                
            }
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
            success("New property not supported; Test not run!");
        }
        return docBuilder;
    }    

    /**
     * Create validating DOM builder
     *
     * @param secure
     * @return
     * @throws Exception
     */
    protected DocumentBuilder createValidatingDOM(boolean secure, String property, String value) throws Exception {
        if (secure) {
            return getDOMBuilder(true, true, 
                true, property, value,
                false, false,
                true);
        } else {
            return getDOMBuilder(false, false, 
                false, property, value,
                false, false,
                true);
        }
    }

    /**
     * Check if the new properties are supported
     *
     * @return true if yes, false if not
     */
    public boolean isNewPropertySupported() {
        try {
            SAXParser parser = getSAXParser(false, false, false);
            parser.setProperty(JDK_GENEAL_ENTITY_SIZE_LIMIT, "10000");
        } catch (ParserConfigurationException ex) {
            fail(ex.getMessage());
        } catch (SAXException ex) {
            String err = ex.getMessage();
            if (err.indexOf("Property '" + JDK_GENEAL_ENTITY_SIZE_LIMIT + "' is not recognized.") > -1) {
                //expected before this patch
                debugPrint("New limit properties not supported. Tests not run.");
                return false;
            }
        }
        return true;
    }
    
    void unexpectedException(String testName, Exception e, String typeOfLimit) {
        String err = e.getMessage();
        if (err == null) err = String.valueOf(e);

        fail(testName + " Failed: " + err);
    }
    
    void expectedException(String testName, Exception e, String typeOfLimit) {
        String err = e.getMessage();
        if (err == null) err = String.valueOf(e);
        if (err.indexOf("The parser has encountered more than")>-1 && err.indexOf("entity expansions") > -1) {
            debugPrint("entity expansion limit reached");
        } else if (err.indexOf("The entity")>-1 && err.indexOf("was referenced, but not declared") > -1) {
            debugPrint("Undeclared entity is caught; Or SupportDTD=false for StAX");
        } else if (err.indexOf("JAXP0001")>-1) {
            debugPrint(err);
        } else if (err.indexOf("http://apache.org/xml/features/disallow-doctype-decl") > -1) {
            //expected error
            debugPrint(DISALLOW_DOCTYPE_DECL_FEATURE + " is set");
        } else {
            e.printStackTrace();
            fail(testName + " Failed: " + err);
        }
        success(testName + ": " + typeOfLimit + " test passed");
    }
    

    void disallowDTD(String testName, Exception e) {
        String err = e.getMessage();
        if (err == null) err = String.valueOf(e);
        if (err.indexOf("Property '" + ACCESS_EXTERNAL_DTD + "' is not recognized.") > -1) {
            //expected before this patch
            debugPrint("Property accessExternalDTD not supported");
        } else if (err.indexOf("Property '" + ACCESS_EXTERNAL_SCHEMA + "' is not recognized.") > -1) {
            debugPrint("Property accessExternalSchema not supported");
        } else if (err.indexOf("TransformerFactory does not recognise attribute") > -1) {
            debugPrint("TransformerFactory does not recognise attribute 'http://www.oracle.com/xml/jaxp/properties/accessExternalStylesheet'");
        } else if (err.indexOf("DOCTYPE is disallowed") > -1) {
            //expected error
            debugPrint(DISALLOW_DOCTYPE_DECL_FEATURE + " is set");
        } else {
            fail(testName + " failed: " + e.getMessage());
        }
        success(testName + " passed");
    }

    void fail(String errMsg) {
        if (_errMsg == null) {
            _errMsg = errMsg;
        } else {
            _errMsg = _errMsg + "\n" + errMsg;
        }
        failed++;
    }

    void success(String msg) {
        passed++;
        System.out.println(msg);
    }

    void readDTD(XMLStreamReader xsr) throws XMLStreamException {
        while (xsr.hasNext()) {
            int e = xsr.next();
            if (e == XMLEvent.DTD) {
                debugPrint("DTD: " + xsr.getText());
            }
        }

    }

    void readEvent(XMLEventReader er) throws XMLStreamException {
        XMLEvent evt = er.nextEvent();  //StartDocument
        while (evt.getEventType() != XMLStreamConstants.END_DOCUMENT) {
            if (evt.getEventType() == XMLStreamConstants.DTD) {
                debugPrint("DTD: " + evt.toString());
            }
            evt = er.nextEvent();
        }
    }
    
    /**
     * SAX handler
     */
    public class MyHandler extends DefaultHandler2 implements ErrorHandler {

        StringBuffer currentValue = new StringBuffer();

        public void startDocument() throws SAXException {
        }

        public void endDocument() throws SAXException {
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            currentValue.delete(0, currentValue.length());
            try {
                debugPrint("Element: " + uri + ":" + localName + " " + qName);
            } catch (Exception e) {
                throw new SAXException(e);
            }

        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
            debugPrint("Text: \n" + currentValue.toString() + "\n");
            debugPrint("End Element: " + uri + ":" + localName + " " + qName);
        }

        public void characters(char ch[], int start, int length) throws SAXException {
            currentValue.append(ch, start, length);
        }

        public void internalEntityDecl(String name, String value) throws SAXException {
            super.internalEntityDecl(name, value);
            debugPrint("internalEntityDecl() is invoked for entity : " + name);
        }

        public void externalEntityDecl(String name, String publicId, String systemId) throws SAXException {
            super.externalEntityDecl(name, publicId, systemId);
            debugPrint("externalEntityDecl() is invoked for entity : " + name);
        }

        public void startEntity(String name) throws SAXException {
            super.startEntity(name);
//              debugPrint("startEntity() is invoked for entity : " + name) ;
        }

        public void endEntity(String name) throws SAXException {
            super.endEntity(name);
//              debugPrint("endEntity() is invoked for entity : " + name) ;
        }

        public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
            debugPrint("resolveEntity(publicId, systemId) is invoked");
            return super.resolveEntity(publicId, systemId);
        }

        public InputSource resolveEntity(String name, String publicId, String baseURI, String systemId) throws SAXException, IOException {
            debugPrint("resolveEntity(name, publicId, baseURI, systemId) is invoked");
            return super.resolveEntity(name, publicId, baseURI, systemId);
        }

        public InputSource getExternalSubset(String name, String baseURI) throws SAXException, IOException {
            debugPrint("getExternalSubset() is invoked");
            return super.getExternalSubset(name, baseURI);
        }
    }

    /////////////////////////////////////////////////
    ///////////Using Resolver
    /////////////////////////////////////////////////
    class myEntityResolver implements EntityResolver {

        public InputSource resolveEntity(String publicId, String systemId) {
            if (systemId.indexOf("replaceWithLocalpath") > -1) {
                return new InputSource(_filepath + "/externalEntity.xml");
            }

            return null;
        }
    }

    class myExternalDTDResolver implements EntityResolver {

        public InputSource resolveEntity(String publicId, String systemId) {
            if (systemId.indexOf("externalDTD2.dtd") > -1) {
                return new InputSource(_filepath + "/externalDTD2.dtd");
            }

            return null;
        }
    }

    class MyStaxResolver implements XMLResolver {

        public MyStaxResolver() {
        }

        public Object resolveEntity(String publicId, String systemId, String baseURI, String namespace) throws javax.xml.stream.XMLStreamException {
            if (systemId.indexOf("replaceWithLocalpath") > -1) {
                InputStream is;
                try {
                    is = new FileInputStream(_filepath + "/externalEntity.xml");
                    return is;
                } catch (FileNotFoundException ex) {
                    return null;
                }
            }

            return null;
        }
    }

    DOMSource getDOMSource(String uri, String systemId) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        Document doc = dbf.newDocumentBuilder().parse(new File(uri));
        DOMSource ds = new DOMSource(doc);
        ds.setSystemId(systemId);
        return ds;
    }

    /**
     * Read from $java.home/lib/jaxp.properties for the specified property
     *
     * @param propertyId the Id of the property
     * @return the value of the property
     */
    public static String getDefaultAccessProperty(String sysPropertyId, String defaultVal) {
        String accessExternal = getSystemProperty(sysPropertyId);
        if (accessExternal != null) {
            accessExternal = accessExternal.toLowerCase();
        } else {
            accessExternal = readJAXPProperty(sysPropertyId);
            if (accessExternal == null) {
                accessExternal = defaultVal;
            }
        }
        return accessExternal;
    }

    /**
     * Save original java home, and set it to user.dir
     */
    static void setJavaHome() {
        originalJavaHome = (String)
        AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                String javaHome = System.getProperty("java.home");
                System.setProperty("java.home", System.getProperty("user.dir"));
                return javaHome;
            }
        });
    }

    /**
     * reset java home to the original value
     */
    static void resetJavaHome() {
        if (originalJavaHome != null) {
            AccessController.doPrivileged(new PrivilegedAction() {
                public Object run() {
                    System.setProperty("java.home", originalJavaHome);
                    return null;
                }
            });
        }
    }

    /**
     * Read from $java.home/lib/jaxp.properties for the specified property
     *
     * @param propertyId the Id of the property
     * @return the value of the property
     */
    static String readJAXPProperty(String propertyId) {
        String value = null;
        try {
            if (firstTime) {
                synchronized (cacheProps) {
                    if (firstTime) {
                        String configFile = getSystemProperty("java.home") + File.separator
                                + "lib" + File.separator + "jaxp.properties";
                        File f = new File(configFile);
                        firstTime = false;
                        if (getFileExists(f)) {
                            cacheProps.load(getFileInputStream(f));
                        }
                    }
                }
            }
            value = cacheProps.getProperty(propertyId);

        } catch (Exception ex) {
        }

        return value;
    }

    public static String getSystemProperty(final String propName) {
        return (String) AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                return System.getProperty(propName);
            }
        });
    }

    static boolean getFileExists(final File f) {
        return ((Boolean) AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                return f.exists() ? Boolean.TRUE : Boolean.FALSE;
            }
        })).booleanValue();
    }

    static FileInputStream getFileInputStream(final File file)
            throws FileNotFoundException {
        try {
            return (FileInputStream) AccessController.doPrivileged(new PrivilegedExceptionAction() {
                public Object run() throws FileNotFoundException {
                    return new FileInputStream(file);
                }
            });
        } catch (PrivilegedActionException e) {
            throw (FileNotFoundException) e.getException();
        }
    }


    

    static final String javaVersion = System.getProperty("java.version");
    static final double versionNumber = getJavaVersion();
    static double getJavaVersion() {
        String version = javaVersion.substring(0, javaVersion.indexOf('.', 2));
        return Double.parseDouble(version);
    }

    /**
     * Cache for properties in java.home/lib/jaxp.properties
     */
    static final Properties cacheProps = new Properties();
    /**
     * Flag indicating if properties from java.home/lib/jaxp.properties have
     * been cached.
     */
    static volatile boolean firstTime = true;

    static void debugPrint(String msg) {
        if (DEBUG) {
            System.out.println(msg);
        }
    }
}
