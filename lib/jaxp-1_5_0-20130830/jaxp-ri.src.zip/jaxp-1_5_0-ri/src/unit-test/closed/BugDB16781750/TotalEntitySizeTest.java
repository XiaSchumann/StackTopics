package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test entity expansion limit
 * @run main/othervm OneTest
 */
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.SAXParser;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import org.w3c.dom.Document;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Total entity size limit tests
 *
 * @author huizhe.wang@oracle.com
 */
public class TotalEntitySizeTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public TotalEntitySizeTest(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        TotalEntitySizeTest test = new TotalEntitySizeTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();
            test.testSAXGETESL_Default();
            test.testSAXGETESL_FSPOn();
            test.testSAXGETESL_FSPOff();
            test.testSAXGETESL_SP_OverLimit();
            test.testSAXGETESL_API_Overlimit();
            test.testSAXGETESL_API_SP();
            
            test.testDOMGETESL_Default();
            test.testDOMGETESL_FSPOn();
            test.testDOMGETESL_FSPOff();
            test.testDOMGETESL_SP_OverLimit();
            test.testDOMGETESL_API_Overlimit();
            test.testDOMGETESL_API_SP();
            
            test.testStAXGETESL_Default();
            test.testStAXGETESL_SP_OverLimit();
            test.testStAXGETESL_API_OverLimit();
            test.testStAXGETESL_NotSupportDTD();
            test.testStAXGETESL_isReplacingEntityReferences();            

            test.tearDown();
        }

    }
    
    /////////////////////////////////////////////////
    ///////////General Entity Reference
    /////////////////////////////////////////////////
    
    //totalEntitySizeLimit tests
    /**
     * By default, the limit is 256 x 10 ^ 6
     */
    public void testSAXGETESL_Default() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlGE64005_10000), new DefaultHandler());
            fail("testSAXGETESL_Default failed: totalEntitySizeLimit");
        } catch (Exception e) {
            expectedException("testSAXGETESL_Default", e, "totalEntitySizeLimit");
        }
    }

    /**
     * By default, FEATURE_SECURE_PROCESSING is true, setting FSP therefore 
     * does not make any difference
     */
    public void testSAXGETESL_FSPOn() {

        try {
            SAXParser parser = getSAXParser(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_TRUE);
            parser.parse(new File(_xmlGE64005_10000), new DefaultHandler());
            fail("testSAXGESL_FSPOn failed: totalEntitySizeLimit test passed");
        } catch (Exception e) {
            expectedException("testSAXGESL_FSPOn", e, "entityExpansion");
        }
    }

    /**
     * Set FEATURE_SECURE_PROCESSING to false, no limit
     */
    public void testSAXGETESL_FSPOff() {

        try {
            SAXParser parser = getSAXParser(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_FALSE);
            parser.parse(new File(_xmlGE64005_10000), new DefaultHandler());
            success("testSAXGESL_FSPOff: totalEntitySizeLimit test passed: no limit");
        } catch (Exception e) {
            unexpectedException("testSAXGESL_FSPOff", e, "entityExpansion");
        }
    }
    
    /**
     * Use system property to set a limit
     */
    public void testSAXGETESL_SP_OverLimit() {
        System.setProperty(SP_TOTAL_ENTITY_SIZE_LIMIT, "1700");

        try {
            SAXParser parser = getSAXParser();
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            fail("testSAXGETESL_SP_OverLimit failed: over the totalEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGETESL_SP_OverLimit", e, "totalEntitySizeLimit");
        } finally {
            System.clearProperty(SP_TOTAL_ENTITY_SIZE_LIMIT);
        }
    }    
    
    /**
     * Use API property to set a limit
     */
    public void testSAXGETESL_API_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "1700");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            fail("testSAXGETESL_API_Overlimt failed: totalEntitySizeLimit test failed");
        } catch (Exception e) {
            expectedException("testSAXGETESL_API_Overlimt", e, "totalEntitySizeLimit");
        }
    }
    /**
     * The API property override any that may be set by other means
     */
    public void testSAXGETESL_API_SP() {
        System.setProperty(SP_TOTAL_ENTITY_SIZE_LIMIT, "1700");

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "2000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlGE9), new DefaultHandler());
            success("testSAXGETESL_API_SP: totalEntitySizeLimit test passed");
        } catch (Exception e) {
            unexpectedException("testSAXGETESL_API_SP", e, "totalEntitySizeLimit");
        } finally {
            System.clearProperty(SP_TOTAL_ENTITY_SIZE_LIMIT);
        }
    }
    
    /**
     * DOM consumes more memory; On client VM, the limit is 50000000
     */
    public void testDOMGETESL_Default() {

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlGE64005_2800));
            fail("testDOMGETESL_Default failed: totalEntitySizeLimit test");
        } catch (Exception e) {
            expectedException("testDOMGETESL_Default", e, "totalEntitySizeLimit");
        }
    }
    
        
    /**
     * By default, FEATURE_SECURE_PROCESSING is already true, but let's still
     * test setting FSP explicitly 
     */
    public void testDOMGETESL_FSPOn() {

        DocumentBuilder docBuilder = getDOMBuilder(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_TRUE);
        try {
            Document document = docBuilder.parse(new File(_xmlGE64005_10000));
            fail("testDOMGETESL_FSPOn failed: totalEntitySizeLimit test passed");
        } catch (Exception e) {
            expectedException("testDOMGETESL_FSPOn", e, "entityExpansion");
        }
    }

    /**
     * Set FEATURE_SECURE_PROCESSING to false, no limit
     */
    public void testDOMGETESL_FSPOff() {

        DocumentBuilder docBuilder = getDOMBuilder(SET_FSP_EXPLICITLY, SET_FSP_BEFORE, SECURE_PROCESSING_FALSE);
        try {
            Document document = docBuilder.parse(new File(_xmlGE64005_2800));
            success("testDOMGETESL_FSPOff: totalEntitySizeLimit test passed: no limit");
        } catch (Exception e) {
            unexpectedException("testDOMGETESL_FSPOff", e, "totalEntitySizeLimit");
        }
    }   
    
    /**
     * Use system property to set a limit
     */
    public void testDOMGETESL_SP_OverLimit() {
        System.setProperty(SP_TOTAL_ENTITY_SIZE_LIMIT, "1700");

        DocumentBuilder docBuilder = getDOMBuilder();
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));
            fail("testDOMGETESL_SP_OverLimit failed: over the totalEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMGETESL_SP_OverLimit", e, "totalEntitySizeLimit");
        } finally {
            System.clearProperty(SP_TOTAL_ENTITY_SIZE_LIMIT);
        }
    }    
    /**
     * Use API property to set a limit
     */
    public void testDOMGETESL_API_Overlimit() {

        DocumentBuilder docBuilder = getDOMBuilder(JDK_TOTAL_ENTITY_SIZE_LIMIT, "1700");
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));            
            fail("testDOMGETESL_API_Overlimit failed: over the totalEntitySizeLimitLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testDOMGETESL_API_Overlimit", e, "totalEntitySizeLimit");
        }
    }    
        
    /**
     * The API property overrides any that may be set by other means
     */
    public void testDOMGETESL_API_SP() {
        System.setProperty(SP_TOTAL_ENTITY_SIZE_LIMIT, "1700");

        DocumentBuilder docBuilder = getDOMBuilder(JDK_TOTAL_ENTITY_SIZE_LIMIT, "1900");
        try {
            Document document = docBuilder.parse(new File(_xmlGE9));            
            success("testDOMGETESL_API_SP: totalEntitySizeLimitLimit test passed");
        } catch (Exception e) {
            unexpectedException("testDOMGETESL_API_SP", e, "totalEntitySizeLimit");
        } finally {
            System.clearProperty(SP_TOTAL_ENTITY_SIZE_LIMIT);
        }
    }    

    /**
     * StAX
     */
    /**
     * On client VM, the limit is 50000000
     */
    public void testStAXGETESL_Default() {

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE64005_1350, new FileInputStream(new File(_xmlGE64005_1350)));
            readDTD(xsr);
            success("testStAXGETESL_Default: generalEntitySize test passed");
        } catch (Exception e) {
            unexpectedException("testStAXGETESL_Default", e, "generalEntitySize");
            e.printStackTrace();
        }
    } 
    
    /**
     * Accumulated total size will be 1800
     */
    public void testStAXGETESL_SP_OverLimit() {
        System.setProperty(SP_TOTAL_ENTITY_SIZE_LIMIT, "1700");
        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testStAXGETESL_SP_OverLimit: over the generalEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testStAXGETESL_SP_OverLimit", e, "generalEntitySize");
        } finally {
            System.clearProperty(SP_TOTAL_ENTITY_SIZE_LIMIT);
        }
    }    

    /**
     * Parsing a file that contains total entity 1800 with a limit set to 1700 through the
     * API property; API property always take preference
     */
    public void testStAXGETESL_API_OverLimit() {
        System.setProperty(SP_TOTAL_ENTITY_SIZE_LIMIT, "2000");

        try {
            XMLInputFactory xif = XMLInputFactory.newInstance();
            xif.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "1700");
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testSAXGE_API_OverLimit: over the generalEntitySizeLimit, shall throw exception");
        } catch (Exception e) {
            expectedException("testSAXGE_API_OverLimit", e, "generalEntitySize");
        } finally {
            System.clearProperty(SP_TOTAL_ENTITY_SIZE_LIMIT);
        }
    }    
    
    /**
     * When SupportDTD=false, entity reference will result in an error
     */
    public void testStAXGETESL_NotSupportDTD() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
            xif.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "2000");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            fail("testStAXGETESL_NotSupportDTD: SupportDTD=false, shall throw exception");
        } catch (Exception e) {
            expectedException("testStAXGETESL_NotSupportDTD", e, "generalEntitySize");
        }
    }

    /**
     * When IS_REPLACING_ENTITY_REFERENCES=false, entity will not be started. The parser
     * returns entity reference without resolving it. The total size limit doesn't matter
     */
    public void testStAXGETESL_isReplacingEntityReferences() {
        XMLInputFactory xif = null;
        try {
            xif = XMLInputFactory.newInstance();
            xif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
            xif.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "1700");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        try {
            XMLStreamReader xsr = xif.createXMLStreamReader(_xmlGE9, new FileInputStream(new File(_xmlGE9)));
            readDTD(xsr);
            success("testStAXGETESL_isReplacingEntityReferences: IS_REPLACING_ENTITY_REFERENCES=false, passed");
        } catch (Exception e) {
            unexpectedException("testStAXGETESL_isReplacingEntityReferences", e, "generalEntitySize");
        }
    }
}
