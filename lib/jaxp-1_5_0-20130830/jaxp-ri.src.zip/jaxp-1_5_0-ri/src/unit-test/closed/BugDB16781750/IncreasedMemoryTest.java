package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary these tests require increase memory to pass
 * @run main/othervm -Xmx 500M IncreasedMemoryTest
 */
import java.io.*;
import javax.xml.parsers.SAXParser;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Compare with those in DefaultMemoryTest. 300M is enough for these tests
 * to pass. 
 * 
 * @author huizhe.wang@oracle.com
 */
public class IncreasedMemoryTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public IncreasedMemoryTest(String name) {
        super(name);
    }
    
    protected void setUp() {
        super.setUp();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        IncreasedMemoryTest test = new IncreasedMemoryTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();
            test.testSAXPESL_5M_Overlimit();
            test.testSAXPESL_2M_Overlimit();
            test.testSAXPESL_100K_Overlimit();
            test.tearDown();
        }

    }
    

    //////////////////////////////////////////////////////////////
    ///////////These tests are executed with increased memory/////
    //////////////////////////////////////////////////////////////
    //maxParameterEntitySizeLimit tests
    

    /**
     * within a limit of 5,000,000, 9x7x10 would have caused OOME but for 
     * increased memory
     */
    public void testSAXPESL_5M_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "100000000");
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "5000000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE9x7x11), new DefaultHandler());
            success("testSAXPESL_5M_Overlimit: maxParameterEntitySizeLimit: ok with increased memory");
        } catch (Exception e) {
            unexpectedException("testSAXPESL_5M_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }    
    
    /**
     * within a limit of 2,000,000, 11x6x32 would have caused OOME but for 
     * increased memory
     */
    public void testSAXPESL_2M_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "100000000");
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "2000000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE11x6x32), new DefaultHandler());
            success("testSAXPESL_2M_Overlimit: maxParameterEntitySizeLimit: ok with increased memory");
        } catch (Exception e) {
            unexpectedException("testSAXPESL_2M_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }    
    
    /**
     * within a limit of 100,000, 5x7x655 would have caused OOME but for 
     * increased memory
     */
    public void testSAXPESL_100K_Overlimit() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_TOTAL_ENTITY_SIZE_LIMIT, "100000000");
            parser.setProperty(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "100000");
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlPE5x7x655), new DefaultHandler());
            success("testSAXPESL_100K_Overlimit: maxParameterEntitySizeLimit: ok with increased memory");
        } catch (Exception e) {
            unexpectedException("testSAXPESL_100K_Overlimit", e, "maxParameterEntitySizeLimit");
        }
    }    

}
