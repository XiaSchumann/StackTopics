package closed.BugDB16781750;

/*
 * Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @test
 * @bug 8014530
 * @key closed-security
 * @summary test XSLT portion of external reference restriction
 * @run main/othervm OneTest
 */
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import org.w3c.dom.Document;
import org.xml.sax.helpers.DefaultHandler;

/**
 * One test
 * 
 * @author huizhe.wang@oracle.com
 */
public class SamplesTest extends TestBase {

    /**
     * Creates a new instance of StreamReader
     */
    public SamplesTest(String name) {
        super(name);
    }
    
    String _xmlSample_Templates, _xmlSample_html, _xmlSample_Mathml;
    
    protected void setUp() {
        super.setUp();
        _xmlSample_Templates = _filepath + "/samples/Templates.xml";    
        _xmlSample_html = _filepath + "/samples/html.xml";    
        _xmlSample_Mathml = _filepath + "/samples/mathml3.xml";    
        if (isWindows) {
            _xmlSample_Templates = "/" + _xmlSample_Templates;
            _xmlSample_html = "/" + _xmlSample_html;
            _xmlSample_Mathml = "/" + _xmlSample_Mathml;
        }    
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        SamplesTest test = new SamplesTest("OneTest");
        if (test.isNewPropertySupported()) {
            test.setUp();

            
            test.testHTMLDTD();
            test.testMathml();
            test.testTemplates();
            test.tearDown();
        }

    }
    
    /**
     * parse some samples to understand the need for entity expansions
     */
    public void testHTMLDTD() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlSample_html), new DefaultHandler());
            success("testHTMLDTD: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testHTMLDTD", e, "entityExpansion");
        }
    }
    /**
     * parse some samples to understand the need for entity expansions
     */
    public void testMathml() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlSample_Mathml), new DefaultHandler());
            success("testMathml: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testMathml", e, "entityExpansion");
        }
    }
    
    /**
     * parse some samples to understand the need for entity expansions
     */
    public void testTemplates() {

        try {
            SAXParser parser = getSAXParser();
            parser.setProperty(JDK_ENTITY_COUNT_INFO, "yes");
            parser.parse(new File(_xmlSample_Templates), new DefaultHandler());
            success("testTemplates: entityExpansion test passed");
        } catch (Exception e) {
            unexpectedException("testTemplates", e, "entityExpansion");
        }
    }    
    /**
     * By default, no limit 
     */
    public void testMemoryUsage() {
        reportMemUsuage("before test:");
        long mem0 = startMemory();
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            //dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            //dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, Boolean.TRUE);
            dbf.setNamespaceAware(true);
            dbf.setAttribute(JDK_PARAMETER_ENTITY_SIZE_LIMIT, "5000000");
            dbf.setAttribute(JDK_ENTITY_COUNT_INFO, "yes");
            DocumentBuilder db = dbf.newDocumentBuilder();

//            InputSource is = new InputSource(new FileInputStream(file));
//            is.setSystemId(file);
//            Document doc = db.parse(new FileInputStream(_xmlPE3by3), _xmlPE3by3id);
//            Document doc = db.parse(new File(_xmlSchemaXSD)); 
            Document doc = db.parse(new File(_xmlPE10by10)); 
            //printDOMTree(doc);
        } catch (OutOfMemoryError oom) {
            oom.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            long memUsed1 = mem0 - endMemory();
            System.out.println("Memory used: " + memUsed1 / 1024 / 1024 + "MB");
            final long usedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            System.out.println("Memory used: usedMem=" + usedMem / 1024 / 1024 + "MB");
        }
    }

    public void printDOMTree(Document doc) {
        OutputStreamWriter outWriter = null;
        try {
            outWriter = new OutputStreamWriter(System.out, DOMEcho.outputEncoding);
            PrintWriter writer = new PrintWriter(outWriter, true);
            DOMEcho echo = new DOMEcho(writer);
            new DOMEcho(new PrintWriter(outWriter, true)).echo(doc);
        } catch (UnsupportedEncodingException ex) {        
            ex.printStackTrace();
        } finally {
            try {
                outWriter.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    protected void setUp1() {
        super.setUp();
System.out.println("\n filepath: " + _filepath);
        if (isWindows) {
            _filepath = _filepath.replace('\\', '/');
System.out.println("is windows, replace \\ with /, _filepath: " +_filepath);
        _xmlGENotDeclared = "/" + _filepath + "/testGENotDeclared.xml";
        _xmlGE9 = "/" + _filepath + "/testGE9.xml";
        _xmlGE64005 = "/" + _filepath + "/testGE64005.xml";
System.out.println("is windows?, _xmlGE64005: " +_xmlGE64005);
        _xmlGE64006 = "/" + _filepath + "/testGE64006.xml";
        } else {
        _xmlGE9 = _filepath + "/testGE9.xml";
        _xmlGE64005 = _filepath + "/testGE64005.xml";
System.out.println("not windows?, _filepath" +_filepath);
System.out.println("not windows?, _xmlGE64005" +_xmlGE64005);
        _xmlGE64006 = _filepath + "/testGE64006.xml";
        }        
        _xmlGE64005Id = "file:" + _xmlGE64005;
        
System.out.println("is windows?, _xmlGE64005Id: " +_xmlGE64005Id);
        
      
    }

    long startMemory() {
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        long memFree = Runtime.getRuntime().freeMemory();
        return memFree;
    }

    long endMemory() {
        long memFree = Runtime.getRuntime().freeMemory();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        return memFree;
    }

    void reportMemUsuage(String msg) {
        System.out.println(msg);
        long memTotal = Runtime.getRuntime().totalMemory();
        long memFree = Runtime.getRuntime().freeMemory();
        long maxBytes = Runtime.getRuntime().maxMemory();
        System.out.println("Memory in JVM: \nMax: " + maxBytes / 1024 / 1024 + "MB \nTotal available: " + memTotal / 1024 / 1024 + "MB \nFree: " + memFree / 1024 / 1024 + "M");
    }
    
}
