/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package closed.BugDB16672496;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.security.Policy;
import java.security.ProtectionDomain;
import java.util.EnumSet;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import junit.framework.TestCase;
import junit.textui.TestRunner;

public class ReadSystemPropertyTest extends TestCase {

    public static void main(String[] args) {
        TestRunner.run(ReadSystemPropertyTest.class);
    }
    private boolean hasSM;
    private Policy _orig;

    @Override
    protected void setUp() {
        //System.out.println("_filepath=" + _filepath);
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        _orig = Policy.getPolicy();
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }
    // We could use user.home here - except that we can't rely on
    // its value to be always successfully detected in the stack trace.
    // We don't want to arbitrarily set the value of user.home to a value
    // that we're sure to detect as it could have side effects, so
    // instead we're using a fake property - for which we can control
    // the value: which property we use doesn't really matter anyway since
    // our test shouldn't have the permission to read any system property.
    //
    private final static String PROP_NAME = "user.home.test";
    private final static String marker = "/my/test/user/home";

    public void testSystemProperty() {
        System.setProperty(PROP_NAME, marker);
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"));
        Policy.setPolicy(p);
        System.setSecurityManager(new SecurityManager());

        try {
            final String value = System.getProperty(PROP_NAME);
            throw new Error("Got " + PROP_NAME + "=\"" + value + "\"");
        } catch (SecurityException x) {
            System.out.println("Access to \"" + PROP_NAME + "\" was not granted");
        }

        int failed = 0;
        final StringBuilder messages = new StringBuilder();
        for (FactoryType factory : EnumSet.allOf(FactoryType.class)) {
            try {
                flushStdOut();
                try {
                    runTest(factory);
                    throw new Error(
                            factory.type.getSimpleName() + ".newFactory("
                            + PROP_NAME + "=\"" + marker
                            + "\", Thread.currentThread()"
                            + ".getContextClassLoader())"
                            + " should have failed.");
                } catch (Throwable t) {
                    final ByteArrayOutputStream os =
                            new ByteArrayOutputStream();
                    final PrintStream osw = new PrintStream(os);
                    t.printStackTrace(osw);
                    if (os.toString().contains(marker)) {
                        throw new Error(factory.type.getSimpleName()
                                + ".newFactory: "
                                + "Stack trace contains property value: "
                                + marker, t);
                    } else {
                        System.out.println(factory.type.getSimpleName()
                                + ".newFactory: "
                                + "Exception stack trace verified. "
                                + "Marker not present:\n"
                                + os.toString());
                    }
                } finally {
                    flushStdOut();
                }
            } catch (Throwable t) {
                t.printStackTrace();
                failed++;
                messages.append("\tFAILED (runTest): ")
                        .append(t.getMessage()).append("\n");
            }
        }
        if (failed > 0) {
            throw new AssertionError("Some tests failed: \n"
                    + messages.toString());
        } else {
            System.out.println("All tests sucessfully passed");
        }
    }

    private static enum FactoryType {

        EVENT(XMLEventFactory.class) {
            @Override
            XMLEventFactory newFactory(String factoryId, ClassLoader loader) {
                return XMLEventFactory.newFactory(factoryId, loader);
            }
        },
        INPUT(XMLInputFactory.class) {
            @Override
            XMLInputFactory newFactory(String factoryId, ClassLoader loader) {
                return XMLInputFactory.newFactory(factoryId, loader);
            }
        },
        OUTPUT(XMLOutputFactory.class) {
            @Override
            XMLOutputFactory newFactory(String factoryId, ClassLoader loader) {
                return XMLOutputFactory.newFactory(factoryId, loader);
            }
        };
        private final Class<?> type;

        FactoryType(Class<?> type) {
            this.type = type;
        }

        abstract Object newFactory(String factoryId, ClassLoader loader);
    }

    private static void runTest(FactoryType factory) {
        System.out.println("Calling " + factory.type.getSimpleName()
                + ".newFactory("
                + PROP_NAME + "=\"" + marker
                + "\", Thread.currentThread()"
                + ".getContextClassLoader())");
        final Object instance =
                factory.newFactory(PROP_NAME,
                Thread.currentThread().getContextClassLoader());
    }

    // Avoids garbled output
    private static void flushStdOut() throws InterruptedException {
        System.out.flush();
        Thread.sleep(100);
    }

    /**
     * Simple policy implementation that grants a set of permissions to all code
     * sources and protection domains.
     */
    static class SimplePolicy extends Policy {

        private final Permissions perms;

        public SimplePolicy(Permission... permissions) {
            perms = new Permissions();
            for (Permission permission : permissions) {
                perms.add(permission);
            }
        }

        @Override
        public PermissionCollection getPermissions(CodeSource cs) {
            return perms;
        }

        @Override
        public PermissionCollection getPermissions(ProtectionDomain pd) {
            return perms;
        }

        @Override
        public boolean implies(ProtectionDomain pd, Permission p) {
            return perms.implies(p);
        }
    }
}
