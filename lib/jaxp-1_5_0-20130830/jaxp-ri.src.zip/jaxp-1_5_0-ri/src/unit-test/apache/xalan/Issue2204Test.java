/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package apache.xalan;


import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.StringWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import junit.textui.TestRunner;
import junit.framework.TestCase;


/**
 * <p>Test {@link javax.xml.transform.Transformer} for
 * CR 6905829:
 * Fix for 622552 should be integrated correctly in jdk5ux
 * </p>
 *
 * The problem was caused by a typo during jdk5 integration
 * This test is to answer licensee question
 * joe.wang@sun.com
 */
public class Issue2204Test extends TestCase {

    public static void main(String [] args){
        TestRunner.run(Issue2204Test.class);
    }

    /**

     */
    public final void testTransform() {
        try {
            Transformer t = TransformerFactory.newInstance()
                        .newTransformer(new StreamSource("./jaxp-ri/src/unit-test/apache/xalan/Issue2204.xsl"));

            System.out.printf("transformer: %s%n", t.getClass().getName());

            StringWriter streamResult = new StringWriter();
            t.transform(new StreamSource("./jaxp-ri/src/unit-test/apache/xalan/Issue2204.xml"),
                        new StreamResult(streamResult));

            System.out.println(streamResult.toString());
            if (streamResult.toString().indexOf("3") > 0) {
                fail("Function Count on variable modifies number of nodes in variable.");
            }
            // expected success
        } catch (Exception e) {
            // unexpected failure
            e.printStackTrace();
            fail(e.toString());
        }
    }
}
