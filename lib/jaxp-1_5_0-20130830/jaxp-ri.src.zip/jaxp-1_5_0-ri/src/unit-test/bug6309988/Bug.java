/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * Bug.java
 *
 * Created on October 22, 2005, 10:33 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package bug6309988;

/**
 *
 * @author Sunitha Reddy
 */
import common.SimplePolicy;
import java.io.*;
import java.security.Policy;
import java.util.PropertyPermission;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.*;

public class Bug extends TestCase {

    DocumentBuilderFactory dbf = null;
    static boolean _isSecureMode = false;

    static {
        if (System.getSecurityManager() != null) {
            _isSecureMode = true;
            System.out.println("Security Manager is present");
        } else {
            System.out.println("Security Manager is NOT present");
        }
    }
    private boolean hasSM;
    private Policy _orig;
    private String _filePath;
    /**
     * Creates a new instance of Bug
     */
    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }
        _orig = Policy.getPolicy();

        String path = this.getClass().getResource("DosTest.xml").getPath();
        _filePath = path.substring(0, path.lastIndexOf("/"));
        if (hasSM) {
            Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new PropertyPermission("elementAttributeLimit", "write"),
                    new PropertyPermission("entityExpansionLimit", "write"),
                    new PropertyPermission("maxOccurLimit", "write"),
                    new FilePermission(_filePath + "/-", "read"));
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    /* Given XML document has more than 10000 attributes. Exception is expected
     */
    public void testDOMParserElementAttributeLimit() {
        try {
            dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest.xml"));
            fail("SAXParserException is expected, as given XML document contains more than 10000 attributes");
        } catch (SAXParseException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        }
    }

    /* Given XML document has more than 10000 attributes.
     * It should report an error.
     */
    public void testDOMNSParserElementAttributeLimit() {
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest.xml"));
            fail("SAXParserException is expected, as given XML document contains more than 10000 attributes");
        } catch (SAXParseException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        }
    }

    /* Given XML document has more than 10000 attributes. Parsing this XML document
     * in non-secure mode, should not report any error.
     */
    public void testDOMNSParserElementAttributeLimitWithoutSecureProcessing() {
        if (_isSecureMode) {
            return; //jaxp secure feature can not be turned off when security manager is present
        }
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            dbf.setNamespaceAware(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest.xml"));

        } catch (SAXParseException e) {
            fail(e.getMessage());
        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        }
    }

    /* Before 8014530:
     * Given XML document has 3 attributes and System property is set to 2. Parsing this XML document
     * in non-secure mode, should not report an error.
     * 
     * After 8014530:
     * System properties will override FSP, the result of this test should be the same as
     * testSystemElementAttributeLimitWithSecureProcessing
     */
    public void testSystemElementAttributeLimitWithoutSecureProcessing() {
        if (_isSecureMode) {
            return; //jaxp secure feature can not be turned off when security manager is present
        }
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            dbf.setNamespaceAware(true);
            System.setProperty("elementAttributeLimit", "2");
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest3.xml"));
            fail("SAXParserException is expected, as given XML document contains more than 2 attributes");
        } catch (Exception e) {
            String errMsg = e.getMessage();
            Throwable cause = e.getCause();
            if (cause != null) {
                errMsg += cause.getMessage();
            }
            if (errMsg.contains("JAXP0001")) {
                //expected
            } else {
                fail("Unexpected error: " + e.getMessage());
            }
        } finally {
            System.clearProperty("elementAttributeLimit");
        }
    }

    /* Given XML document has 3 attributes and System property is set to 2. Parsing this XML document
     * in secure mode, should report an error.
     */
    public void testSystemElementAttributeLimitWithSecureProcessing() {
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            System.setProperty("elementAttributeLimit", "2");
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("DosTest3.xml"));
            fail("SAXParserException is expected, as given XML document contains more than 2 attributes");
        } catch (SAXParseException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        } finally {
            System.clearProperty("elementAttributeLimit");
        }
    }

    /* Default value for secure processing feature should be false.
     */
    public void testDOMSecureProcessingDefaultValue() {
        try {
            dbf = DocumentBuilderFactory.newInstance();
            assertTrue("Default value for secureProcessing feature should be true", dbf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING));

        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        }
    }

    /* Default value for secure processing feature should be false.
     */
    public void testSAXSecureProcessingDefaultValue() {
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            assertTrue("Default value for secureProcessing feature should be true", spf.getFeature(XMLConstants.FEATURE_SECURE_PROCESSING));

        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        }
    }

    /* This method sets system property for maxOccurLimit=2 and secure process
     * feature is off. Given doument contains more than 2 elements and hence
     * an error should be reported.
     */
    public void testSystemMaxOccurLimitWithoutSecureProcessing() {
        if (_isSecureMode) {
            return; //jaxp secure feature can not be turned off when security manager is present
        }
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            spf.setValidating(true);
            System.setProperty("maxOccurLimit", "2");
            // Set the properties for Schema Validation
            String SCHEMA_LANG = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
            String SCHEMA_TYPE = "http://www.w3.org/2001/XMLSchema";
            //Get the Schema location as a File object
            File schemaFile = new File(this.getClass().getResource("toys.xsd").toURI());
            //Get the parser
            SAXParser parser = spf.newSAXParser();
            parser.setProperty(SCHEMA_LANG, SCHEMA_TYPE);
            parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", schemaFile);

            InputStream is = this.getClass().getResourceAsStream("toys.xml");
            MyErrorHandler eh = new MyErrorHandler();
            parser.parse(is, eh);
            assertFalse("Not Expected Error ", eh.errorOccured);
            System.setProperty("maxOccurLimit", "");
        } catch (Exception e) {
            fail("Exception occured: " + e.getMessage());
        }
    }

    /* This method sets system property for maxOccurLimit=2 and secure process
     * feature is ON. Given doument contains more than 2 elements and hence
     * an error should be reported.
     *
     * THIS RESTRICTION HAS BEEN LIFTED AFTER THE IMPLEMENTATION OF A
     * CONSTANT SPACE ALGORITHM TO VALIDATE THESE TYPES OF SCHEMAS. FOR
     * NOW, WE ARE COMMENTING OUT THIS UNIT TEST.
     *
     public void testSystemMaxOccurLimitWithSecureProcessing()
     {
     try{
     SAXParserFactory spf = SAXParserFactory.newInstance();
     spf.setValidating(true);
     System.setProperty("maxOccurLimit","2");
     // Set the properties for Schema Validation
     String SCHEMA_LANG ="http://java.sun.com/xml/jaxp/properties/schemaLanguage";
     String SCHEMA_TYPE="http://www.w3.org/2001/XMLSchema";
     //Get the Schema location as a File object
     File schemaFile=new File(this.getClass().getResource("toys.xsd").toURI());
     //Get the parser
     SAXParser parser = spf.newSAXParser();
     parser.setProperty(SCHEMA_LANG, SCHEMA_TYPE);
     parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource",schemaFile);

     InputStream is = this.getClass().getResourceAsStream("toys.xml");
     MyErrorHandler eh = new MyErrorHandler();
     parser.parse(is,eh);
     assertTrue("Expected Error as maxOccurLimit is exceeded",eh.errorOccured);
     System.setProperty("maxOccurLimit","");
     }catch(Exception e){
     fail("Exception occured: " + e.getMessage());
     }
     }
     */

    /* This test will take longer time to execute( abt 120sec).
     * This method tries to validate a document. This document contains an
     * element whose maxOccur is '3002'. Since secure processing feature is off,
     * document should be parsed without any errors.
     */
    public void testValidMaxOccurLimitWithOutSecureProcessing() {
        if (_isSecureMode) {
            return; //jaxp secure feature can not be turned off when security manager is present
        }
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            spf.setValidating(true);
            // Set the properties for Schema Validation
            String SCHEMA_LANG = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
            String SCHEMA_TYPE = "http://www.w3.org/2001/XMLSchema";
            //Get the Schema location as a File object
            File schemaFile = new File(this.getClass().getResource("toys3002.xsd").toURI());
            //Get the parser
            SAXParser parser = spf.newSAXParser();
            parser.setProperty(SCHEMA_LANG, SCHEMA_TYPE);
            parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", schemaFile);

            InputStream is = this.getClass().getResourceAsStream("toys.xml");
            MyErrorHandler eh = new MyErrorHandler();
            parser.parse(is, eh);
            assertFalse("Expected Error as maxOccurLimit is exceeded", eh.errorOccured);

        } catch (Exception e) {
            fail("Exception occured: " + e.getMessage());
        }
    }

    /* Before 8014530:
     * System property is set to 2. Given XML document has more than 2 entity references.
     * Parsing this document in non-secure mode, should *not* report an error.
     * 
     * After 8014530:
     * System properties will override FSP, the result of this test should be the same as
     * testSystemElementAttributeLimitWithSecureProcessing
     */
    public void testSystemEntityExpansionLimitWithOutSecureProcessing() {
        if (_isSecureMode) {
            return; //jaxp secure feature can not be turned off when security manager is present
        }
        try {
            System.setProperty("entityExpansionLimit", "2");
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            dbf.setValidating(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("entity.xml"));
            fail("SAXParserException is expected, as given XML document contains more 2 entity references");
        } catch (Exception e) {
            String errMsg = e.getMessage();
            Throwable cause = e.getCause();
            if (cause != null) {
                errMsg += cause.getMessage();
            }
            if (errMsg.contains("JAXP0001")) {
                //expected
            } else {
                fail("Unexpected error: " + e.getMessage());
            }
        } finally {
            System.clearProperty("entityExpansionLimit");
        }
    }

    /* System property is set to 2. Given XML document has more than 2 entity references.
     * Parsing this document in secure mode, should report an error.
     */
    public void testSystemEntityExpansionLimitWithSecureProcessing() {
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(true);
            System.setProperty("entityExpansionLimit", "2");
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("entity.xml"));
            fail("SAXParserException is expected, as given XML document contains more 2 entity references");

        } catch (SAXParseException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        } finally {
            System.setProperty("entityExpansionLimit", "");
        }
    }

    /* Given XML document has more than 64000 entity references.
     * Parsing this document in secure mode, should report an error.
     */
    public void testEntityExpansionLimitWithSecureProcessing() {
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("entity64K.xml"));
            fail("SAXParserException is expected, as given XML document contains more 2 entity references");

        } catch (SAXParseException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        } finally {
            System.setProperty("entityExpansionLimit", "");
        }
    }

    /* Given XML document has more than 64000 entity references.
     * Parsing this document in non-secure mode, should not report any error.
     */
    public void testEntityExpansionLimitWithOutSecureProcessing() {
        if (_isSecureMode) {
            return; //jaxp secure feature can not be turned off when security manager is present
        }
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, false);
            dbf.setValidating(true);
            DocumentBuilder parser = dbf.newDocumentBuilder();
            Document doc = parser.parse(this.getClass().getResourceAsStream("entity64K.xml"));

        } catch (SAXParseException e) {
            fail("Exception " + e.getMessage());
        } catch (Exception e) {
            fail("Exception " + e.getMessage());
        } finally {
            System.setProperty("entityExpansionLimit", "");
        }
    }
}
