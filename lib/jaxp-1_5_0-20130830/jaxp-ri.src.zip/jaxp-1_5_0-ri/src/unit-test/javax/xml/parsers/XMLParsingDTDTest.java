/**
 * USE closed.bugdb14495809.XMLParingDTD instead
 */
package javax.xml.parsers;

import java.io.*;
import java.util.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.*;
import javax.xml.stream.*;
import javax.xml.transform.stax.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 */
public class XMLParsingDTDTest extends TestBase {

    static String xml = "<?xml version='1.0' encoding='UTF-8' standalone='no'?>"
            + "<!DOCTYPE foo [ "
            + "<!ENTITY bar 'test' >"
            + "]>"
            + "<foo>&bar;</foo>";

    public static void main(String[] args) {
        TestRunner.run(XMLParsingDTDTest.class);
    }

    public XMLParsingDTDTest(String name) {
        super(name);
    }

    public void testDOM_notLoadDTD() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(LOAD_EXTERNAL_DTD_FEATURE, false);
            docBuilder = dbf.newDocumentBuilder();
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_dtd_http)));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
        try {
            Document document = docBuilder.parse(new File(_external_dtd_file));
        } catch (Exception e) {
            ignoreAccessRestriction("testDOMAccess_notLoadDTD", e, "should not throw error since dtd is not loaded", null);
        }
    }

    /**
     * return empty inputsource to skip DTD
     */
    public void xtestDOM_IgnoreDTD() {
        DocumentBuilderFactory dbf = null;
        DocumentBuilder docBuilder = null;
        try {
            dbf = DocumentBuilderFactory.newInstance();
            docBuilder = dbf.newDocumentBuilder();
            docBuilder.setEntityResolver(new EntityResolver() {
                @Override
                public InputSource resolveEntity(String publicId, String systemId)
                        throws SAXException, IOException {
                    //ignore DTD
                    return new InputSource(new StringReader(""));
                }
            });
        } catch (Exception e) {
        }

        try {
            Document document = docBuilder.parse(new InputSource(new StringReader(_external_entity_resolver)));
            checkDefaultBehavior(TEST_EXTERNALDTD, "testDOM_wEntityResolver_Default", PROTOCOL_HTTP);
        } catch (Exception e) {
            checkDefaultBehaviorExp(TEST_EXTERNALDTD, e, PROTOCOL_HTTP);
        }
    }

    public void xtest1() throws Exception {
        is_replacing_entity_references_test(true);
    }

    public void xtest2() throws Exception {
        is_replacing_entity_references_test(false);
    }

    public void xtest3() throws Exception {
        expand_entity_references_test(true);
    }

    public void xtest4() throws Exception {
        expand_entity_references_test(false);
    }

    static void is_replacing_entity_references_test(boolean is_replacing_entity_references) throws Exception {
        System.out.println("is_replacing_entity_references_test: IS_REPLACING_ENTITY_REFERENCES is " + Boolean.valueOf(is_replacing_entity_references));

        XMLInputFactory inputFactory = XMLInputFactory.newInstance();
        inputFactory.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, is_replacing_entity_references);
        Transformer transformer = TransformerFactory.newInstance().newTransformer();

        StringReader xmlReader = new StringReader(xml);

        XMLEventReader eventReader = inputFactory.createXMLEventReader(xmlReader);
        StAXSource source = new StAXSource(eventReader);
        DOMResult result = new DOMResult();

        transformer.transform(source, result);

        Node node = result.getNode();
        System.out.print("node (class:" + node.getClass().getName() + ") = " + nodeToString(node));

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.newDocument();
            doc.importNode(node, false);
            System.out.println("Import node succeed");
        } catch (Exception e) {
            System.out.println("Import node failed");
        }

        System.out.println();
    }

    static void expand_entity_references_test(boolean expand_entity_references) throws Exception {
        System.out.println("expand_entity_references_test(): " + Boolean.valueOf(expand_entity_references));

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(false);
        dbf.setExpandEntityReferences(expand_entity_references);
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new StringBufferInputStream(xml));

        System.out.println("doc = " + dumpDocument(doc));
        System.out.println();
    }

    static String nodeToString(Node node) throws Exception {
        StringWriter sw = new StringWriter();
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.transform(new DOMSource(node), new StreamResult(sw));
        return sw.toString();
    }

    static String dumpDocument(Document doc) throws Exception {
        StringWriter sw = new StringWriter();
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer trans = tf.newTransformer();
        trans.transform(new DOMSource(doc), new StreamResult(sw));
        return sw.toString();
    }
}
