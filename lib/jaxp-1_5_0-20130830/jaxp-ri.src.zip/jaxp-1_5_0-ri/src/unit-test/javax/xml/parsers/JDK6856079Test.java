package javax.xml.parsers;

/*
 * Testclass for Java 6 Parsing Problem of DTD's in Webstart
 */
import common.TestBase;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import junit.textui.TestRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class JDK6856079Test extends TestBase {

    protected final static String xmlEncoding = "ISO-8859-15";
    protected static Charset xmlEncodingCharset = null;

    String _xml;
    static {
        xmlEncodingCharset = Charset.forName(xmlEncoding);
    }
    
    public static void main(String[] args) {
        TestRunner.run(JDK6856079Test.class);
    }

    @Override
    protected void setUp() {
        super.setUp();
        String temp = JDK6856079Test.class.getResource("Templates.xml").getPath();
        _filepath = temp.substring(0, temp.lastIndexOf('/'));

        _xml = _filepath + "/Templates.xml";
    }

    public void test() {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            // Using factory get an instance of document builder
            DocumentBuilder db = dbf.newDocumentBuilder();

            // Create Classloader for using XML-File from JAR-Library
//            ClassLoader cl = JDK6856079Test.class.getClassLoader();
//            InputStream is = cl.getResourceAsStream( "Templates.xml" );
            InputStream is = new FileInputStream(_xml);
            //InputStream is = cl.getResourceAsStream( "xml/sample.xml" );

            db.setEntityResolver(new JarLoadingEntityResolver());
            // parse using builder to get DOM representation of the XML file
            // NOTE: Somwhere in Parsing the DTD of sample.xml occures an error

            InputStreamReader inReader = new InputStreamReader(is,
                    xmlEncodingCharset);

            System.out.println("### INFO: Start parsing ...");
            InputSource inputSource = new InputSource(inReader);
            inputSource.setSystemId(_xml);
            Document dom = db.parse(inputSource);//is );
            System.out.println("### INFO: Parsing successful!");
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (SAXException se) {
            se.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }
}
