/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.xml.stream.EntitiesTest;

import java.net.URL;
import java.io.*;
import javax.xml.stream.*;
import javax.xml.stream.events.* ;
import java.util.Date;
import junit.framework.TestCase;
import junit.textui.TestRunner;


/**
 * @author K.Venugopal@sun.com
 */

public class EntityTest extends TestCase {

    XMLInputFactory factory = null;
    String output="";

    public EntityTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(EntityTest.class);
    }

    protected void setUp() {
        try{
            factory = XMLInputFactory.newInstance();
        }catch(Exception ex){
            fail("Could not create XMLInputFactory");
        }
    }

    protected void tearDown() {
        factory = null;
    }

    public void testProperties() {
        assertTrue(factory.isPropertySupported("javax.xml.stream.isReplacingEntityReferences"));
    }

    public void testCharacterReferences() {
        try{
            URL fileName = EntityTest.class.getResource("testCharRef.xml");
            URL outputFileName = EntityTest.class.getResource("testCharRef.xml.output");
            XMLStreamReader xmlr = factory.createXMLStreamReader(new InputStreamReader(fileName.openStream()));
            int eventType = 0;
            while(xmlr.hasNext()){
                eventType = xmlr.next();
                handleEvent(xmlr,eventType);
            }
            System.out.println("Output:");
            System.out.println(output);
            assertTrue(compareOutput(new InputStreamReader(outputFileName.openStream()), new StringReader(output)));
        }catch(Exception ex){
            ex.printStackTrace();
            fail(ex.getMessage());
        }
    }

    private void handleEvent(XMLStreamReader xmlr , int eventType){
        switch (eventType){
            case XMLEvent.START_ELEMENT:
                handleStartElement(xmlr);
                break;
            case XMLEvent.END_ELEMENT:
                handleEndElement(xmlr);
                break;
            case XMLEvent.CHARACTERS:
                handleCharacters(xmlr);
                break;
            case XMLEvent.COMMENT:
                handleComment(xmlr);
                break;
            case XMLEvent.ENTITY_REFERENCE:
                break;
            case XMLEvent.ATTRIBUTE:
                break;
            case XMLEvent.DTD:
                break;
            case XMLEvent.CDATA:
                break;
            default :
                break;
        }
    }

    private void handleStartElement(XMLStreamReader xmlr){
        output+="<";
        output+=xmlr.getLocalName();
        if(xmlr.hasText())
            output+=xmlr.getText();
        printAttributes(xmlr);
        output+=">";
    }

    private void handleEndElement(XMLStreamReader xmlr){
        output+="</";
        output+=xmlr.getLocalName();
        output+=">";
    }

    private void handleComment(XMLStreamReader xmlr){
        if(xmlr.hasText())
            output+=xmlr.getText();
    }
    private void handleCharacters(XMLStreamReader xmlr){
        if(xmlr.hasText())
            output+=xmlr.getText();
    }
    private  void printAttributes(XMLStreamReader xmlr){
        if(xmlr.getAttributeCount() > 0){
            int count = xmlr.getAttributeCount() ;
            for(int i = 0 ; i < count ; i++) {
                output+=xmlr.getAttributeName(i);
                output+="=";
                output+=xmlr.getAttributeValue(i);
                /*String name = xmlr.getAttributeName(i) ;
                String value = xmlr.getAttributeValue(i) ;
                System.out.println(name+"="+value);*/
            }
        }
    }

    protected boolean compareOutput(Reader expected, Reader actual)
    throws IOException {
        LineNumberReader expectedOutput = new LineNumberReader(expected);
        LineNumberReader actualOutput = new LineNumberReader(actual);

        while (expectedOutput.ready() && actualOutput.ready()) {
            String expectedLine = expectedOutput.readLine();
            String actualLine = actualOutput.readLine();
            if (!expectedLine.equals(actualLine)) {
                System.out.println(
                "Entityreference expansion failed, line no: " + expectedOutput.getLineNumber());
                System.out.println("Expected: " + expectedLine);
                System.out.println("Actual  : " + actualLine);
                return false;
            }
        }
        expectedOutput.close();
        actualOutput.close();
        return true;
    }
}
