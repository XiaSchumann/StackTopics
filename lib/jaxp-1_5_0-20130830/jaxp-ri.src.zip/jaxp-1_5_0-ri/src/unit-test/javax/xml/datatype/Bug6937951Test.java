/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

// $Id: Bug6937951Test.java,v 1.2 2010-07-07 04:24:53 joehw Exp $
/*
 * Unit tests for {@link javax.xml.datatype.DatatypeFactory}.
 */
package javax.xml.datatype;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.xml.namespace.QName;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.datatype.Duration;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/*
 * used to generate millisecond values
 * import java.util.Calendar;
 * import java.util.GregorianCalendar;
 * import java.util.TimeZone;
 */

/**
 * Unit tests for CR6937951.
 *
 * @author huizhe.wang@oracle.com</a>
 */

public class Bug6937951Test extends TestCase {

    /**
     * @inheritDoc
     */
    public Bug6937951Test(String name) {
        super(name);
    }

    /**
     * @inheritDoc
     */
    public static void main(String[] args) {
        TestRunner.run(Bug6937951Test.class);
    }


    public void test() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        XMLGregorianCalendar c1 = dtf.newXMLGregorianCalendar("1999-12-31T24:00:00");
        XMLGregorianCalendar c2 = dtf.newXMLGregorianCalendar("2000-01-01T00:00:00");
        System.out.println("c1: " + c1.getYear()+ "-"+ c1.getMonth()+"-"+c1.getDay()+"T"+c1.getHour());
        System.out.println(c1.equals(c2) ? "pass" : "fail");  // fails
        if (!c1.equals(c2))
            fail("hour 24 needs to be treated as equal to hour 0 of the next day");
        if (c1.getYear() != 2000 && c1.getHour()!=0)
            fail("hour 24 needs to be treated as equal to hour 0 of the next day");

    }

}
