/*
 * bug6613059.java
 *
 * Created on Oct. 12, 2007
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javax.xml.stream.XMLEventReaderTest;

import javax.xml.stream.*;
import junit.framework.*;
import junit.textui.TestRunner;

import java.io.*;
import javax.xml.stream.events.*;
import javax.xml.namespace.QName;


/**
 *
 * @author joe.wang@sun.com
 */
public class Bug6613059Test extends TestCase {

    public static void main(String [] args){
        TestRunner.run(Bug6613059Test.class);
    }

    /** Creates a new instance of bug6539065 */
    public Bug6613059Test() {
    }

    public void test(){
        String xmlFile = "bug6613059.xml";
        XMLEventReader xer = null;
        XMLInputFactory xif = XMLInputFactory.newInstance();
        try {
            xer = xif.createXMLEventReader(xif.createXMLStreamReader(
                getClass().getResource(xmlFile).getFile(),
                getClass().getResourceAsStream(xmlFile)));
        } catch (XMLStreamException e) {
            System.out.println("Error while reading XML: " + e.getClass().getName() + " " + e.getMessage());
        }

        try {
            while (xer.hasNext()) {
                XMLEvent event = xer.nextTag();
                if (event.isEndElement() && event.asEndElement().getName().equals(new QName("menubar"))) {
                    break;
                }

                if (event.asStartElement().getName().equals(new QName("menu"))) {
                    //nextTag should be used when processing element-only content, assuming "addMenu" in
                    //the user's code handles the menu part properly
                    addMenu(xer, event);
                }

            }
        } catch (XMLStreamException e) {
            fail("Exception while reading " + xmlFile + ": " + e.getClass().getName() + " " + e.getMessage());
        }
    }

    void addMenu(XMLEventReader xer, XMLEvent event) throws XMLStreamException {
        //user did not submit this part of code, just jump to the end of menu element
        int eventType = 0;
        while (true) {
           event = xer.nextEvent();
           //System.out.println("event: " + event);
           eventType = event.getEventType();
           if (eventType == XMLStreamConstants.END_ELEMENT &&
                   event.asEndElement().getName().equals(new QName("menu"))) {
               break;
           }
        }
    }
}
