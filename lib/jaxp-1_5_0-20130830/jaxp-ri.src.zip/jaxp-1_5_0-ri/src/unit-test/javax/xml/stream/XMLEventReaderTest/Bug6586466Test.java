/*
 * bug6586466.java
 *
 * Created on Oct. 12, 2007
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javax.xml.stream.XMLEventReaderTest;

import javax.xml.stream.*;
import junit.framework.*;
import junit.textui.TestRunner;

import java.io.*;
import javax.xml.stream.events.*;
import javax.xml.namespace.QName;


/**
 * 6586466 XMLEventReaderImpl.nextTag() does not update fLastEvent
 * @author joe.wang@sun.com
 */
public class Bug6586466Test extends TestCase {

    public static void main(String [] args){
        TestRunner.run(Bug6586466Test.class);
    }

    /** Creates a new instance of bug6539065 */
    public Bug6586466Test() {
    }

    public void test(){
        String xmlData = "<?xml version=\"1.0\"?><Test>Hello</Test>";
        try {
            XMLEventReader xmlReader =
                    XMLInputFactory.newInstance().createXMLEventReader(
                            new ByteArrayInputStream(xmlData.getBytes()));

            XMLEvent event = xmlReader.nextEvent();
            System.out.println(event.getClass());

            // xmlReader.peek(); // error in both cases with/without peek()
            event = xmlReader.nextTag(); // nextEvent() would work fine
            // nextTag() forgets to set fLastEvent
            System.out.println(event.getClass());

            String text = xmlReader.getElementText();
            System.out.println(text);
        } catch (XMLStreamException e) {
            fail(e.getMessage());
        }
    }


}
