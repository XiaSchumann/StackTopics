/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package javax.xml.stream.XMLInputFactoryTest;

/**CR 8006974
 * XMLInputFactory.newInstance(String factoryId, ...) should fall back to a default implementation
 * @author huizhe.wang@oracle.com
 */


import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug8006974Test extends TestCase{

    /** Creates a new instance of Bug */
    public Bug8006974Test(String name) {
         super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug8006974Test.class);
    }

    private Bug8006974Test() {
        super("Bug8006974Test");
    }

    String Temp_Result = "";
    boolean PASSED = true;
    boolean FAILED = false;

    String XMLInputFactoryClassName = "com.sun.xml.internal.stream.XMLInputFactoryImpl";
    String XMLInputFactoryID = "javax.xml.stream.XMLInputFactory";
    static final String XMLEventFactoryID = "javax.xml.stream.XMLEventFactory";
    static final String XMLOutputFactoryID = "javax.xml.stream.XMLOutputFactory";
    ClassLoader CL = null;

    //these tests were original: jaxp-test jaxp-product-tests javax.xml.jaxp14.ptests.FactoryTest

    /* Note the following tests originally need to set System Property factoryId 
     * in order to find implementation. Because of this bug, these tests fail
     * if the system property is not specified. With this fix, the default
     * implementation shall be located.
     * 
     * Cases in XMLEventFactory (test37 and 39) and XMLOutputFactory are similar
     */
    
    /*
      test for XMLInputFactory.newInstance(java.lang.String factoryId, java.lang.ClassLoader classLoader)
      classloader is null and factoryId points to correct 
      implementation of javax.xml.stream.XMLInputFactory ,
      should return newInstance of XMLInputFactory
    */
    public void test29() {
        try{
            XMLInputFactory xif = XMLInputFactory.newInstance(XMLInputFactoryID, CL);
            if (xif instanceof XMLInputFactory){
                System.out.println(" test29() passed");
            }else{
                System.out.println(" test29() failed");
                fail("test29() failed: xif not an instance of XMLInputFactory ");
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            String err = "Failed : FactoryConfigurationError in test29 " + fce;
            System.out.println(err);
            fail(err);
        } catch(Exception e){
            String err = "Failed : Exception in test29 " + e;
            System.out.println(err);
            fail(err);
        }
    }
        
    /*
      test for XMLInputFactory.newInstance(java.lang.String factoryId, java.lang.ClassLoader classLoader)
      classloader is default(Class.getClassLoader()) and factoryId points to correct 
      implementation of javax.xml.stream.XMLInputFactory ,
      should return newInstance of XMLInputFactory
    */
    public void test31() {
        try{
            ClassLoader cl =Bug8006974Test.class.getClassLoader();
            XMLInputFactory xif = XMLInputFactory.newInstance(XMLInputFactoryID, cl);
            if (xif instanceof XMLInputFactory){
                System.out.println(" test31() passed");
            }else{
                fail("test31() failed: xif not an instance of XMLInputFactory ");
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            fail("Failed : FactoryConfigurationError in test31 " + fce);
        } catch(Exception e){
            fail("Failed : Exception in test31 " + e);
        }
    }    
    
    /*
      test for XMLOutputFactory.newInstance(java.lang.String factoryID, java.lang.ClassLoader classLoader)
      classloader is null and factoryClassName points to correct 
      implementation of javax.xml.stream.XMLOutputFactory ,
      should return newInstance of XMLOutputFactory
    */
    public void test33() {
        try{
            XMLOutputFactory xof = XMLOutputFactory.newFactory(XMLOutputFactoryID, CL);
            if (xof instanceof XMLOutputFactory){
                System.out.println(" test33() passed");
            }else{
                System.out.println(" test33() failed");
            }
        } catch(FactoryConfigurationError fce){
            fail("Failed : FactoryConfigurationError in test33 " + fce);
        } catch(Exception e){
            fail("Failed : Exception in test33 " + e);
        }
    }
   
      /*
      test for XMLOutputFactory.newInstance(java.lang.String factoryId, java.lang.ClassLoader classLoader)
      classloader is default(Class.getClassLoader()) and factoryId points to correct 
      implementation of javax.xml.datatype.DatatypeFactory ,
      should return newInstance of XMLOutputFactory
    */
    public void test35() {
        try{
            ClassLoader cl =Bug8006974Test.class.getClassLoader();
            XMLOutputFactory xof = XMLOutputFactory.newFactory(XMLOutputFactoryID, cl);
            if (xof instanceof XMLOutputFactory){
                System.out.println(" test35() passed");
            }else{
                System.out.println(" test35() failed");
            }
        } catch(FactoryConfigurationError fce){
            fail("Failed : FactoryConfigurationError in test35 " + fce);
        } catch(Exception e){
            fail("Failed : Exception in test35 " + e);
        }
    }
       
    /*
      test for XMLEventFactory.newInstance(java.lang.String factoryId, java.lang.ClassLoader classLoader)
      classloader is null and factoryId points to correct 
      implementation of javax.xml.stream.XMLEventFactory ,
      should return newInstance of XMLEventFactory
    */
    public void test37() {
        try{
            XMLEventFactory xef = XMLEventFactory.newInstance(XMLEventFactoryID, CL);
            if (xef instanceof XMLEventFactory){
                System.out.println(" test37() passed");
            }else{
                fail(" test37() failed");
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            fail("Failed : FactoryConfigurationError in test37 " + fce);
        } catch(Exception e){
            fail("Failed : Exception in test37 " + e);
        }
    }
     
      /*
      test for XMLEventFactory.newInstance(java.lang.String factoryId, java.lang.ClassLoader classLoader)
      classloader is default(Class.getClassLoader()) and factoryId points to correct 
      implementation of javax.xml.stream.XMLEventFactory ,
      should return newInstance of XMLEventFactory
    */
    public void test39() {
        try{
            ClassLoader cl =Bug8006974Test.class.getClassLoader();
            XMLEventFactory xef = XMLEventFactory.newInstance(XMLEventFactoryID, cl);
            if (xef instanceof XMLEventFactory){
                System.out.println(" test39() passed");
            }else{
                fail(" test39() failed");
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            fail("Failed : FactoryConfigurationError in test39 " + fce);
        } catch(Exception e){
            fail("Failed : Exception in test39 " + e);
        }
    }
    
    /**
     * Tests for StAX 1.2 newFactories
     */
    public void test29_newFactory() {
        try{
            XMLInputFactory xif = XMLInputFactory.newFactory(XMLInputFactoryID, CL);
            if (xif instanceof XMLInputFactory){
                System.out.println(" test29() passed");
            }else{
                System.out.println(" test29() failed");
                fail("test29() failed: xif not an instance of XMLInputFactory ");
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            String err = "Failed : FactoryConfigurationError in test29 " + fce;
            System.out.println(err);
            fail(err);
        } catch(Exception e){
            String err = "Failed : Exception in test29 " + e;
            System.out.println(err);
            fail(err);
        }
    }
    public void test31_Factory() {
        try{
            Bug8006974Test test3 = new Bug8006974Test();
            ClassLoader cl = (test3.getClass()).getClassLoader();
            XMLInputFactory xif = XMLInputFactory.newFactory(XMLInputFactoryID, cl);
            if (xif instanceof XMLInputFactory){
                System.out.println(" test31() passed");
            }else{
                fail("test31() failed: xif not an instance of XMLInputFactory ");
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            fail("Failed : FactoryConfigurationError in test31 " + fce);
        } catch(Exception e){
            fail("Failed : Exception in test31 " + e);
        }
    }
    
}
