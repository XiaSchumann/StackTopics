

package javax.xml.stream.XMLEventWriterTest;

import java.io.ByteArrayOutputStream;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.stax.StAXResult;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Test XMLEventWriter.
 *
 * @author Joe Wang
 */
public class JDK8010382Test extends TestCase {

    /**
     * Creates a new instance of XMLStreamWriterTest.
     *
     * @param name Name of test.
     */
    public JDK8010382Test(String name) {
        super(name);
    }

    /**
     * Command line invokation.
     *
     * @param args Standard args.
     */
    public static void main(String [] args) {
        TestRunner.run(JDK8010382Test.class);
    }

    /**
     * Test XMLStreamWriter parsing a file with an external entity reference.
     */
    public void testXMLStreamWriter() {
		try {
            XMLOutputFactory ofac = XMLOutputFactory.newInstance();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            //XMLStreamWriter swriter = ofac.createXMLStreamWriter(buffer);
            XMLStreamWriter swriter = ofac.createXMLStreamWriter(buffer, "UTF-8");
            StAXResult res = new StAXResult(swriter);
            XMLEventWriter writer = ofac.createXMLEventWriter(res);

            XMLEventFactory efac = XMLEventFactory.newInstance();
            writer.add(efac.createStartDocument());
//            writer.add(efac.createStartDocument(null,"1.0"));
            writer.add(efac.createStartElement("", "", "root"));
            writer.add(efac.createEndElement("", "", "root"));
            writer.add(efac.createEndDocument());
            writer.close();
            System.out.println(buffer.toString());
        } catch(Exception e) {
            e.printStackTrace();
        }

    }

}
