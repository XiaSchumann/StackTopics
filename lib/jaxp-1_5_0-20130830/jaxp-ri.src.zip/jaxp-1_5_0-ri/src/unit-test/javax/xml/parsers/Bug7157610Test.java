/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package javax.xml.parsers;

import java.io.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.ext.*;
import org.xml.sax.helpers.*;
import org.w3c.dom.*;


import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * 7157608: the standard-uri-conformant feature is not recognized.
 *
 *
 */
public class Bug7157610Test extends TestCase {
    static final String APACHE ="http://apache.org/xml/features/disallow-doctype-decl";
    static final String MSG = "DOCTYPE is disallowed when the feature \"http://apache.org/xml/features/disallow-doctype-decl\" set to true.";

    String xml1, xml2;
    
    public static void main(String[] args) {

        TestRunner.run(Bug7157610Test.class);
    }

    @Override
    protected void setUp() throws IOException {
        File file1 = new File(getClass().getResource("Bug7157610.xml").getFile());
        xml1 = file1.getPath();
    }
    public void testSAXParserFactory() {
        System.out.print("SAXParserFactory");
        try {
            boolean flag = true;
            
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setFeature(APACHE, flag);
            SAXParser sp = spf.newSAXParser();
            sp.parse(xml1, new DefaultHandler());
            fail("DoctypeNotAllowed not reported.");
        } catch (Exception e) {
            if (MSG.equals(e.getMessage())) {
                System.out.println(": OK");
            } else {
                fail("Error message should be DoctypeNotAllowed");
            }
        }
    }

    public void testXMLReader() {
        System.out.print("XMLReader");
        try {
            boolean flag = true;
            
            XMLReader reader = XMLReaderFactory.createXMLReader();
            reader.setErrorHandler(null);  //not to call ErrorHandler
            reader.setFeature(APACHE, flag);
            reader.parse(xml1);
            fail("DoctypeNotAllowed not reported.");
        } catch (Exception e) {
            if (MSG.equals(e.getMessage())) {
                System.out.println(": OK");
            } else {
                fail("Error message should be DoctypeNotAllowed");
            }
        }
    }

    public void testDocumentBuilderFactory() {
        System.out.print("DocumentBuilderFactory");
        try {
            boolean flag = true;
            
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(APACHE, flag);
            DocumentBuilder db = dbf.newDocumentBuilder();
            db.setErrorHandler(null);  //not to call ErrorHandler
            db.parse(xml1);
            fail("DoctypeNotAllowed not reported.");
        } catch (Exception e) {
            if (MSG.equals(e.getMessage())) {
                System.out.println(": OK");
            } else {
                fail("Error message should be DoctypeNotAllowed");
            }
        }
    }

}
