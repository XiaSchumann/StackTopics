package javax.xml.parsers;

import java.io.*;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * 8023652: DocumentBuilder parse failures can cause file handle leak
 */
public class JDK8023652Test extends TestCase {

    static String xml = "<?xml version='1.0' encoding='UTF-8' standalone='no'?>"
            + "<!DOCTYPE foo [ "
            + "<!ENTITY bar 'test' >"
            + "]>"
            + "<foo>&bar;</foo>";

    public static void main(String[] args) {
        TestRunner.run(JDK8023652Test.class);
    }

    public JDK8023652Test(String name) {
        super(name);
    }

    public void test() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true); // ??
        DocumentBuilder builder = factory.newDocumentBuilder();
        File fromThisFile = new File("JDK8023652Test.txt");
        fromThisFile.createNewFile();
        try {
            builder.parse(fromThisFile);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (!fromThisFile.delete()) {
                System.out.println("leaked a file handle ");
            } else {
                System.out.println(" no leak detected ");
            }
        }
    }
}
