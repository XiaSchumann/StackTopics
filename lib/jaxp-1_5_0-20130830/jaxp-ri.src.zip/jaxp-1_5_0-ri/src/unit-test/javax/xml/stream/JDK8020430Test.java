
package javax.xml.stream;

import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.StartDocument;
import javax.xml.stream.events.XMLEvent;
import java.io.*;
import javax.xml.transform.sax.SAXSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.InputSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author joe.wang@sun.com
 */
public class JDK8020430Test  extends TestCase{

    private static final XMLOutputFactory outputFactory =
        XMLOutputFactory.newInstance();
    private static final XMLInputFactory inputFactory =
        XMLInputFactory.newInstance();
    private static final int NO_THREADS = 3;

    public JDK8020430Test(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(JDK8020430Test.class);
    }

    public void test() {
        try {
            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            factory.setProperty(XMLOutputFactory.IS_REPAIRING_NAMESPACES, true); 
        } catch (NullPointerException e) {
            fail(e.getMessage());
        }
    }
    
    public void testSchemaFactory01() throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        InputSource is = new InputSource(JDK8020430Test.class.getResourceAsStream("test.xsd"));
        SAXSource ss = new SAXSource (is);
        Schema s = sf.newSchema(ss);
        assertNotNull(s);
    }

}
