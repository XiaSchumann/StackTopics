

package javax.xml.parsers;

import java.io.*;
import java.util.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.*;
import javax.xml.stream.*;
import javax.xml.transform.stax.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * from Artem Smotrakov <artem.smotrakov@oracle.com>
 * questions
 * I am trying to parse XML document that contain DTD using STaX and DOM. I wrote a test (please see attachment), there are four test cases:
1. STaX parser + enabled IS_REPLACING_ENTITY_REFERENCES
Result: the entity is replaced as defined in DTD
2. STaX parser + disabled IS_REPLACING_ENTITY_REFERENCES
Result: the entity is replaced by empty string
3. DOM parser + DocumentBuilderFactory.setExpandEntityReferences(true)
Result: the entity is replaced as defined in DTD
4. DOM parser + DocumentBuilderFactory.setExpandEntityReferences(false)
Result: the entity is replaced as defined in DTD

I have few questions:

1. Is it expected behavior that disabled IS_REPLACING_ENTITY_REFERENCES option causes just replacing entities with empty string?
* It is. But it did not "replace" it with an empty string literally.  The parser simply ignored the Entity reference.

2. Spec for DocumentBuilderFactory.setExpandEntityReferences(boolean expandEntityRef) method says "Specifies that the parser produced by this code will expand entity reference nodes". Is it expected that passing both true and false causes the same behavior (the entity is replaced as defined in DTD)
* The definition of  setExpandEntityReferences can be misleading. It's really to determine whether or not the parser would create EntityReference nodes in the DOM tree. It is not about "replacing" the entity reference or not.

3. Is there any way to turn off entity processing without just replacing it with empty string? 
* When using StAX, if you use the Event factory, you'd see that when IS_REPLACING_ENTITY_REFERENCES is false, there will be no Characters but only EntityReference event.

...
Node node = result.getNode();
System.out.print("node (class:" + node.getClass().getName() + ") = " + nodeToString(node));

try {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.newDocument();
        doc.importNode(node, false);
        System.out.println("Import node succeed");
    }
    catch(Exception e) {
        System.out.println("Import node failed");
    }
...

This fails always. Is it expected behavior? 
* 
* It is, because what you got was a Document node that could not be imported, see org.w3c.dom Document -> importNode:

DOCUMENT_NODE
    Document nodes cannot be imported. 
 */
public class XMLParsingTest extends TestCase {
    static String xml =    "<?xml version='1.0' encoding='UTF-8' standalone='no'?>" + 
                	    "<!DOCTYPE foo [ " + 
                            "<!ENTITY bar 'test' >" +
                            "]>" +
                            "<foo>&bar;</foo>";
    
    public static void main(String [] args){
        TestRunner.run(XMLParsingTest.class);
    }

    public XMLParsingTest(String name) {
        super(name);
    }

    public void xtest1() throws Exception {
	is_replacing_entity_references_test(true);
    }
    public void xtest2() throws Exception {
	is_replacing_entity_references_test(false);
    }    
    public void test3() throws Exception {
	expand_entity_references_test(true);
    }    
    public void test4() throws Exception {
	expand_entity_references_test(false);
    }    
    static void is_replacing_entity_references_test(boolean is_replacing_entity_references) throws Exception {
	System.out.println("is_replacing_entity_references_test: IS_REPLACING_ENTITY_REFERENCES is " + Boolean.valueOf(is_replacing_entity_references));
	
	XMLInputFactory inputFactory = XMLInputFactory.newInstance();
	inputFactory.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, is_replacing_entity_references);
	Transformer transformer = TransformerFactory.newInstance().newTransformer();

	StringReader xmlReader = new StringReader(xml);

	XMLEventReader eventReader = inputFactory.createXMLEventReader(xmlReader);
	StAXSource source = new StAXSource(eventReader);
	DOMResult result = new DOMResult();

	transformer.transform(source, result);

	Node node = result.getNode();
	System.out.print("node (class:" + node.getClass().getName() + ") = " + nodeToString(node));
	
	try {
	    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	    DocumentBuilder db = dbf.newDocumentBuilder();
	    Document doc = db.newDocument();
	    doc.importNode(node, false);
	    System.out.println("Import node succeed");
	}
	catch(Exception e) {
	    System.out.println("Import node failed");
	}
	
	System.out.println();
    }
    
    static void expand_entity_references_test(boolean expand_entity_references) throws Exception {
	System.out.println("expand_entity_references_test(): " + Boolean.valueOf(expand_entity_references));
	
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(false);
	dbf.setExpandEntityReferences(expand_entity_references);
	DocumentBuilder db = dbf.newDocumentBuilder();
	Document doc = db.parse(new StringBufferInputStream(xml));
	
	System.out.println("doc = " + dumpDocument(doc));
	System.out.println();
    }
    
    static String nodeToString(Node node) throws Exception {
	StringWriter sw = new StringWriter();
        Transformer t = TransformerFactory.newInstance().newTransformer();
	t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.transform(new DOMSource(node), new StreamResult(sw));
        return sw.toString();
    }
    
    static String dumpDocument(Document doc) throws Exception {
	StringWriter sw = new StringWriter();
	TransformerFactory tf = TransformerFactory.newInstance();
        Transformer trans = tf.newTransformer();
        trans.transform(new DOMSource(doc), new StreamResult(sw));
        return sw.toString();
    }
}
