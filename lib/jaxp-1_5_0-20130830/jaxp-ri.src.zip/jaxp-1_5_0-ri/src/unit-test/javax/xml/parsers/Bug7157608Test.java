/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package javax.xml.parsers;

import java.io.IOException;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * 7157608: the standard-uri-conformant feature is not recognized.
 *
 *
 */
public class Bug7157608Test extends TestCase {
    public static boolean isWindows = false;
    static {
        if (System.getProperty("os.name").indexOf("Windows")>-1) {
            isWindows = true;
        }
    };
    
    String xml1, xml2;
    
    public static void main(String[] args) {
            TestRunner.run(Bug7157608Test.class);
    }

    
    @Override
    protected void setUp() throws IOException {
        File file1 = new File(getClass().getResource("Bug7157608.xml").getFile());
        xml1 = file1.getPath().replace("\\", "\\\\");
        File file2 = new File(getClass().getResource("Bug7157608_1.xml").getFile());
        xml2 = file2.getPath();
    }
    // case 1
    // standard-uri-confomant is false
    // dtd-validation is false
    public void test1() {
        if (isWindows) {
            try {
                ParserSettings ps = new ParserSettings();

                DocumentBuilder db = getDocumentBuilder(ps);
                InputSource is = new InputSource();
                is.setSystemId(xml1);
                Document doc = db.parse(is);
                System.out.println("test1() :OK");
            } catch (Exception e) {
                fail("test1() :NG");

            }
        }
    }

    // case 2
    // standard-uri-confomant is false
    // dtd-validation is true
    public void test2() {
        if (isWindows) {
            try {
                ParserSettings ps = new ParserSettings();
                ps.validating = true;

                DocumentBuilder db = getDocumentBuilder(ps);
                InputSource is = new InputSource(xml2);
                Document doc = db.parse(is);
                System.out.println("test2() :OK");
            } catch (Exception e) {
                fail("test2() :NG");
    //            logger.info(e.getMessage());
            }
        }
    }

    // case 3
    // standard-uri-confomant is true
    public void test3() {
        if (isWindows) {
            try {
                ParserSettings ps = new ParserSettings();
                ps.standardUriConformant=true;

                DocumentBuilder db = getDocumentBuilder(ps);
                InputSource is = new InputSource();
                is.setSystemId(xml1);
                Document doc = db.parse(is);
                fail("test3() :NG");
            } catch (IOException e) {
                String returnedErr = e.getMessage();
                String expectedStr ="Opaque part contains invalid character";

                if (returnedErr.indexOf(expectedStr)>=0) {
                    System.out.println("test3() :OK");
                } else {
                    fail("test3() :NG");
                }
            }catch(Exception e){
                System.out.println("test3() :NG");
            }
        }
    }

    // case 4
    // standard-uri-confomant is true
    // dtd-validation is true
    public void test4() {
        if (isWindows) {
            try {
                ParserSettings ps = new ParserSettings();
                ps.standardUriConformant = true;
                ps.validating = true;

                DocumentBuilder db = getDocumentBuilder(ps);
                InputSource is = new InputSource(xml2);
                Document doc = db.parse(is);
                fail("test4() :NG");
            } catch (IOException e) {
                String returnedErr = e.getMessage();
                String expectedStr ="Opaque part contains invalid character";

                if (returnedErr.indexOf(expectedStr)>=0) {
                    System.out.println("test3() :OK");
                } else {
                    fail("test3() :NG");
                }
            }catch(Exception e){
                fail("test4() :NG");
            }
        }
    }

    public DocumentBuilder getDocumentBuilder(ParserSettings ps){
        DocumentBuilder db=null;
        try{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            if(ps.standardUriConformant){
                dbf.setFeature("http://apache.org/xml/features/standard-uri-conformant", true);
            }
            dbf.setValidating(ps.validating);
            db = dbf.newDocumentBuilder();
            db.setErrorHandler(new MyHandler());
        }catch(Exception e){
            fail("standard-uri-conformant not recognized");
        }
        return db;
    }

    class MyHandler extends  DefaultHandler {
        @Override
        public void warning(SAXParseException e) throws SAXException {
            printDetail("**Warning**", e);
        }

        @Override
        public void error(SAXParseException e) throws SAXException {
            printDetail("**Error**", e);
            throw new SAXException("Error encountered");
        }

        @Override
        public void fatalError(SAXParseException e) throws SAXException {
            printDetail("**Fatal Error**", e);
            throw new SAXException("Fatal Error encountered");
        }

        public void printDetail(String msg, SAXParseException e) {
            System.out.println(msg);
            System.out.println(e.getMessage());
            System.out.println("  Line:    " + e.getLineNumber());
            System.out.println("  Column:  " + e.getColumnNumber());
            System.out.println("  URI:     " + e.getSystemId());
        }

    }
    class ParserSettings{
        boolean standardUriConformant = false;
        boolean validating = false;
    }
}
