/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * $Id: XMLEventWriterTest.java,v 1.4 2007-07-19 04:35:39 ofung Exp $
 * %W% %E%
 */

package javax.xml.stream.XMLEventWriterTest;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.events.XMLEvent;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.xml.XMLConstants;

/**
 * Test XMLEventWriter.
 *
 * @author <a href="mailtoJeff.Suttor@Sun.com>Jeff Suttor</a>, cribbed from CR 6245284 user provided test case.
 */
public class XMLEventWriterTest extends TestCase {

    /**
     * Creates a new instance of XMLStreamWriterTest.
     *
     * @param name Name of test.
     */
    public XMLEventWriterTest(String name) {
        super(name);
    }

    /**
     * Command line invokation.
     *
     * @param args Standard args.
     */
    public static void main(String [] args) {
        TestRunner.run(XMLEventWriterTest.class);
    }

    /**
     * Test XMLStreamWriter parsing a file with an external entity reference.
     */
    public void testXMLStreamWriter() {

        try {
            XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();
            XMLEventWriter eventWriter =
                    outputFactory.createXMLEventWriter(System.out);
            XMLInputFactory inputFactory = XMLInputFactory.newInstance();
            inputFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");
            File file = new File(XMLEventWriterTest.class.getResource(
                            "XMLEventWriterTest.xml").toURI());
            FileInputStream inputStream = new FileInputStream(file);
            XMLEventReader eventReader =
                    inputFactory.createXMLEventReader(inputStream);

            //adds the event to the consumer.
            eventWriter.add(eventReader);
            eventWriter.flush();
            eventWriter.close();

            // expected success
        } catch (Exception exception) {
            exception.printStackTrace();
            fail(exception.toString());
        }
    }

    /**
     * Inspired by CR 6245284 Sun Stax /sjsxp.jar does not behave properly
     * during merge of xml files.
     */
    public void testMerge() {

        try {
            // Create the XML input factory
            XMLInputFactory factory = XMLInputFactory.newInstance();

            // Create XML event reader 1
            InputStream inputStream1 = new FileInputStream(
                    new File(XMLEventWriterTest.class.getResource(
                        "merge-1.xml").toURI()));
            XMLEventReader r1 = factory.createXMLEventReader(inputStream1);

            // Create XML event reader 2
            InputStream inputStream2 = new FileInputStream(
                    new File(XMLEventWriterTest.class.getResource(
                        "merge-2.xml").toURI()));
            XMLEventReader r2 = factory.createXMLEventReader(inputStream2);

            // Create the output factory
            XMLOutputFactory xmlof = XMLOutputFactory.newInstance();

            // Create XML event writer
            XMLEventWriter xmlw = xmlof.createXMLEventWriter(System.out);

            // Read to first <product> element in document 1
            // and output to result document
            QName bName = new QName("b");

            while (r1.hasNext()) {
                // Read event to be written to result document
                XMLEvent event = r1.nextEvent();

                if (event.getEventType() == XMLEvent.END_ELEMENT) {

                    // Start element - stop at <product> element
                    QName name = event.asEndElement().getName();
                    if (name.equals(bName)) {

                        QName zName = new QName("z");

                        boolean isZr = false;

                        while (r2.hasNext()) {
                            // Read event to be written to result document
                            XMLEvent event2 = r2.nextEvent();
                            // Output event
                            if (event2.getEventType() == XMLEvent.START_ELEMENT
                                    && event2.asStartElement().getName().equals(zName)) {
                                isZr = true;
                            }

                            if (xmlw != null && isZr) {
                                xmlw.add(event2);
                            }

                            // stop adding events after </z>
                            // i.e. do not write END_DOCUMENT :)
                            if (isZr
                                    && event2.getEventType() == XMLEvent.END_ELEMENT
                                    && event2.asEndElement().getName().equals(zName)) {
                                isZr = false;
                            }
                        }
                        xmlw.flush();
                    }
                }

                // Output event
                if (xmlw != null) {
                    xmlw.add(event);
                }
            }

            // Read to first <product> element in document 1
            // without writing to result document
            xmlw.close();

            // expected success
        } catch (Exception ex) {
            ex.printStackTrace();
            fail(ex.toString());
        }
    }
}
