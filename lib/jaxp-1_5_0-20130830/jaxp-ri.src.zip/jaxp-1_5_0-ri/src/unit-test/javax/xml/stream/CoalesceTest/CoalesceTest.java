/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * TestCoalesce.java
 *
 * Created on April 27, 2004, 3:30 PM
 */

package javax.xml.stream.CoalesceTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author  nb131165
 */
public class CoalesceTest extends TestCase {

    String countryElementContent =  "START India  CS}}}}}} India END" ;
    String descriptionElementContent =  "a&b" ;
    String fooElementContent = "&< cdatastart<><>>><>><<<<cdataend entitystart insert entityend";

    /** Creates a new instance of TestCoalesce */
    public CoalesceTest(String name) {
        super(name);
    }

    public void testCoalesceProperty(){
        try{
            XMLInputFactory xifactory = XMLInputFactory.newInstance() ;
            xifactory.setProperty(XMLInputFactory.IS_COALESCING, new Boolean(true)) ;
            File file = new File("./tests/Coalesce/coalesce.xml") ;
            InputStream xml = new FileInputStream(file);
            XMLStreamReader streamReader = xifactory.createXMLStreamReader(xml);
            while(streamReader.hasNext()){
                int eventType = streamReader.next() ;
                if(eventType == XMLStreamConstants.START_ELEMENT && streamReader.getLocalName().equals("country")){
                    eventType = streamReader.next() ;
                    if(eventType == XMLStreamConstants.CHARACTERS){
                        String text = streamReader.getText() ;
                        if(!text.equals(countryElementContent)){
                            System.out.println("String dont match");
                            System.out.println("text = " + text ) ;
                            System.out.println("countryElementContent = " + countryElementContent);
                        }
                        //assertTrue(text.equals(countryElementContent));
                    }
                }
                if(eventType == XMLStreamConstants.START_ELEMENT && streamReader.getLocalName().equals("description")){
                    eventType = streamReader.next() ;
                    if(eventType == XMLStreamConstants.CHARACTERS){
                        String text = streamReader.getText() ;
                        if(!text.equals(descriptionElementContent)){
                            System.out.println("String dont match");
                            System.out.println("text = " + text ) ;
                            System.out.println("descriptionElementContent = " + descriptionElementContent);
                        }
                        assertTrue(text.equals(descriptionElementContent));
                    }
                }
                if(eventType == XMLStreamConstants.START_ELEMENT && streamReader.getLocalName().equals("foo")){
                    eventType = streamReader.next() ;
                    if(eventType == XMLStreamConstants.CHARACTERS){
                        String text = streamReader.getText() ;
                        if(!text.equals(fooElementContent)){
                            System.out.println("String dont match");
                            System.out.println("text = " + text ) ;
                            System.out.println("fooElementContent = " + fooElementContent);
                        }

                        assertTrue(text.equals(fooElementContent));
                    }
                }

            }
        }
        catch(XMLStreamException ex){

            if( ex.getNestedException() != null){
                ex.getNestedException().printStackTrace();
            }
            //ex.printStackTrace() ;
        }
        catch(Exception ex){
            ex.printStackTrace() ;
        }

    }

    public static void main(String [] args){
        TestRunner.run(CoalesceTest.class);
    }
}
