/*
 * bug6586466.java
 *
 * Created on Oct. 12, 2007
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javax.xml.stream.XMLEventReaderTest;

import javax.xml.stream.*;
import junit.framework.*;
import junit.textui.TestRunner;

import java.io.*;
import javax.xml.XMLConstants;
import javax.xml.stream.events.*;
import javax.xml.namespace.QName;


/**
 * 6846133 StAX XMLEventReader DTD issues
 * @author joe.wang@sun.com
 */
public class Bug6846133Test extends TestCase {
    private static final String xml = "<!DOCTYPE html PUBLIC \"-//W3C//DTDXHTML 1.0 Transitional//EN\" "
                                      + "\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
                                      + "<html><body><p>I am some simple html</p></body> </html>";

    public static void main(String [] args){
        TestRunner.run(Bug6846133Test.class);
    }

    /** Creates a new instance of bug6846133 */
    public Bug6846133Test() {
    }

    public void test() {
        try {
            javax.xml.stream.XMLInputFactory factory = javax.xml.stream.XMLInputFactory.newInstance ();
            factory.setXMLResolver (new DTDResolver ());
            factory.setProperty (javax.xml.stream.XMLInputFactory.SUPPORT_DTD, true);
            factory.setProperty (javax.xml.stream.XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES  , true);
            factory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "http");
            java.io.ByteArrayInputStream is = new java.io.ByteArrayInputStream(xml.getBytes ("UTF-8"));

            //createXMLEventReader (source) not supported
            //javax.xml.transform.stream.StreamSource source = new javax.xml.transform.stream.StreamSource (is);
            //javax.xml.stream.XMLEventReader reader = factory.createXMLEventReader (source);

            javax.xml.stream.XMLEventReader reader = factory.createXMLEventReader (is);
            while (reader.hasNext ()) {
                javax.xml.stream.events.XMLEvent event = reader.nextEvent ();
                if (event.getEventType () == javax.xml.stream.XMLStreamConstants.DTD) {
                    String temp = ((javax.xml.stream.events.DTD) event).getDocumentTypeDeclaration();
                    if (temp.length() < 120) {
                        fail("DTD truncated");
                    }
                    System.out.println(temp);
                }
            }
        } catch (XMLStreamException xe) {
            fail(xe.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class DTDResolver implements javax.xml.stream.XMLResolver {
        public Object resolveEntity (String arg0, String arg1, String arg2, String arg3) throws XMLStreamException
        {
            System.out.println ("DTD is parsed");
            return new java.io.ByteArrayInputStream (new byte[0]);
        }
    }

}
