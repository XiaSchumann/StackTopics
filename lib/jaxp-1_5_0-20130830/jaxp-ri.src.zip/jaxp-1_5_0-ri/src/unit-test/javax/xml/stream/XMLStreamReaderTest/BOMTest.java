/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


/*

 * $Id: BOMTest.java,v 1.3 2008-02-19 06:46:37 joehw Exp $
 * %W% %E%

 */



package javax.xml.stream.XMLStreamReaderTest;

/**
 * This test case was initiated by CR 6218794 (Support for Byte Order Mark)
 *
 * @author Jeff Suttor
 * @author Ana Lindstrom-Tamer
 */

import java.io.*;

import java.util.Iterator;
import javax.xml.stream.*;
import javax.xml.stream.events.*;
import junit.framework.TestCase;
import junit.textui.TestRunner;

public class BOMTest extends TestCase {
    // UTF-8 BOM test file
    private static final String INPUT_FILE1 = "UTF8-BOM.xml";
    // UTF-16 Big Endian test file
    private static final String INPUT_FILE2 = "UTF16-BE.wsdl";
    /** Creates a new instance of Bug */
    public BOMTest(String name) {
     super(name);
    }
    public static void main(String[] args) {
        TestRunner.run(BOMTest.class);
    }

    public void testBOM(){
        XMLInputFactory ifac = XMLInputFactory.newInstance();
        try{
            XMLStreamReader re = ifac.createXMLStreamReader(this.getClass().getResource(INPUT_FILE1).toExternalForm(),this.getClass().getResourceAsStream(INPUT_FILE1));
            while (re.hasNext()){
                int event = re.next();
            }
            XMLStreamReader re2 = ifac.createXMLStreamReader(this.getClass().getResource(INPUT_FILE2).toExternalForm(),this.getClass().getResourceAsStream(INPUT_FILE2));
            while (re2.hasNext()){

                int event = re2.next();

            }
        } catch(Exception e) {
            e.printStackTrace();
            fail("Exception occured: " + e.getMessage());
        }
    }
}
