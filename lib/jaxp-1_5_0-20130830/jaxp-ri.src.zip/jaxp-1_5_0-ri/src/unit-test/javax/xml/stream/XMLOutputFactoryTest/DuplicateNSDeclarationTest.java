/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
/*
 * $Id: DuplicateNSDeclarationTest.java,v 1.2 2007-07-19 04:35:39 ofung Exp $
 * %W% %E%
 */

package javax.xml.stream.XMLOutputFactoryTest;

import java.io.*;

import javax.xml.stream.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.stax.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Test the writing of duplicate namespace declarations.
 *
 * Inspired by SJSXP
 * <a href="https://sjsxp.dev.java.net/issues/show_bug.cgi?id=13">Issue # 13</a>.
 *
 * @author <a href="Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */

public class DuplicateNSDeclarationTest extends TestCase {

    public DuplicateNSDeclarationTest(String name) {
        super(name);
    }

    public static void main(String [] args) {
        TestRunner.run(DuplicateNSDeclarationTest.class);
    }

    public void testDuplicateNSDeclaration() {

        // expect only 1 Namespace Declaration
        final String EXPECTED_OUTPUT =
                "<?xml version=\"1.0\" ?>"
                + "<ns1:foo"
                + " xmlns:ns1=\"http://example.com/\">"
                + "</ns1:foo>";

        // have XMLOutputFactory repair Namespaces
        XMLOutputFactory ofac = XMLOutputFactory.newInstance();
        ofac.setProperty(
                XMLOutputFactory.IS_REPAIRING_NAMESPACES,
                new Boolean(true));

        // send output to a Stream
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        StreamResult sr = new StreamResult(buffer);
        XMLStreamWriter w = null;

        //write a duplicate Namespace Declaration
        try {
            w = ofac.createXMLStreamWriter(sr);
            w.writeStartDocument();
            w.writeStartElement("ns1","foo","http://example.com/");
            w.writeNamespace("ns1","http://example.com/");
            w.writeNamespace("ns1","http://example.com/");
            w.writeEndElement();
            w.writeEndDocument();
            w.close();
        } catch (XMLStreamException xmlStreamException) {
            xmlStreamException.printStackTrace();
            fail(xmlStreamException.toString());
        }

        // debugging output for humans
        System.out.println();
        System.out.println("actual:   \"" + buffer.toString() + "\"");
        System.out.println("expected: \"" + EXPECTED_OUTPUT + "\"");

        // are results as expected?
        assertEquals(EXPECTED_OUTPUT, buffer.toString());
    }
}
