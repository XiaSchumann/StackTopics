/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
/*
 * $Id: StreamResultTest.java,v 1.2 2007-07-19 04:35:39 ofung Exp $
 * %W% %E%
 */

package javax.xml.stream.XMLOutputFactoryTest;

import java.io.*;

import javax.xml.stream.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.stax.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy, Sun Microsystems
 */

public class StreamResultTest extends TestCase{

    public StreamResultTest(String name) {
        super(name);
    }

    public static void main(String [] args) {
        TestRunner.run(StreamResultTest.class);
    }

    public void testStreamResult() {
        final String EXPECTED_OUTPUT = "<?xml version=\"1.0\"?><root></root>";
        try {
            XMLOutputFactory ofac = XMLOutputFactory.newInstance();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            StreamResult sr = new StreamResult(buffer);
            XMLStreamWriter writer = ofac.createXMLStreamWriter(sr);
            writer.writeStartDocument("1.0");
            writer.writeStartElement("root");
            writer.writeEndElement();
            writer.writeEndDocument();
            writer.close();
            assertEquals(buffer.toString(), EXPECTED_OUTPUT);
        } catch(Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }
    }

    public void testStreamWriterWithStAXResultNStreamWriter() {
        final String EXPECTED_OUTPUT = "<?xml version=\"1.0\"?><root></root>";

        try{
            XMLOutputFactory ofac = XMLOutputFactory.newInstance();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            XMLStreamWriter writer = ofac.createXMLStreamWriter(buffer);
            StAXResult res = new StAXResult(writer);
            writer = ofac.createXMLStreamWriter(res);
            writer.writeStartDocument("1.0");
            writer.writeStartElement("root");
            writer.writeEndElement();
            writer.writeEndDocument();
            writer.close();
            assertEquals(buffer.toString(), EXPECTED_OUTPUT);
        } catch(Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }
    }

    public void testEventWriterWithStAXResultNStreamWriter() {
        final String EXPECTED_OUTPUT = "<?xml version=\"1.0\"?><root></root>";
        try {
            XMLOutputFactory ofac = XMLOutputFactory.newInstance();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            XMLStreamWriter swriter = ofac.createXMLStreamWriter(buffer);
            StAXResult res = new StAXResult(swriter);
            XMLEventWriter writer = ofac.createXMLEventWriter(res);

            XMLEventFactory efac = XMLEventFactory.newInstance();
            writer.add(efac.createStartDocument(null,"1.0"));
            writer.add(efac.createStartElement("", "", "root"));
            writer.add(efac.createEndElement("", "", "root"));
            writer.add(efac.createEndDocument());
            writer.close();

            assertEquals(buffer.toString(), EXPECTED_OUTPUT);
        } catch(Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }
    }

    public void testEventWriterWithStAXResultNEventWriter() {
        final String EXPECTED_OUTPUT = "<?xml version=\"1.0\"?><root></root>";

        try{
            XMLOutputFactory ofac = XMLOutputFactory.newInstance();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            XMLEventWriter writer = ofac.createXMLEventWriter(buffer);
            StAXResult res = new StAXResult(writer);
            writer = ofac.createXMLEventWriter(res);

            XMLEventFactory efac = XMLEventFactory.newInstance();
            writer.add(efac.createStartDocument(null,"1.0"));
            writer.add(efac.createStartElement("", "", "root"));
            writer.add(efac.createEndElement("", "", "root"));
            writer.add(efac.createEndDocument());
            writer.close();

            assertEquals(buffer.toString(), EXPECTED_OUTPUT);
        } catch(Exception e) {
            e.printStackTrace();
            fail(e.toString());
        }
    }

    public void testStreamWriterWithStAXResultNEventWriter() throws Exception{
        try{
            XMLOutputFactory ofac = XMLOutputFactory.newInstance();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            XMLEventWriter writer = ofac.createXMLEventWriter(buffer);
            StAXResult res = new StAXResult(writer);
            XMLStreamWriter swriter = ofac.createXMLStreamWriter(res);
            fail("Expected an Exception as XMLStreamWriter can't be created " +
                    "with a StAXResult which has EventWriter.");
        } catch(Exception e) {
            System.out.println(e.toString());
        }
    }
}
