/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


package javax.xml.stream.Events;

import java.io.File;
import java.io.StringReader;
import java.util.*;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.*;
import javax.xml.stream.events.*;

import junit.framework.TestCase;
import junit.framework.Assert;
import junit.textui.TestRunner;

import java.io.FileWriter;

/**
 * 6620632 / sjsxp issue 48: DTD event is missing entity and notation information
 *
 * @author Joe.Wang@sun.com
 */
public class Issue48Test extends TestCase {

    public java.io.File input;
    public final String filesDir = "./";
    protected XMLInputFactory inputFactory;
    protected XMLOutputFactory outputFactory;

    public static void main(String [] args) {
        TestRunner.run(Issue48Test.class);
    }

    /**
     * DTDEvent instances constructed via event reader are missing the notation and
     * entity declaration information
     */
    public void testDTDEvent() {
        String XML = "<?xml version='1.0' ?>"
        +"<!DOCTYPE root [\n"
        +"<!ENTITY intEnt 'internal'>\n"
        +"<!ENTITY extParsedEnt SYSTEM 'url:dummy'>\n"
        +"<!NOTATION notation PUBLIC 'notation-public-id'>\n"
        +"<!NOTATION notation2 SYSTEM 'url:dummy'>\n"
        +"<!ENTITY extUnparsedEnt SYSTEM 'url:dummy2' NDATA notation>\n"
        +"]>"
        +"<root />";

        try {
            XMLEventReader er = getReader(XML);
            XMLEvent evt = er.nextEvent();  //StartDocument
            evt = er.nextEvent();           //DTD
            if (evt.getEventType() != XMLStreamConstants.DTD) {
                fail("Expected DTD event");
            }
            DTD dtd = (DTD) evt;
            List entities = dtd.getEntities();
            if (entities == null) {
                fail("No entity found. Expected 3.");
            } else {
                Assert.assertEquals(entities.size(), 3);
            }
            // Let's also verify they are all of right type...
            testListElems(entities, EntityDeclaration.class);

            List notations = dtd.getNotations();
            if (notations == null) {
                fail("No notation found. Expected 2.");
            } else {
                Assert.assertEquals(notations.size(), 2);
            }
            // Let's also verify they are all of right type...
            testListElems(notations, NotationDeclaration.class);
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }


    private XMLEventReader getReader(String XML)
        throws Exception
    {
            inputFactory = XMLInputFactory.newInstance();

            // Check if event reader returns the correct event
            XMLEventReader er = inputFactory.createXMLEventReader(new StringReader(XML));
         return er;
    }
    private void testListElems(List l, Class expType)
    {
        Iterator it = l.iterator();
        while (it.hasNext()) {
            Object o = it.next();
            assertNotNull(o);
            assertTrue(expType.isAssignableFrom(o.getClass()));
        }
    }

}
