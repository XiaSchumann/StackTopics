/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.xml.stream;

import common.SimplePolicy;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Properties;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import java.io.*;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.security.Policy;
import java.security.ProtectionDomain;
import java.util.PropertyPermission;

/**
 * @author  Santiago.PericasGeertsen@sun.com
 * 
 * needs to be able to run both regularly and with a security manager
 * @author huizhe.wang@oracle.com
 */
public class FactoryFindTest extends TestCase {

    boolean myClassLoaderUsed = false;

    final static String FACTORY_KEY = "javax.xml.stream.XMLInputFactory";
    private boolean hasSM;
    private Policy _orig;
    private String _curdir;
    private String _configFile;

    public FactoryFindTest(String name) {
        super(name);
    }

    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }

        _configFile = System.getProperty("java.home") +
                File.separator + "lib" + File.separator + "stax.properties";
                
        File curdir = new File(".");
        _curdir = curdir.getAbsolutePath();
        _curdir = _curdir.substring(0, _curdir.length()-1);
        _orig = Policy.getPolicy();
        Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                new RuntimePermission("setContextClassLoader"),
                new RuntimePermission("createClassLoader"),
                new FilePermission(_configFile, "read,write,delete"),
                new FilePermission(_curdir + "/-", "read,write,delete"),
                new PropertyPermission(FACTORY_KEY, "read")
                );
        Policy.setPolicy(p);
        if (hasSM) {
            //let's run this with SM
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }
    
    public void testFactoryFindUsingStaxProperties() {
        // If property is defined, will take precendence so this test
        // is ignored :(
        if (System.getProperty(FACTORY_KEY) != null) {
            return;
        }

        Properties props = new Properties();

        File f = new File(_configFile);
        if (f.exists()) {
            try {
                FileInputStream fis = new FileInputStream(f);
                props.load(fis);
                fis.close();
            }
            catch (FileNotFoundException e) {
                return;
            }
            catch (IOException e) {
                return;
            }
        }
        else {
            props.setProperty(FACTORY_KEY,
                "com.sun.xml.internal.stream.XMLInputFactoryImpl");
            try {
                FileOutputStream fos = new FileOutputStream(f);
                props.store(fos, null);
                fos.close();
                f.deleteOnExit();
            }
            catch (FileNotFoundException e) {
                return;
            }
            catch (IOException e) {
                return;
            }
        }

        XMLInputFactory factory = XMLInputFactory.newInstance();
        assertTrue(factory.getClass().getName().equals(props.getProperty(FACTORY_KEY)));
    }

    public void testFactoryFind(){
        if (!hasSM) {
            try {
                // System.setProperty("jaxp.debug", "true");

                XMLInputFactory factory = XMLInputFactory.newInstance();
                assertTrue(factory.getClass().getClassLoader() == null);

                Thread.currentThread().setContextClassLoader(null);
                factory = XMLInputFactory.newInstance();
                assertTrue(factory.getClass().getClassLoader() == null);

                Thread.currentThread().setContextClassLoader(new MyClassLoader());
                factory = XMLInputFactory.newInstance();
                assertTrue(myClassLoaderUsed);

                XMLOutputFactory ofactory = XMLOutputFactory.newInstance();
                assertTrue(ofactory.getClass().getClassLoader() == null);

                Thread.currentThread().setContextClassLoader(null);
                ofactory = XMLOutputFactory.newInstance();
                assertTrue(ofactory.getClass().getClassLoader() == null);

                Thread.currentThread().setContextClassLoader(new MyClassLoader());
                ofactory = XMLOutputFactory.newInstance();
                assertTrue(myClassLoaderUsed);
            }
            catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    public static void main(String [] args){
        TestRunner.run(FactoryFindTest.class);
    }

    class MyClassLoader extends URLClassLoader {

        public MyClassLoader() {
            super(new URL[0]);
        }

        public Class loadClass(String name) throws ClassNotFoundException {
            myClassLoaderUsed = true;
            return super.loadClass(name);
        }
    }    
}
