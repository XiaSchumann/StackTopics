/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.xml.stream.XMLStreamReaderTest;

import junit.framework.TestCase;

import java.io.StringReader;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;


import junit.textui.TestRunner;
/**
 * See bug 6389307.
 *
 * @author Kohsuke Kawaguchi
 */
public class DoubleXmlnsTest extends TestCase {

    public static void main(String[] args) {
        TestRunner.run(DoubleXmlnsTest.class);
    }

    public void testDoubleNS() throws Exception {

        final String INVALID_XML =
                "<foo xmlns:xmli='http://www.w3.org/XML/1998/namespacei' xmlns:xmli='http://www.w3.org/XML/1998/namespacei' />";

        try {
            XMLStreamReader xsr = XMLInputFactory.newInstance().createXMLStreamReader(
                    new StringReader(INVALID_XML));

            while(xsr.hasNext()) {
                xsr.next();
            }

            fail("Wellformedness error expected: "
                    + INVALID_XML);
        } catch (XMLStreamException e) {
            ; // this is expected
        }
    }

    public void testNestedNS() throws Exception {

        final String VALID_XML =
                "<foo xmlns:xmli='http://www.w3.org/XML/1998/namespacei'><bar xmlns:xmli='http://www.w3.org/XML/1998/namespaceii'></bar></foo>";

        try {
            XMLStreamReader xsr = XMLInputFactory.newInstance().createXMLStreamReader(
                    new StringReader(VALID_XML));

            while(xsr.hasNext()) {
                xsr.next();
            }

            // expected success
        } catch (XMLStreamException e) {
            e.printStackTrace();

            fail("Wellformedness error is not expected: "
                    + VALID_XML
                    + ", "
                    + e.getMessage());
        }
    }

    public void testDoubleXmlns() throws Exception {

        final String INVALID_XML =
                "<foo xmlns:xml='http://www.w3.org/XML/1998/namespace' xmlns:xml='http://www.w3.org/XML/1998/namespace' ></foo>";

        try {
            XMLStreamReader xsr = XMLInputFactory.newInstance().createXMLStreamReader(
                    new StringReader(INVALID_XML));

            while(xsr.hasNext()) {
                xsr.next();
            }

            fail("Wellformedness error expected :"
                    + INVALID_XML);
        } catch (XMLStreamException e) {
            ; // this is expected
        }
    }

    public void testNestedXmlns() throws Exception {

        final String VALID_XML =
                "<foo xmlns:xml='http://www.w3.org/XML/1998/namespace'><bar xmlns:xml='http://www.w3.org/XML/1998/namespace'></bar></foo>";

        try {
            XMLStreamReader xsr = XMLInputFactory.newInstance().createXMLStreamReader(
                    new StringReader(VALID_XML));

            while(xsr.hasNext()) {
                xsr.next();
            }

            // expected success
        } catch (XMLStreamException e) {
            e.printStackTrace();
           fail("Wellformedness error is not expected: "
                   + VALID_XML
                   + ", "
                   + e.getMessage());
        }
    }
}
