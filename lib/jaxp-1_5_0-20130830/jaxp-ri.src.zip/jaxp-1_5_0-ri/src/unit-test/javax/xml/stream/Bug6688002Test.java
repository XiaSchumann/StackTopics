
package javax.xml.stream;

import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.StartDocument;
import javax.xml.stream.events.XMLEvent;
import java.io.*;

import org.xml.sax.InputSource;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author joe.wang@sun.com
 */
public class Bug6688002Test  extends TestCase{

    private static final XMLOutputFactory outputFactory =
        XMLOutputFactory.newInstance();
    private static final XMLInputFactory inputFactory =
        XMLInputFactory.newInstance();
    private static final int NO_THREADS = 3;

    public Bug6688002Test(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug6688002Test.class);
    }

    public void testMultiThread()
    throws Exception{
        Thread[] threads = new Thread[NO_THREADS];
        for(int i=0; i < NO_THREADS; i++) {
            threads[i] = new Thread(new MyRunnable(i));
        }
        for(int i=0; i < NO_THREADS; i++) {
            threads[i].start();
        }
        for(int i=0; i < NO_THREADS; i++) {
            threads[i].join();
        }
    }
    public class MyRunnable implements Runnable {
        final int no;

        MyRunnable(int no) {
            this.no = no;
        }

        public void run() {
                try {
                     FileOutputStream fos = new FileOutputStream(""+no);
                     XMLStreamWriter w = getWriter(fos);
                     //System.out.println("Writer="+w+" Thread="+Thread.currentThread());
                     w.writeStartDocument();
                     w.writeStartElement("hello");
                     for(int j=0; j < 50; j++) {
                         w.writeStartElement("a"+j);
                         w.writeEndElement();
                     }
                     w.writeEndElement();
                     w.writeEndDocument();
                     w.close();
                     fos.close();

                     FileInputStream fis = new FileInputStream(""+no);
                     XMLStreamReader r = getReader(fis);
                     while(r.hasNext()) {
                         r.next();
                     }
                     r.close();
                     fis.close();
                } catch(Exception e) {
                     fail(e.getMessage());
                }
        }
    }

    public static /* synchronized */ XMLStreamReader getReader(InputStream is)
        throws Exception {
        return inputFactory.createXMLStreamReader(is);
        //return XMLStreamReaderFactory.create(null, is, true);
    }

    public static /* synchronized */ XMLStreamWriter getWriter(OutputStream os)
        throws Exception {
        return outputFactory.createXMLStreamWriter(os);
        //return XMLStreamWriterFactory.createXMLStreamWriter(os);
    }


}
