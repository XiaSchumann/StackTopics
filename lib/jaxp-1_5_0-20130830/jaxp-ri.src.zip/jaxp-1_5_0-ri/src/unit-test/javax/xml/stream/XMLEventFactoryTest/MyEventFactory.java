/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.xml.stream.XMLEventFactoryTest;

import java.util.Iterator;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.stream.Location;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.Comment;
import javax.xml.stream.events.DTD;
import javax.xml.stream.events.EndDocument;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.EntityDeclaration;
import javax.xml.stream.events.EntityReference;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.ProcessingInstruction;
import javax.xml.stream.events.StartDocument;
import javax.xml.stream.events.StartElement;

/**CR 7191547
 * [StAX] XMLEventFactory.newFactory(String factoryId, ClassLoader loader) does not work as expected
 * @author huizhe.wang@oracle.com
 */



public class MyEventFactory extends javax.xml.stream.XMLEventFactory {

    @Override
    public void setLocation(Location location) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Attribute createAttribute(String prefix, String namespaceURI, String localName, String value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Attribute createAttribute(String localName, String value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Attribute createAttribute(QName name, String value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Namespace createNamespace(String namespaceURI) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Namespace createNamespace(String prefix, String namespaceUri) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public StartElement createStartElement(QName name, Iterator attributes, Iterator namespaces) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public StartElement createStartElement(String prefix, String namespaceUri, String localName) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public StartElement createStartElement(String prefix, String namespaceUri, String localName, Iterator attributes, Iterator namespaces) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public StartElement createStartElement(String prefix, String namespaceUri, String localName, Iterator attributes, Iterator namespaces, NamespaceContext context) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public EndElement createEndElement(QName name, Iterator namespaces) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public EndElement createEndElement(String prefix, String namespaceUri, String localName) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public EndElement createEndElement(String prefix, String namespaceUri, String localName, Iterator namespaces) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Characters createCharacters(String content) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Characters createCData(String content) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Characters createSpace(String content) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Characters createIgnorableSpace(String content) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public StartDocument createStartDocument() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public StartDocument createStartDocument(String encoding, String version, boolean standalone) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public StartDocument createStartDocument(String encoding, String version) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public StartDocument createStartDocument(String encoding) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public EndDocument createEndDocument() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public EntityReference createEntityReference(String name, EntityDeclaration declaration) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Comment createComment(String text) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ProcessingInstruction createProcessingInstruction(String target, String data) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public DTD createDTD(String dtd) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
