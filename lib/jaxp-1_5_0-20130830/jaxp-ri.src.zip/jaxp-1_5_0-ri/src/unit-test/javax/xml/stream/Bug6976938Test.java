
package javax.xml.stream;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import javax.xml.namespace.QName;

import javax.xml.stream.EventFilter;
import javax.xml.stream.XMLEventReader;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author joe.wang@sun.com
 */
public class Bug6976938Test  extends TestCase{
    /**
     * File with very long text.
     */
    private static final String INPUT_FILE = "Bug6976938.xml";

    /**
     * Namespace for the Vodafone Generic Trouble Ticketing schema.
     */
    public static final String VF_GENERIC_TT_NAMESPACE = "http://www.vodafone.com/oss/xml/TroubleTicket";

    /**
     * QName for the "attachment" element.
     */
    public static final QName ATTACHMENT_NAME = new QName(VF_GENERIC_TT_NAMESPACE, "attachment");


    public Bug6976938Test(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug6976938Test.class);
    }

    public void testEventReader() {
        XMLInputFactory xif = XMLInputFactory.newInstance();
        xif.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
        eventReaderTest(xif);
    }

    public void testEventReader1() {
        XMLInputFactory xif = XMLInputFactory.newInstance();
        eventReaderTest(xif);
    }

    public void eventReaderTest(XMLInputFactory xif) {
        XMLEventReader eventReader = null;
        try {
            eventReader = xif.createXMLEventReader(this.getClass().getResourceAsStream(INPUT_FILE));
            XMLEventReader filteredEventReader = xif.createFilteredReader(eventReader, new EventFilter() {
                public boolean accept(XMLEvent event) {
                    if (!event.isStartElement()) {
                        return false;
                    }
                    QName elementQName = event.asStartElement().getName();
                    if ((elementQName.getLocalPart().equals(ATTACHMENT_NAME.getLocalPart()) || elementQName.getLocalPart().equals("Attachment"))
                            && elementQName.getNamespaceURI().equals(VF_GENERIC_TT_NAMESPACE)) {
                        return true;
                    }
                    return false;
                }
            });
            if (filteredEventReader.hasNext()) {
                System.out.println("containsAttachments() returns true");
            }
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());

        } finally {
            if (eventReader != null) {
                try {
                    eventReader.close();
                } catch (XMLStreamException xse) {
                    // Ignored by intention
                }
            }
        }
    }

}
