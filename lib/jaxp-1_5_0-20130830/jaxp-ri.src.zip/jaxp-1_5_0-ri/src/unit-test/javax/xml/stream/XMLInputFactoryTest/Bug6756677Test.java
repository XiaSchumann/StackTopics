/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.xml.stream.XMLInputFactoryTest;

/**CR 6756677
 * [StAX] XMLInputFactory.newInstance(String factoryId, ...) treats property name as a property value
 * @author huizhe.wang@oracle.com
 */

import common.SimplePolicy;
import java.security.Policy;
import java.util.PropertyPermission;
import javax.xml.stream.XMLInputFactory;
import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug6756677Test extends TestCase{
    String Temp_Result = "";
    boolean PASSED = true;
    boolean FAILED = false;

    String XMLInputFactoryClassName = "com.sun.xml.internal.stream.XMLInputFactoryImpl";
    String XMLInputFactoryID = "javax.xml.stream.XMLInputFactory";
    String MYFACTORYID = "MyInputFactory";
    ClassLoader CL = null;

    private boolean hasSM;
    private Policy _orig;

    /** Creates a new instance of Bug */
    public Bug6756677Test(String name) {
         super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug6756677Test.class);
    }

    private Bug6756677Test() {
        super("Bug6756677Test");
    }
    
    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }
        _orig = Policy.getPolicy();
        
        if (hasSM) {
            Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new PropertyPermission(XMLInputFactoryID, "write"),
                    new PropertyPermission(MYFACTORYID, "write"));
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void testNewInstance() {
        String myFactory ="javax.xml.stream.XMLInputFactoryTest.MyInputFactory";
        try {
            System.setProperty(MYFACTORYID, myFactory);
            XMLInputFactory xif = XMLInputFactory.newInstance("MyInputFactory", null);
            System.out.println(xif.getClass().getName());
            assertTrue(xif.getClass().getName().equals(myFactory));

        }
        catch (UnsupportedOperationException oe) {
            fail(oe.getMessage());
            oe.printStackTrace();
        }

    }
    //newFactory was added in StAX 1.2
    public void testNewFactory() {
        String myFactory ="javax.xml.stream.XMLInputFactoryTest.MyInputFactory";
        ClassLoader cl = null;
        try {
            System.setProperty(MYFACTORYID, myFactory);
            XMLInputFactory xif = XMLInputFactory.newFactory("MyInputFactory", cl);
            System.out.println(xif.getClass().getName());
            assertTrue(xif.getClass().getName().equals(myFactory));

        }
        catch (UnsupportedOperationException oe) {
            fail(oe.getMessage());
        }

    }

    //jaxp-test jaxp-product-tests javax.xml.jaxp14.ptests.FactoryTest
    public void test() {
        if (!test29()) {
            fail(Temp_Result);
        }
        if (!test31()) {
            fail(Temp_Result);
        }
    }

    /*
      test for XMLInputFactory.newInstance(java.lang.String factoryId, java.lang.ClassLoader classLoader)
      classloader is null and factoryId points to correct 
      implementation of javax.xml.stream.XMLInputFactory ,
      should return newInstance of XMLInputFactory
    */
    public boolean test29() {
        System.setProperty(XMLInputFactoryID, "com.sun.xml.internal.stream.XMLInputFactoryImpl");
        try{
            XMLInputFactory xif = XMLInputFactory.newInstance(XMLInputFactoryID, CL);
            if (xif instanceof XMLInputFactory){
                System.out.println(" test29() passed");
                return PASSED;
            }else{
                System.out.println(" test29() failed");
                Temp_Result = "test29() failed: xif not an instance of XMLInputFactory ";
                return FAILED;
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            System.out.println("Failed : FactoryConfigurationError in test29 " + fce);
            Temp_Result = "test29() failed ";
            return FAILED;
        } catch(Exception e){
            System.out.println("Failed : Exception in test29 " + e);
            Temp_Result = "test29() failed ";
            return FAILED;
        }
    }
      /*
      test for XMLInputFactory.newInstance(java.lang.String factoryId, java.lang.ClassLoader classLoader)
      classloader is default(Class.getClassLoader()) and factoryId points to correct 
      implementation of javax.xml.stream.XMLInputFactory ,
      should return newInstance of XMLInputFactory
    */
    public boolean test31() {
        System.setProperty(XMLInputFactoryID, "com.sun.xml.internal.stream.XMLInputFactoryImpl");
        try{
            Bug6756677Test test3 = new Bug6756677Test();
            ClassLoader cl = (test3.getClass()).getClassLoader();
            XMLInputFactory xif = XMLInputFactory.newInstance(XMLInputFactoryID, cl);
            if (xif instanceof XMLInputFactory){
                System.out.println(" test31() passed");
                return PASSED;
            }else{
                System.out.println(" test31() failed");
                Temp_Result = "test31() failed: xif not an instance of XMLInputFactory ";
                return FAILED;
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            System.out.println("Failed : FactoryConfigurationError in test31 " + fce);
            Temp_Result = "test31() failed ";
            return FAILED;
        } catch(Exception e){
            System.out.println("Failed : Exception in test31 " + e);
            Temp_Result = "test31() failed ";
            return FAILED;
        }
    }
}
