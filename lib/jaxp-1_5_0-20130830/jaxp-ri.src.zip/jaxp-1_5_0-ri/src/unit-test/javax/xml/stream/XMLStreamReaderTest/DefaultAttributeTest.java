/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * DefaultAttributeTest.java
 *
 * Created on May 3, 2006, 6:15 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package javax.xml.stream.XMLStreamReaderTest;

/**
 *
 * @author Sunitha Reddy
 */
import java.io.*;
import java.util.Iterator;
import javax.xml.XMLConstants;
import javax.xml.stream.*;
import javax.xml.stream.events.*;

import junit.framework.TestCase;
import junit.textui.TestRunner;

public class DefaultAttributeTest extends TestCase{

    private static final String INPUT_FILE = "ExternalDTD.xml";

    /** Creates a new instance of Bug */
    public DefaultAttributeTest(String name) {
         super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(DefaultAttributeTest.class);
    }

    public void testStreamReader(){
        XMLInputFactory ifac = XMLInputFactory.newInstance();
        XMLOutputFactory ofac = XMLOutputFactory.newInstance();


        try{
            ifac.setProperty(ifac.IS_REPLACING_ENTITY_REFERENCES, new Boolean(false));
            ifac.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");
            XMLStreamReader re = ifac.createXMLStreamReader(this.getClass().getResource(INPUT_FILE).toExternalForm(),this.getClass().getResourceAsStream(INPUT_FILE));

            while (re.hasNext()){
                int event = re.next();
                if (event == XMLStreamConstants.START_ELEMENT && re.getLocalName().equals("bookurn")){
                        assertTrue("No attributes are expected for <bookurn> ",re.getAttributeCount() == 0);
                        assertTrue("Two namespaces are expected for <bookurn> ",re.getNamespaceCount() == 2);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        }
    }

    public void testEventReader(){
        try{
            XMLInputFactory ifac = XMLInputFactory.newInstance();
            ifac.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");
            XMLEventReader read = ifac.createXMLEventReader(this.getClass().getResource(INPUT_FILE).toExternalForm(),this.getClass().getResourceAsStream(INPUT_FILE));
            while (read.hasNext()){
                XMLEvent event = read.nextEvent();
                if (event.isStartElement()){
                    StartElement startElement = event.asStartElement();
                    if (startElement.getName().getLocalPart().equals("bookurn")){
                        Iterator iterator = startElement.getNamespaces();
                        int count = 0;
                        while(iterator.hasNext()){
                           iterator.next();
                            count ++;
                        }
                        assertTrue("Two namespaces are expected for <bookurn> ", count == 2);

                        Iterator attributes = startElement.getAttributes();
                        count = 0;
                        while(attributes.hasNext()){
                            iterator.next();
                            count ++;
                        }
                        assertTrue("Zero attributes are expected for <bookurn> ", count == 0);
                    }}
            }
        }catch(Exception e){
            e.printStackTrace();
            fail("Exception occured: "+e.getMessage());
        }
    }
}
