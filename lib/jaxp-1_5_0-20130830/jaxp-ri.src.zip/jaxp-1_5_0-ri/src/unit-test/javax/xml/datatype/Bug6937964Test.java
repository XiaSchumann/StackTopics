/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

// $Id: Bug6937964Test.java,v 1.2 2010-05-19 23:20:07 joehw Exp $
/*
 * Unit tests for {@link javax.xml.datatype.DatatypeFactory}.
 */
package javax.xml.datatype;


import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.datatype.Duration;
import javax.xml.namespace.QName;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/*
 * used to generate millisecond values
 * import java.util.Calendar;
 * import java.util.GregorianCalendar;
 * import java.util.TimeZone;
 */

/**
 * Unit tests for CR6937951.
 *
 * @author huizhe.wang@oracle.com</a>
 */

public class Bug6937964Test extends TestCase {
    /**
     * Print debugging to System.err.
     */
    private static final boolean DEBUG = false;
    /**
     * Constant to indicate expected lexical test failure.
     */
    private static final String TEST_VALUE_FAIL = "*FAIL*";

    private static final String FIELD_UNDEFINED = "FIELD_UNDEFINED";
    static final DatatypeConstants.Field [] fields = {
        DatatypeConstants.YEARS,
        DatatypeConstants.MONTHS,
        DatatypeConstants.DAYS,
        DatatypeConstants.HOURS,
        DatatypeConstants.MINUTES,
        DatatypeConstants.SECONDS
    };
    /**
     * @inheritDoc
     */
    public Bug6937964Test(String name) {
        super(name);
    }

    /**
     * @inheritDoc
     */
    public static void main(String[] args) {
        TestRunner.run(Bug6937964Test.class);
    }


    public void test() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        Duration d = dtf.newDurationYearMonth("P20Y15M");
        int years = d.getYears();
        System.out.println(d.getYears()==21 ? "pass" : "fail");
    }

    public void testNewDurationYearMonthLexicalRepresentation() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        Duration d = dtf.newDurationYearMonth("P20Y15M");
        int years = d.getYears();
        assertTrue("Return value should be normalized", years==21);
    }
    public void testNewDurationYearMonthMilliseconds() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        Duration d = dtf.newDurationYearMonth(671976000000L);
        int years = d.getYears();
        System.out.println("Years: " + years);
        assertTrue("Return value should be normalized", years==21);
    }
    public void testNewDurationYearMonthBigInteger() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        BigInteger year = new BigInteger("20");
        BigInteger mon = new BigInteger("15");
        Duration d = dtf.newDurationYearMonth(true, year, mon);
        int years = d.getYears();
        assertTrue("Return value should be normalized", years==21);
    }
    public void testNewDurationYearMonthInt() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        Duration d = dtf.newDurationYearMonth(true, 20, 15);
        int years = d.getYears();
        assertTrue("Return value should be normalized", years==21);
    }

    public void testNewDurationDayTimeLexicalRepresentation() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        Duration d = dtf.newDurationDayTime("P1DT23H59M65S");
        int days = d.getDays();
        assertTrue("Return value should be normalized", days==2);
    }
    public void testNewDurationDayTimeMilliseconds() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        Duration d = dtf.newDurationDayTime(172805000L);
        int days = d.getDays();
        assertTrue("Return value should be normalized", days==2);
    }
    public void testNewDurationDayTimeBigInteger() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        BigInteger day = new BigInteger("1");
        BigInteger hour = new BigInteger("23");
        BigInteger min = new BigInteger("59");
        BigInteger sec = new BigInteger("65");
        Duration d = dtf.newDurationDayTime(true, day, hour, min, sec);
        int days = d.getDays();
        System.out.println("Days: " + days);
        assertTrue("Return value should be normalized", days==2);
    }
    public void testNewDurationDayTimeInt() throws DatatypeConfigurationException {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        Duration d = dtf.newDurationDayTime(true, 1, 23, 59, 65);
        int days = d.getDays();
        System.out.println("Days: " + days);
        assertTrue("Return value should be normalized", days==2);
    }

    /**
     * Exception above cases that test the originally reported scenarios, we also
     * need to pass the following edge cases
     */
    /**
     * Test {@link
     * DatatypeFactory.newDurationYearMonth(String lexicalRepresentation)}.
     *
     */
    public final void testNewDurationYearMonthLexicalRepresentation1() {

        /**
         * Lexical test values to test.
         */
        final String[] TEST_VALUES_LEXICAL = {
                "P13M",      "P1Y1M",
                "-P13M",     "-P1Y1M",
                "P1Y",      "P1Y",
                "-P1Y",     "-P1Y",
                "P1Y25M",    "P3Y1M",
                "-P1Y25M",   "-P3Y1M"
        };

        DatatypeFactory datatypeFactory = null;
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException
                datatypeConfigurationException) {
            fail(datatypeConfigurationException.toString());
        }

        if (DEBUG) {
            System.err.println("DatatypeFactory created: "
                    + datatypeFactory.toString());
        }

        // test each value
        for (int onTestValue = 0;
            onTestValue < TEST_VALUES_LEXICAL.length;
            onTestValue = onTestValue + 2) {

            if (DEBUG) {
                System.err.println("testing value: \""
                        + TEST_VALUES_LEXICAL[onTestValue]
                        + "\", expecting: \""
                        + TEST_VALUES_LEXICAL[onTestValue + 1] + "\"");
            }

            try {
                Duration duration =
                    datatypeFactory.newDurationYearMonth(
                            TEST_VALUES_LEXICAL[onTestValue]);

                if (DEBUG) {
                    System.err.println("Duration created: \""
                            + duration.toString() + "\"");
                }

                // was this expected to fail?
                if (TEST_VALUES_LEXICAL[onTestValue + 1]
                                        .equals(TEST_VALUE_FAIL)) {
                    fail("the value \""
                            + TEST_VALUES_LEXICAL[onTestValue]
                            + "\" is invalid yet it created the Duration \""
                            + duration.toString() + "\"");
                }

                // right XMLSchemaType?
                // TODO: enable test, it should pass, it fails with Exception(s) for now due to a bug
                try {
                    QName xmlSchemaType = duration.getXMLSchemaType();
                    if (!xmlSchemaType.equals(DatatypeConstants.DURATION_YEARMONTH)) {
                        fail("Duration created with XMLSchemaType of\""
                                + xmlSchemaType
                                + "\" was expected to be \""
                                + DatatypeConstants.DURATION_YEARMONTH
                                + "\" and has the value \""
                                + duration.toString() + "\"");
                    }
                } catch (IllegalStateException illegalStateException) {
                    // TODO; this test really should pass
                    System.err.println("Please fix this bug that is being ignored, for now: " + illegalStateException.getMessage());
                }

                // does it have the right value?
                if (!TEST_VALUES_LEXICAL[onTestValue + 1]
                                         .equals(duration.toString())) {
                    fail("Duration created with \""
                            + TEST_VALUES_LEXICAL[onTestValue]
                            + "\" was expected to be \""
                            + TEST_VALUES_LEXICAL[onTestValue + 1]
                            + "\" and has the value \""
                            + duration.toString() + "\"");
                }

                // Duration created with correct value
            } catch (Exception exception) {

                if (DEBUG) {
                    System.err.println("Exception in creating duration: \""
                            + exception.toString() + "\"");
                }

                // was this expected to succed?
                if (!TEST_VALUES_LEXICAL[onTestValue + 1]
                                         .equals(TEST_VALUE_FAIL)) {
                    fail("the value \""
                            + TEST_VALUES_LEXICAL[onTestValue]
                            + "\" is valid yet it failed with \""
                            + exception.toString() + "\"");
                }
                // expected failure
            }
        }
    }

    /**
     * TCK test failure
     */
    public void testNewDurationDayTime005() {
        BigInteger one = new BigInteger("1");
        BigInteger zero = new BigInteger("0");
        BigDecimal bdZero = new BigDecimal("0");
        BigDecimal bdOne = new BigDecimal("1");

        Object [][] values = {
            // lex, isPositive, years, month, days, hours, minutes, seconds
            {"P1D", Boolean.TRUE, null, null, one, zero, zero, bdZero},
            {"PT1H", Boolean.TRUE, null, null, zero, one, zero, bdZero},
            {"PT1M", Boolean.TRUE,  null, null, zero, zero, one, bdZero},
            {"PT1.1S", Boolean.TRUE, null, null, zero, zero, zero, bdOne},
            {"-PT1H1.1S", Boolean.FALSE, null, null, zero, one, zero, bdOne},
        };

        StringBuffer result = new StringBuffer();
        DatatypeFactory df = null;

        try {
            df = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            fail(e.toString());
        }

        for (int valueIndex = 0; valueIndex < values.length; ++valueIndex) {
            Duration duration = null;
            try {
                duration = df.newDurationDayTime(values[valueIndex][1].equals(Boolean.TRUE)
                    ,((BigInteger)values[valueIndex][4]).intValue()
                    ,((BigInteger)values[valueIndex][5]).intValue()
                    ,((BigInteger)values[valueIndex][6]).intValue()
                    ,((BigDecimal)values[valueIndex][7]).intValue());
            } catch (IllegalArgumentException e) {
                result.append("; unexpected " + e
                            + " trying to create duration \'" + values[valueIndex][0] + "\'");
            }
            if (duration != null) {
                if ((duration.getSign()==1) != values[valueIndex][1].equals(Boolean.TRUE)) {
                    result.append("; " + values[valueIndex][0]
                                + ": wrong sign " + duration.getSign()
                                + ", expected " + values[valueIndex][1]);
                }
                for (int i = 0; i < fields.length; ++i) {
                    Number value = duration.getField(fields[i]);
                    if ((value != null && values[valueIndex][2+i] == null)
                     || (value == null && values[valueIndex][2+i] != null)
                     || (value!=null && !value.equals(values[valueIndex][2+i]))) {
                        result.append("; " + values[valueIndex][0]
                                    + ": wrong value of the field "
                                    + fields[i] + ": \'" + value + "\'"
                                    + ", expected \'" + values[valueIndex][2+i] + "\'");
                    }
                }
            }
        }

        if (result.length() >0) {
            fail(result.substring(2));
        }
        System.out.println("OK");

    }
}
