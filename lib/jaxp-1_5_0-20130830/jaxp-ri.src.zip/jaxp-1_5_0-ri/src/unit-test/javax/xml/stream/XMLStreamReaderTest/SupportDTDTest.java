/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * StreamReader.java
 *
 * Created on February 28, 2007, 3:40 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javax.xml.stream.XMLStreamReaderTest;

import java.io.StringReader;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import javax.xml.stream.XMLEventReader;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.*;
import javax.xml.stream.events.Characters;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * SUPPORT_DTD behavior:
 * Regardless of supportDTD, always report a DTD event () and throw an
 * exception if an entity reference is found when supportDTD is false
 *
 * The behavior is related to property IS_REPLACING_ENTITY_REFERENCES.
 *
 * SUPPORT_DTD      Replace Entity   DTD                    ENTITY_REFERENCE
 * true (default)   true (default)   yes, has entities      no, return Characters
 * true (default)   false            yes, has entities      yes, can print entity name
 * false            true (default)   yes, but no entity     Exception: Undeclared general entity
 * false            false            yes, but no entity     yes, can print entity name
 *
 * Two patches related:
 * sjsxp issue 9: XMLDocumentScannerImpl.java rev 1.6
 * If the supportDTD property is set to FALSE, external and internal subsets
 * are now ignored, rather than an error being reported. In particular, with
 * this property set to FALSE, no error is reported if an external subset cannot
 * be found. Note that the internal subset is still parsed (and errors could be
 * reported here) but no events are returned by the parser. This fixes SJSXP
 * issue 9 from Java.net.
 * Note: SAX and DOM report fatal errors:
 *       If either SAX or DOM is used, turning on http://apache.org/xml/features/disallow-doctype-decl [1] effectively disables DTD,
 *       according to the spec: A fatal error is thrown if the incoming document contains a DOCTYPE declaration.
 *       The current jaxp implementation actually throws a nullpointexception. A better error message could be used.
 *
 * This change is required by CR 6542088.
 * @author joe.wang@sun.com
 */
public class SupportDTDTest  extends TestCase {
    final boolean DEBUG = true;
    final String _file = "./tests/XMLStreamReader/ExternalDTD.xml";
    final String XML = "<?xml version='1.0' ?>"
            +"<!DOCTYPE root [\n"
            +"<!ENTITY intEnt 'internal entity'>\n"
            +"<!ENTITY extParsedEnt SYSTEM 'url:dummy'>\n"
            +"<!NOTATION notation PUBLIC 'notation-public-id'>\n"
            +"<!NOTATION notation2 SYSTEM 'url:dummy'>\n"
            +"<!ENTITY extUnparsedEnt SYSTEM 'url:dummy2' NDATA notation>\n"
            +"]>"
            +"<root>&intEnt;</root>";
    final String XML1 = "<?xml version='1.0' encoding ='utf-8'?>"
            +"<!DOCTYPE document SYSTEM \"tests/XMLStreamReader/ExternalDTD.dtd\">"
            +"<document>"
            +       "<name>&mkm;</name>"
            +"</document>";

    final int ENTITY_INTERNAL_ONLY = 1;
    final int ENTITY_EXTERNAL_ONLY = 2;
    final int ENTITY_BOTH = 3;

    boolean _DTDReturned = false;
    boolean _EntityEventReturned = false;
    boolean _hasEntityDelaration = false;
    boolean _exceptionThrown = false;
    /** Creates a new instance of StreamReader */
    public SupportDTDTest(String name) {
        super(name);
    }
    void reset() {
        _DTDReturned = false;
        _EntityEventReturned = false;
        _hasEntityDelaration = false;
        _exceptionThrown = false;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestRunner.run(SupportDTDTest.class);
    }

    //tests 1-4 test internal entities only
    public void test1() {
        supportDTD(true, true, ENTITY_INTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(true, _hasEntityDelaration);
        assertEquals(false, _EntityEventReturned);
    }
    public void test2() {
        supportDTD(true, false, ENTITY_INTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(true, _hasEntityDelaration);
        assertEquals(true, _EntityEventReturned);
    }
    public void test3() {
        supportDTD(false, true, ENTITY_INTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(false, _hasEntityDelaration);
        assertEquals(true, _exceptionThrown);
    }
    public void test4() {
        supportDTD(false, false, ENTITY_INTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(false, _hasEntityDelaration);
        assertEquals(true, _EntityEventReturned);
    }
    //tests 5-8 test external entities only
    public void test5() {
        System.setProperty("javax.xml.accessExternalDTD", "any");
        supportDTD(true, true, ENTITY_EXTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(true, _hasEntityDelaration);
        assertEquals(false, _EntityEventReturned);
    }
    public void test6() {
        supportDTD(true, false, ENTITY_EXTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(true, _hasEntityDelaration);
        assertEquals(true, _EntityEventReturned);
    }
    public void test7() {
        supportDTD(false, true, ENTITY_EXTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(false, _hasEntityDelaration);
        assertEquals(true, _exceptionThrown);
    }
    public void test8() {
        supportDTD(false, false, ENTITY_EXTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(false, _hasEntityDelaration);
        assertEquals(true, _EntityEventReturned);
        System.setProperty("javax.xml.accessExternalDTD", "");
    }
    //tests 9-12 test both internal and external entities
    public void test9() {
        supportDTD(true, true, ENTITY_INTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(true, _hasEntityDelaration);
        assertEquals(false, _EntityEventReturned);
    }
    public void test10() {
        supportDTD(true, false, ENTITY_INTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(true, _hasEntityDelaration);
        assertEquals(true, _EntityEventReturned);
    }
    public void test11() {
        supportDTD(false, true, ENTITY_INTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(false, _hasEntityDelaration);
        assertEquals(true, _exceptionThrown);
    }
    public void test12() {
        supportDTD(false, false, ENTITY_INTERNAL_ONLY);
        assertEquals(true, _DTDReturned);
        assertEquals(false, _hasEntityDelaration);
        assertEquals(true, _EntityEventReturned);
    }

    public void supportDTD(boolean supportDTD, boolean replaceEntity, int inputType) {
        reset();
        print("\n");
        print((supportDTD?"SupportDTD=true":"SupportDTD=false") + ", " + (replaceEntity?"replaceEntity=true":"replaceEntity=false"));
        try {
            XMLInputFactory xif = getFactory(supportDTD, replaceEntity);
            XMLEventReader r = getEventReader(xif, inputType);
            int eventType = 0;
            int count = 0;
            while (r.hasNext()) {
                XMLEvent event = r.nextEvent();
                eventType = event.getEventType();
                print("Event " + ++count +": " + eventType);
                switch (eventType) {
                    case XMLStreamConstants.DTD :
                        DisplayEntities((DTD)event);
                        _DTDReturned = true;
                        break;
                    case XMLStreamConstants.ENTITY_REFERENCE :
                        print("Entity Name: " + ((EntityReference)event).getName());
                        _EntityEventReturned = true;
                        break;
                    case XMLStreamConstants.CHARACTERS :
                        print("Text: " + ((Characters)event).getData());
                }
            }

        } catch (Exception e) {
            _exceptionThrown = true;
            if (DEBUG) e.printStackTrace();
        }
    }

    XMLInputFactory getFactory(boolean supportDTD, boolean replaceEntity) {
        XMLInputFactory xif = XMLInputFactory.newInstance();
        xif.setProperty(XMLInputFactory.SUPPORT_DTD, (supportDTD)?Boolean.TRUE:Boolean.FALSE);
        xif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, (replaceEntity)?Boolean.TRUE:Boolean.FALSE);
        //xif.setProperty(XMLInputFactory.IS_VALIDATING, Boolean.TRUE);
        return xif;
    }
    private XMLEventReader getEventReader(XMLInputFactory inputFactory, int input)
    throws Exception {
        XMLEventReader er = null;
        if (input == ENTITY_INTERNAL_ONLY) {
            er = inputFactory.createXMLEventReader(new StringReader(XML));
        } else if (input == ENTITY_EXTERNAL_ONLY) {
            er = inputFactory.createXMLEventReader(new StringReader(XML1));
        } else {
            File file = new File(_file);
            FileInputStream inputStream = new FileInputStream(file);
            //XMLStreamReader r = xif.createXMLStreamReader(inputStream);
            er = inputFactory.createXMLEventReader(inputStream);
        }
        return er;
    }
    void DisplayEntities(DTD event) {
        List entities = event.getEntities();
        if (entities == null) {
            _hasEntityDelaration = false;
            print("No entity found.");
        } else {
            _hasEntityDelaration = true;
            for (int i=0; i<entities.size(); i++) {
                EntityDeclaration entity = (EntityDeclaration)entities.get(i);
                print(entity.getName());
            }
        }

    }
    void print(String s) {
        if (DEBUG) System.out.println(s);
    }

}
