/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


package javax.xml.stream.Events;

import java.io.File;
import java.io.StringReader;
import java.util.*;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.*;
import javax.xml.stream.events.*;
import javax.xml.stream.Location;

import junit.framework.TestCase;
import junit.framework.Assert;
import junit.textui.TestRunner;

import java.io.FileWriter;

/**
 * sjsxp issue 58: XMLEvent.getLocation() returns a volatile Location
 *
 * XMLEvent getLocation: Return the location of this event. The Location
 * returned from this method is non-volatile and will retain its information.
 *
 * Note that the change is made on StreamReader's getLocation method. With this change
 * the location returned by StreamReader will be non-volatile. The fact that a
 * location returned by StreamReader.getLocation would change when next() was called
 * is not comprehensible and desirable

 * @author Joe.Wang@sun.com
 */
public class Issue58Test extends TestCase {

    public java.io.File input;
    public final String filesDir = "./";
    protected XMLInputFactory inputFactory;
    protected XMLOutputFactory outputFactory;

    public static void main(String [] args) {
        TestRunner.run(Issue58Test.class);
    }

    public void testLocation() {
        String XML = "<?xml version='1.0' ?>"
        +"<!DOCTYPE root [\n"
        +"<!ENTITY intEnt 'internal'>\n"
        +"<!ENTITY extParsedEnt SYSTEM 'url:dummy'>\n"
        +"<!NOTATION notation PUBLIC 'notation-public-id'>\n"
        +"<!NOTATION notation2 SYSTEM 'url:dummy'>\n"
        +"<!ENTITY extUnparsedEnt SYSTEM 'url:dummy2' NDATA notation>\n"
        +"]>\n"
        +"<root />";

        try {
            XMLEventReader er = getReader(XML);
            XMLEvent evt = er.nextEvent();  //StartDocument
            Location loc1 = evt.getLocation();
            System.out.println("Location 1: "+loc1.getLineNumber()+","+loc1.getColumnNumber());
            evt = er.nextEvent();           //DTD
            //loc1 should not change so its line number should still be 1
            assertTrue(loc1.getLineNumber()==1);
            Location loc2 = evt.getLocation();
            System.out.println("Location 2: "+loc2.getLineNumber()+","+loc2.getColumnNumber());
            evt = er.nextEvent();           //root
            System.out.println( "Location 1: "+loc1.getLineNumber()+","+loc1.getColumnNumber());
            assertTrue(loc1.getLineNumber()==1);
            assertTrue(loc2.getLineNumber()==7);
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }


    private XMLEventReader getReader(String XML)
        throws Exception
    {
            inputFactory = XMLInputFactory.newInstance();

            // Check if event reader returns the correct event
            XMLEventReader er = inputFactory.createXMLEventReader(new StringReader(XML));
         return er;
    }

}
