/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2011 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.xml.parsers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.StringReader;
import javax.xml.XMLConstants;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import org.xml.sax.InputSource;

import org.xml.sax.helpers.DefaultHandler;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Unit tests for: CR 6536111 jaxp/sax SAX parser throws OutOfMemoryError
 *
 * @author <a href="mailto:joe.wang@Sun.com">Joe Wang</a>
 *
 */
public class Bug6536111OOMTest extends TestCase {

    static int iteration = 100000;

    public static void main(String[] args) {

        TestRunner.run(Bug6536111OOMTest.class);
    }

    public void testInternal() throws Exception {
        StringBuffer buff = new StringBuffer("<?xml version='1.0' ?>" + "<!DOCTYPE root [\n" + "<!ENTITY intEnt 'internal'>\n" + "]>" + "<root>very long string");

        for (int i = 0; i < iteration; i++) {
            buff.append("very long string");
        }
        buff.append("</root>");

        long mem0 = startMemory();
        String XML = buff.toString();
        long memUsed = mem0 - endMemory();
        System.out.println("length of XML: " + XML.length());
        System.out.println("memory used by creating XML: " + memUsed );

        javax.xml.parsers.SAXParserFactory saxFactory =
                javax.xml.parsers.SAXParserFactory.newInstance();
        //test default status
        //saxFactory.setFeature("http://xml.org/sax/features/external-general-entities",true);

        javax.xml.parsers.SAXParser parser = saxFactory.newSAXParser();
        parser.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");

        mem0 = startMemory();
        //parser.parse(is, new DefaultHandler());
        parser.parse(new InputSource(new StringReader(XML)), new DefaultHandler());
        long memUsed1 = mem0 - endMemory();
        System.out.println("testInternal: Memory used during parsing: " + memUsed1 + "\n");

        /**
        * These tests are not very accurate since freeMemory() may not reflect the actual memory
        * usage, esp. when StringBuffer or arrays are involved
        * Tests showed however the following can reliably detect if the whole xml was
        * put into cache (memUsed1 would be much smaller).
         */
        assertTrue(memUsed1 < memUsed/2);
    }

    public void testExternal() throws Exception {
        StringBuffer buff = new StringBuffer("<?xml version='1.0' ?>" + "<!DOCTYPE root SYSTEM \"jaxp-ri/src/unit-test/javax/xml/parsers/local.dtd\">" + "<root>very long string");

        for (int i = 0; i < iteration;
                i++) {
            buff.append("very long string");
        }

        buff.append("</root>");

        long mem0 = startMemory();
        String XML = buff.toString();
        long memUsed = mem0 - endMemory();
        System.out.println("length of XML: " + XML.length());
        System.out.println("memory used by creating XML: " + memUsed );

        javax.xml.parsers.SAXParserFactory saxFactory =
                javax.xml.parsers.SAXParserFactory.newInstance();
        //test default status
        //saxFactory.setFeature("http://xml.org/sax/features/external-general-entities",true);

        javax.xml.parsers.SAXParser parser = saxFactory.newSAXParser();
        parser.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");

        mem0 = startMemory();
        parser.parse(new InputSource(new StringReader(XML)), new DefaultHandler());
        long memUsed1 = mem0 - endMemory();
        System.out.println("testExternal: Memory used during parsing: " + memUsed1 + "\n");

        assertTrue(memUsed1 < memUsed/2);

    }

    public void testBoth() throws Exception {
        StringBuffer buff = new StringBuffer("<?xml version='1.0' ?>" + "<!DOCTYPE root [\n" + "<!ENTITY intEnt 'internal'>\n" + "<!ENTITY ref SYSTEM 'jaxp-ri/src/unit-test/javax/xml/parsers/local.dtd'>\n" + "]>" + "<root>very long string");
//        StringBuffer buff = new StringBuffer("<?xml version='1.0' ?><!DOCTYPE root [\n<!ENTITY intEnt 'internal'>\n");
//        buff.append("<!ENTITY ref SYSTEM 'jaxp-ri/src/unit-test/javax/xml/parsers/local.dtd'>\n]><root>very long string");
        for (int i = 0; i < iteration-5; i++) {
            buff.append("very long string");
        }

        buff.append("</root>");

        long mem0 = startMemory();
        String XML = buff.toString();
        long memUsed = mem0 - endMemory();
        System.out.println("length of XML: " + XML.length());
        System.out.println("memory used by creating XML: " + memUsed );

        javax.xml.parsers.SAXParserFactory saxFactory =
                javax.xml.parsers.SAXParserFactory.newInstance();
        //test default status
        //saxFactory.setFeature("http://xml.org/sax/features/external-general-entities",true);

        javax.xml.parsers.SAXParser parser = saxFactory.newSAXParser();
        parser.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");

        mem0 = startMemory();
        parser.parse(new InputSource(new StringReader(XML)), new DefaultHandler());
        long memUsed1 = mem0 - endMemory();
        System.out.println("testBoth: Memory used during parsing: " + memUsed1);

        assertTrue(memUsed1 < memUsed/2);

    }

    long startMemory() {
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        long memFree = Runtime.getRuntime().freeMemory();
        return memFree;
    }

    long endMemory() {
        long memFree = Runtime.getRuntime().freeMemory();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        System.gc();
        return memFree;
    }

    void reportMemUsuage(String msg) {
        System.out.println(msg);
        long memTotal = Runtime.getRuntime().totalMemory();
        long memFree = Runtime.getRuntime().freeMemory();
        long memMax = Runtime.getRuntime().maxMemory();
        System.out.println("Memory in JVM: \nMax: " + memMax + "\nTotal available: " + memTotal + "\nFree: " + memFree);
    }
}
