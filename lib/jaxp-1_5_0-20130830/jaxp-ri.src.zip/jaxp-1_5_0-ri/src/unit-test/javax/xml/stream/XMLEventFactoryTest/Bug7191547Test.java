/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2013 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.xml.stream.XMLEventFactoryTest;

/**CR 7191547
 * [StAX] XMLEventFactory.newFactory(String factoryId, ClassLoader loader) does not work as expected
 * @author huizhe.wang@oracle.com
 */

import common.SimplePolicy;
import java.security.Policy;
import java.util.PropertyPermission;
import javax.xml.stream.XMLEventFactory;
import junit.framework.TestCase;
import junit.textui.TestRunner;

public class Bug7191547Test extends TestCase{
    private boolean hasSM;
    private Policy _orig;

    /** Creates a new instance of Bug */
    public Bug7191547Test(String name) {
         super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug7191547Test.class);
    }

    private Bug7191547Test() {
        super("Bug7191547Test");
    }
    
    @Override
    public void setUp() {
        // run tests with security manager
        if (System.getSecurityManager() != null) {
            hasSM = true;
            System.setSecurityManager(null);
        }
        _orig = Policy.getPolicy();

        if (hasSM) {
            Policy p = new SimplePolicy(new RuntimePermission("setSecurityManager"),
                    new PropertyPermission("MyEventFactoryID", "write"));
            Policy.setPolicy(p);
            System.setSecurityManager(new SecurityManager());
        }
    }

    @Override
    public void tearDown() {
        // turn off security manager and restore policy
        System.setSecurityManager(null);
        Policy.setPolicy(_orig);
        if (hasSM) {
            System.setSecurityManager(new SecurityManager());
        }
    }

    public void testNewInstance() {
        String myFactory ="javax.xml.stream.XMLEventFactoryTest.MyEventFactory";
        try {
            System.setProperty("MyEventFactoryID", myFactory);
            XMLEventFactory xif = XMLEventFactory.newInstance("MyEventFactoryID", null);
            System.out.println(xif.getClass().getName());
            assertTrue(xif.getClass().getName().equals(myFactory));

        }
        catch (UnsupportedOperationException oe) {
            fail(oe.getMessage());
        }

    }
    //newFactory was added in StAX 1.2
    public void testNewFactory() {
        String myFactory ="javax.xml.stream.XMLEventFactoryTest.MyEventFactory";
        ClassLoader cl = null;
        try {
            System.setProperty("MyEventFactoryID", myFactory);
            XMLEventFactory xif = XMLEventFactory.newFactory("MyEventFactoryID", cl);
            System.out.println(xif.getClass().getName());
            assertTrue(xif.getClass().getName().equals(myFactory));

        }
        catch (UnsupportedOperationException oe) {
            fail(oe.getMessage());
        }

    }

    String Temp_Result = "";
    boolean PASSED = true;
    boolean FAILED = false;

    ClassLoader CL = null;
    String XMLEventFactoryClassName = "com.sun.xml.internal.stream.events.XMLEventFactoryImpl";
    String XMLEventFactoryID = "javax.xml.stream.XMLEventFactory";
    String factoryId = null;

    //jaxp-test jaxp-product-tests javax.xml.jaxp14.ptests.FactoryTest
    public void test() {
        if (!test37()) {
            fail(Temp_Result);
        }
        if (!test38()) {
            fail(Temp_Result);
        }
        if (!test39()) {
            fail(Temp_Result);
        }
        if (!test40()) {
            fail(Temp_Result);
        }
    }

    /* The following SQE tests were incorrect. The first parameter should have been
     * factoryId as specified in the specification rather than factoryClassName
     * 
     */
    /*
      test for XMLEventFactory.newInstance(java.lang.String factoryClassName, java.lang.ClassLoader classLoader)
      classloader is null and factoryClassName points to correct 
      implementation of javax.xml.stream.XMLEventFactory ,
      should return newInstance of XMLEventFactory
    */
    public boolean test37() {
        try{
            XMLEventFactory xef = XMLEventFactory.newInstance(XMLEventFactoryID, CL);
            if (xef instanceof XMLEventFactory){
                System.out.println(" test37() passed");
                return PASSED; 
            }else{
                System.out.println(" test37() failed");
                Temp_Result = "test37() failed ";
                return FAILED;
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            System.out.println("Failed : FactoryConfigurationError in test37 " + fce);
            Temp_Result = "test37() failed ";
            return FAILED;
        } catch(Exception e){
            System.out.println("Failed : Exception in test37 " + e);
            Temp_Result = "test37() failed ";
            return FAILED;
        }
    }
    
     /*
      test for XMLEventFactory.newInstance(java.lang.String factoryClassName, java.lang.ClassLoader classLoader)
      classloader is null and factoryClassName is null ,
      should throw FactoryConfigurationError
    */
    public boolean test38() {
        try{
            XMLEventFactory xef = XMLEventFactory.newInstance(null, CL);
            System.out.println("Failed : expected FactoryConfigurationError not thrown in test38 ");
            Temp_Result = "test38() failed ";
            return FAILED;
        } catch(NullPointerException npe){
            System.out.println("Passed : expected NPE thrown in test38 ");
            return PASSED; 
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            System.out.println("Passed : expected FactoryConfigurationError thrown in test38 ");
            return PASSED; 
        } catch(Exception e){
            System.out.println("Failed : Exception in test38 " + e);
            Temp_Result = "test38() failed ";
            return FAILED;
        }
    }
     
      /*
      test for XMLEventFactory.newInstance(java.lang.String factoryClassName, java.lang.ClassLoader classLoader)
      classloader is default(Class.getClassLoader()) and factoryClassName points to correct 
      implementation of javax.xml.stream.XMLEventFactory ,
      should return newInstance of XMLEventFactory
    */
    public boolean test39() {
        try{
            Bug7191547Test test3 = new Bug7191547Test();
            ClassLoader cl = (test3.getClass()).getClassLoader();
            XMLEventFactory xef = XMLEventFactory.newInstance(XMLEventFactoryID, cl);
            if (xef instanceof XMLEventFactory){
                System.out.println(" test39() passed");
                return PASSED; 
            }else{
                System.out.println(" test39() failed");
                Temp_Result = "test39() failed ";
                return FAILED;
            }
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            System.out.println("Failed : FactoryConfigurationError in test39 " + fce);
            Temp_Result = "test39() failed ";
            return FAILED;
        } catch(Exception e){
            System.out.println("Failed : Exception in test39 " + e);
            Temp_Result = "test39() failed ";
            return FAILED;
        }
    }
     
    /*
      test for XMLEventFactory.newInstance(java.lang.String factoryClassName, java.lang.ClassLoader classLoader)
      classloader is default(Class.getClassLoader()) and factoryClassName is null ,
      should throw FactoryConfigurationError
    */
    public boolean test40() {
        try{
            Bug7191547Test test3 = new Bug7191547Test();
            ClassLoader cl = (test3.getClass()).getClassLoader();
            XMLEventFactory xef = XMLEventFactory.newInstance(null, cl);
            System.out.println("Failed : expected FactoryConfigurationError not thrown in test40 " );
            Temp_Result = "test40() failed ";
            return FAILED;
        } catch(NullPointerException npe){
            System.out.println("Passed : expected NPE thrown in test40 ");
            return PASSED; 
        } catch(javax.xml.stream.FactoryConfigurationError fce){
            System.out.println("Passed : expected FactoryConfigurationError thrown in test40 " );
            return PASSED;
        } catch(Exception e){
            System.out.println("Failed : Exception in test40 " + e);
            Temp_Result = "test40() failed ";
            return FAILED;
        }
    }   
        
}
