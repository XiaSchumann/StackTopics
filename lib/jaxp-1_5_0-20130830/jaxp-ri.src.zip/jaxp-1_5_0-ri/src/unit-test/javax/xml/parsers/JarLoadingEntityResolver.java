package javax.xml.parsers;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.*;
import java.net.URLDecoder;
import java.util.Enumeration;

/**
 * Resolover for Loading from JAR-File
 */
public class JarLoadingEntityResolver
        implements EntityResolver {

    protected final static String xmlEncoding = "ISO-8859-15";
    //@Override

    public InputSource resolveEntity(String publicId, String systemId)
            throws SAXException, IOException {
        InputSource result = null;
        String strDTDPathJar = null;
        String strDTDPathFile = null;
//		File fileDTDFile = null;
//		URL urlDTDPath = null;

        try {
            try {
                systemId = systemId.replace('\\', '/');
                systemId = URLDecoder.decode(systemId, "UTF-8");
                String strbPathDTD = /*"xml/" +*/ systemId.substring(systemId.lastIndexOf("/") + 1);

                strDTDPathFile = systemId;

                if (strDTDPathFile.startsWith("file:")) {
                    strDTDPathFile = strDTDPathFile.substring("file:".length());
                }

                System.out.println("### INFO: complete DTD-Path: "
                        + strDTDPathFile);

                System.out.println(
                        "### INFO: DTD loading from Classpath ...");

                strDTDPathJar = strbPathDTD.toString();

                if (strDTDPathJar != null) {
                    if (strDTDPathJar.startsWith("file:")) {
                        strDTDPathJar =
                                strDTDPathJar.substring("file:".length());
                    }

                    if (strDTDPathJar.startsWith("./")) {
                        strDTDPathJar = strDTDPathJar.substring(2);
                    }

                    ClassLoader cl = getClass().getClassLoader();

                    Enumeration foundList = cl.getResources(strDTDPathJar);

                    for (int i = 0; foundList.hasMoreElements(); i++) {
                        System.out.println("Found [" + i + "] <"
                                + foundList.nextElement() + ">");
                    }

                    java.io.InputStream inputStream =
                            cl.getResourceAsStream(strDTDPathJar);

                    if (inputStream != null) {
                        result = new InputSource(inputStream);
                        result.setSystemId(systemId);
                        result.setPublicId(publicId);

                        result.setEncoding(xmlEncoding);
                    } else {
                        System.out.println(
                                "### ERROR: DTD Path could not be opened <"
                                + strDTDPathJar + ">");
                    }
                } else {
                    System.out.println("### ERROR: DTD Path is [NULL]");
                }
            } catch (FileNotFoundException fnfe) {
                System.out.println("DTD File could not be opened!");
                fnfe.printStackTrace();
            }
        } catch (Exception ex) {
            System.out.println("Exception! Try to load DTD from Classpath ...");
            ex.printStackTrace();

            File entityFile = new File(systemId);
            String strShortName = entityFile.getName();
            java.io.InputStream dtdFileStream =
                    ClassLoader.getSystemResourceAsStream(strShortName);
            result = new InputSource(new InputStreamReader(dtdFileStream));
        }

        if (result != null) {
            System.out.println("Result of resolveEntity(): <" + result + ">");
        } else {
            System.out.println("Result of resolveEntity is NULL!!");
        }

        return result;
    }
}