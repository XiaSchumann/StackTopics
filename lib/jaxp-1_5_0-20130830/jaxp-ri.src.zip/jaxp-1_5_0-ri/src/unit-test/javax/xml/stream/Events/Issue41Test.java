/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */


package javax.xml.stream.Events;

import java.io.File;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.*;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.*;
import javax.xml.stream.events.*;

import junit.framework.TestCase;
import junit.framework.Assert;
import junit.textui.TestRunner;

import java.io.FileWriter;

/**
 * CR 6631268 for jaxp 1.4
 * sjsxp issue 41: XMLEvent.writeAsEncodedUnicode(Writer) not implemented
 *
 * @author Joe.Wang@sun.com
 */
public class Issue41Test extends TestCase {

    public java.io.File input;
    public final String filesDir = "./";
    protected XMLInputFactory inputFactory;
    protected XMLOutputFactory outputFactory;

    public static void main(String [] args) {
        TestRunner.run(Issue41Test.class);
    }

    public void testEvents() {
        XMLEventFactory f = XMLEventFactory.newInstance();
        final String contents = "test <some> text & more! [[]] --";
        final String prefix = "prefix";
        final String uri = "http://foo";
        final String localName = "elem";

        try {
            StartDocument sd = f.createStartDocument();
            writeAsEncodedUnicode(sd);

            Comment c = f.createComment("some comments");
            writeAsEncodedUnicode(c);

            StartElement se = f.createStartElement(prefix, uri, localName);

            ProcessingInstruction pi = f.createProcessingInstruction("target", "data");
            writeAsEncodedUnicode(pi);

            Namespace ns = f.createNamespace(prefix, uri);
            writeAsEncodedUnicode(ns);

            Characters characters = f.createCharacters(contents);
            writeAsEncodedUnicode(characters);
            //CData
            Characters cdata = f.createCData(contents);
            writeAsEncodedUnicode(cdata);

            //Attribute
            QName attrName = new QName("http://test.com", "attr", "ns");
            Attribute attr = f.createAttribute(attrName, "value");
            writeAsEncodedUnicode(attr);

            // prefix, uri, localName
            EndElement ee = f.createEndElement(prefix, uri, localName);
            writeAsEncodedUnicode(ee);

            EndDocument ed = f.createEndDocument();
            writeAsEncodedUnicode(ed);
        }
        catch (Exception e) {
            fail(e.getMessage());
        }

    }
    /**
     * DTDEvent instances constructed via event reader are missing the notation and
     * entity declaration information
     */
    public void testDTDEvent() {
        String XML = "<?xml version='1.0' ?>"
        +"<!DOCTYPE root [\n"
        +"<!ENTITY intEnt 'internal'>\n"
        +"<!ENTITY extParsedEnt SYSTEM 'url:dummy'>\n"
        +"<!NOTATION notation PUBLIC 'notation-public-id'>\n"
        +"<!NOTATION notation2 SYSTEM 'url:dummy'>\n"
        +"<!ENTITY extUnparsedEnt SYSTEM 'url:dummy2' NDATA notation>\n"
        +"]>"
        +"<root />";

        try {
            XMLEventReader er = getReader(XML);
            XMLEvent evt = er.nextEvent();  //StartDocument
            evt = er.nextEvent();           //DTD
            if (evt.getEventType() != XMLStreamConstants.DTD) {
                fail("Expected DTD event");
            }
            DTD dtd = (DTD) evt;
            writeAsEncodedUnicode(dtd);
            List entities = dtd.getEntities();
            if (entities == null) {
                fail("No entity found. Expected 3.");
            } else {
                writeAsEncodedUnicode((XMLEvent)entities.get(0));
                writeAsEncodedUnicode((XMLEvent)entities.get(1));
                writeAsEncodedUnicode((XMLEvent)entities.get(2));
            }

            List notations = dtd.getNotations();
            if (notations == null) {
                fail("No notation found. Expected 2.");
            } else {
                writeAsEncodedUnicode((XMLEvent)notations.get(0));
                writeAsEncodedUnicode((XMLEvent)notations.get(1));
            }
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }


    private XMLEventReader getReader(String XML)
        throws Exception
    {
            inputFactory = XMLInputFactory.newInstance();

            // Check if event reader returns the correct event
            XMLEventReader er = inputFactory.createXMLEventReader(new StringReader(XML));
         return er;
    }
    private void testListElems(List l, Class expType)
    {
        Iterator it = l.iterator();
        while (it.hasNext()) {
            Object o = it.next();
            assertNotNull(o);
            assertTrue(expType.isAssignableFrom(o.getClass()));
        }
    }

    /**
     * The return of XMLEvent writeAsEncodedUnicode method is not defined
     * This method merely tests that the output exists
     */
    public void writeAsEncodedUnicode(XMLEvent evt)
        throws XMLStreamException
    {
        if (evt.getEventType() == XMLStreamConstants.END_DOCUMENT) {
            return;
        }
        StringWriter sw = new StringWriter();
        evt.writeAsEncodedUnicode(sw);

        assertTrue(sw.toString().length() > 0);
        System.out.println(sw.toString());
    }
}
