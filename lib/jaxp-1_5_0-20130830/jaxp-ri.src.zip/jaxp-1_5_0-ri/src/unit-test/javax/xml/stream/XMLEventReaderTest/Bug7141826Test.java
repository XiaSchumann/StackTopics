/*
 * bug6613059.java
 *
 * Created on Oct. 12, 2007
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javax.xml.stream.XMLEventReaderTest;

import javax.xml.stream.*;
import junit.framework.*;
import junit.textui.TestRunner;

import java.io.*;
import javax.xml.stream.events.*;
import javax.xml.namespace.QName;
import javax.xml.parsers.*;
import org.w3c.dom.Document;
import org.xml.sax.*;
import org.xml.sax.ext.DefaultHandler2;


/**
 *
 * @author huizhe.wang@oracle.com
 */
public class Bug7141826Test extends TestCase {
    static final String xml = "jaxp-ri/src/unit-test/javax/xml/stream/XMLEventReaderTest/Bug7141826.xml";
    
    public static void main(String [] args){
        TestRunner.run(Bug7141826Test.class);
    }
      
    public Bug7141826Test() {
    }

    public void test(){
        try{
            XMLInputFactory xif = XMLInputFactory.newInstance();
            XMLEventReader reader = xif.createXMLEventReader(this.getClass().getResourceAsStream("Bug7141826_1.xml")); 
            while (reader.hasNext()) {
            	System.out.println("Has next");
                reader.next();
            }
            
        }catch(Exception e){
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }

    public void xtestDOMParse() {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document document = db.parse(xml);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void xtestParse() {
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            SAXParser parser = spf.newSAXParser();
            File xmlFile = new File(xml);
            XMLReader xmlReader = parser.getXMLReader();
            xmlReader.setProperty("http://xml.org/sax/properties/lexical-handler",new MyHandler1());
            parser.parse(xmlFile, new MyHandler1());
        } catch (SAXException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            //shouldn't happen
        } catch (ParserConfigurationException ex) {
            //shouldn't happen
        }
    }
    public void xtestParseInputStream() {
        System.out.println("testParseInputStream");
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            SAXParser parser = spf.newSAXParser();
            File xmlFile = new File(xml);
            XMLReader xmlReader = parser.getXMLReader();
            xmlReader.setProperty("http://xml.org/sax/properties/lexical-handler",new MyHandler1());
            parser.parse(new FileInputStream(xml), new MyHandler1());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        System.out.println("testParseInputStream done");
    }
    public class MyHandler1  extends DefaultHandler2 implements ErrorHandler {
        private Writer out;

    StringBuffer textBuffer;
    private String indentString = "    "; // Amount to indent
    private int indentLevel = 0;


        public MyHandler1() {
            try {
                out = new OutputStreamWriter(System.out, "UTF8");
            } catch (UnsupportedEncodingException ex) {
                ex.printStackTrace();
            }
        }
        public void startDocument() throws SAXException {
        }

        public void endDocument() throws SAXException {
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            try {
                System.out.println("uri: " + uri);
                System.out.println("localName: " + localName);
                System.out.println("qName: " + qName);
            } catch (Exception e) {
                throw new SAXException(e);
            }

        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
        }

        public void characters(char ch[], int start, int length) throws SAXException {
        }
        public void comment(char[] ch, int start, int length) {
            String text = new String(ch, start, length);
            //System.out.println(text);
            try {
                nl();
                emit("COMMENT: "+text);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void error(SAXParseException exception) {
            exception.printStackTrace();
        }
        public void fatalError(SAXParseException exception) {
            exception.printStackTrace();
        }
        public void warning(SAXParseException exception) {
            exception.printStackTrace();
        }
    // Wrap I/O exceptions in SAX exceptions, to
    // suit handler signature requirements
    private void emit(String s) throws SAXException {
        try {
            out.write(s);
            out.flush();
        } catch (IOException e) {
            throw new SAXException("I/O error", e);
        }
    }

    // Start a new line
    // and indent the next line appropriately
    private void nl() throws SAXException {
        String lineEnd = System.getProperty("line.separator");

        try {
            out.write(lineEnd);

            for (int i = 0; i < indentLevel; i++)
                out.write(indentString);
        } catch (IOException e) {
            throw new SAXException("I/O error", e);
        }
    }

    }
}
