/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * $Id: IsValidatingTest.java,v 1.4 2007-07-19 04:35:40 ofung Exp $
 * %W% %E%
 */

package javax.xml.stream.XMLStreamReaderTest;

import javax.xml.XMLConstants;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Test IS_VALIDATING property.
 *
 * Motivated by CR 6440324: StAX implementation not spec compliant
 *     - breaks RI compliant apps.
 *
 * Try to parse an XML file that references a a non-existent DTD.
 * Desired behavior:
 *     If IS_VALIDATING == false, then continue processing.
 *
 * Note that an attempt is made to read the DTD even if IS_VALIDATING == false.
 * This is not required for DTD validation, but for entity resolution.
 * The XML specification allows the optional reading of an external DTD
 * even for non-validating processors.
 *
 * @author <a href="mailto:Jeff.Suttor@Sun.com">Jeff Suttor</a>
 */
public class IsValidatingTest extends TestCase {

    /**
     * File with non-existent DTD.
     */
    private static final String INPUT_FILE = "IsValidatingTest.xml";
    /**
     * File with internal subset and non-existent DTD.
     */
    private static final String INPUT_FILE_INTERNAL_SUBSET =
            "IsValidatingTestInternalSubset.xml";

    /**
     * Creates a new instance of IsValidatingTest.
     *
     * @param name Name of test.
     */
    public IsValidatingTest(String name) {
         super(name);
    }

    /**
     * main method.
     *
     * @param args Standard args.
     */
    public static void main(String[] args) {
        TestRunner.run(IsValidatingTest.class);
    }

    /**
     * Test StAX with IS_VALIDATING = false and a non-existent DTD.
     *
     * Test should pass.
     */
    public void testStAXIsValidatingFalse() {

        XMLStreamReader reader = null;
        Boolean isValidating = null;
        String propertyValues = null;
        boolean dtdEventOccured = false;

        XMLInputFactory xif = XMLInputFactory.newInstance();
        xif.setProperty(XMLInputFactory.IS_VALIDATING, Boolean.FALSE);
        xif.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");

        try {
            reader = xif.createXMLStreamReader(
                    this.getClass().getResource(INPUT_FILE).toExternalForm(),
                    this.getClass().getResourceAsStream(INPUT_FILE));

            isValidating = (Boolean) reader.getProperty(
                    XMLInputFactory.IS_VALIDATING);
            propertyValues = "IS_VALIDATING=" + isValidating;

            while (reader.hasNext()) {
                int e = reader.next();
                if (e == XMLEvent.DTD) {
                    dtdEventOccured = true;
                    System.out.println(
                            "testStAXIsValidatingFalse(): "
                            + "reader.getText() with Event == DTD: "
                            + reader.getText());
                }
            }

            // expected success

            // should have see DTD Event
            if (!dtdEventOccured) {
            fail("Unexpected failure: did not see DTD event");
            }
        } catch (Exception e) {
            // unexpected failure
            System.err.println(
                    "Exception with reader.getEventType(): "
                    + reader.getEventType());
            e.printStackTrace();
            fail(
                "Unexpected failure with "
                + propertyValues
                + ", " + e.toString());
        }
    }

    /**
     * Test StAX with IS_VALIDATING = false, an internal subset
     * and a non-existent DTD.
     *
     * Test should pass.
     */
    public void testStAXIsValidatingFalseInternalSubset() {

        XMLStreamReader reader = null;
        Boolean isValidating = null;
        String propertyValues = null;
        boolean dtdEventOccured = false;
        boolean entityReferenceEventOccured = false;

        XMLInputFactory xif = XMLInputFactory.newInstance();
        xif.setProperty(XMLInputFactory.IS_VALIDATING, Boolean.FALSE);
        xif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        xif.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "file");

        try {
            reader = xif.createXMLStreamReader(
                    this.getClass().getResource(INPUT_FILE).toExternalForm(),
                    this.getClass().getResourceAsStream(
                        INPUT_FILE_INTERNAL_SUBSET));

            isValidating = (Boolean) reader.getProperty(
                    XMLInputFactory.IS_VALIDATING);
            propertyValues = "IS_VALIDATING=" + isValidating;

            while (reader.hasNext()) {
                int e = reader.next();
                if (e == XMLEvent.DTD) {
                    dtdEventOccured = true;
                    System.out.println(
                            "testStAXIsValidatingFalseInternalSubset(): "
                            + "reader.getText() with Event == DTD: "
                            + reader.getText());
                } else if (e == XMLEvent.ENTITY_REFERENCE) {
                    // expected ENTITY_REFERENCE values?
                    if (reader.getLocalName().equals("foo")
                        && reader.getText().equals("bar")) {
                        entityReferenceEventOccured = true;
                    }

                    System.out.println(
                            "testStAXIsValidatingFalseInternalSubset(): "
                            + "reader.get(LocalName, Text)() with Event "
                            + " == ENTITY_REFERENCE: "
                            + reader.getLocalName()
                            + " = "
                            + reader.getText());
                }
            }

            // expected success

            // should have see DTD Event
            if (!dtdEventOccured) {
                fail("Unexpected failure: did not see DTD event");
            }

            // should have seen an ENITY_REFERENCE Event
            if (!entityReferenceEventOccured) {
                fail("Unexpected failure: did not see ENTITY_REFERENCE event");
            }
        } catch (Exception e) {
            // unexpected failure
            System.err.println(
                    "Exception with reader.getEventType(): "
                    + reader.getEventType());
            e.printStackTrace();
            fail(
                "Unexpected failure with "
                + propertyValues
                + ", " + e.toString());
        }
    }
}
