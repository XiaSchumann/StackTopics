/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2010 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * Unit tests for {@link javax.xml.datatype.DatatypeFactory}.
 */
package javax.xml.datatype;

import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/*
 * used to generate millisecond values
 * import java.util.Calendar;
 * import java.util.GregorianCalendar;
 * import java.util.TimeZone;
 */
/**
 * Unit tests for JDK-8003588.
 *
 * @author huizhe.wang@oracle.com</a>
 */
public class Bug8003588Test extends TestCase {

    static final String[][] partialOrder = { // partialOrder
        {"P1Y", "<>", "P365D"},
        {"P1Y", "<>", "P366D"},
        {"P1M", "<>", "P28D"},
        {"P1M", "<>", "P29D"},
        {"P1M", "<>", "P30D"},
        {"P1M", "<>", "P31D"},
        {"P5M", "<>", "P150D"},
        {"P5M", "<>", "P151D"},
        {"P5M", "<>", "P152D"},
        {"P5M", "<>", "P153D"},
        {"PT2419200S", "<>", "P1M"},
        {"PT2678400S", "<>", "P1M"},
        {"PT31536000S", "<>", "P1Y"},
        {"PT31622400S", "<>", "P1Y"},
        {"PT525600M", "<>", "P1Y"},
        {"PT527040M", "<>", "P1Y"},
        {"PT8760H", "<>", "P1Y"},
        {"PT8784H", "<>", "P1Y"},
        {"P365D", "<>", "P1Y"},}; // end of partialOrder

    public Bug8003588Test(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug8003588Test.class);
    }

    public void xtestGregorianCalendar() {
        GregorianCalendar cal1 = new GregorianCalendar(400, 1, 1, 0, 0, 0);
        GregorianCalendar cal2 = new GregorianCalendar(400, 1, 1, 0, 0, 0);
        cal1.add(GregorianCalendar.YEAR, 4);
        cal2.add(GregorianCalendar.DAY_OF_YEAR, 1460);
        if (cal1.equals(cal2)) {
            System.out.println("cal1 = cal2");
        }
        System.out.println(cal1.toString());
        System.out.println(cal2.toString());
    }
    public void testGregorianCalendar() {
        System.out.println("testGregorianCalendar");
        GregorianCalendar cal1 = new GregorianCalendar(1970, 1, 1, 0, 0, 0);
        GregorianCalendar cal2 = new GregorianCalendar(1970, 1, 1, 0, 0, 0);
        System.out.println(cal1.getMaximum(GregorianCalendar.YEAR));
        System.out.println(cal1.getMaximum(GregorianCalendar.MONTH));
        System.out.println(cal1.getMinimum(GregorianCalendar.YEAR));
        System.out.println(cal1.getMinimum(GregorianCalendar.MONTH));
        
        System.out.println(cal1.getActualMaximum(GregorianCalendar.YEAR));
        System.out.println(cal1.getActualMaximum(GregorianCalendar.MONTH));
        System.out.println(cal1.getActualMinimum(GregorianCalendar.YEAR));
        System.out.println(cal1.getActualMinimum(GregorianCalendar.MONTH));
    }
    public void testCalendar() {
        System.out.println("testCalendar");
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        System.out.println(cal1.getMaximum(Calendar.YEAR));
        System.out.println(cal1.getMaximum(Calendar.MONTH));
        System.out.println(cal1.getMinimum(Calendar.YEAR));
        System.out.println(cal1.getMinimum(Calendar.MONTH));
    }

    public void xtestCalendar1() {
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.add(GregorianCalendar.YEAR, 1);
        cal2.add(GregorianCalendar.DAY_OF_YEAR, 365);
        if (cal1.equals(cal2)) {
            System.out.println("cal1 = cal2");
        }
        System.out.println(cal1.getTimeInMillis());
        System.out.println(cal2.getTimeInMillis());
    }

    public void xtest() {
        try {
            DatatypeFactory df = DatatypeFactory.newInstance();
            String status = "Passed";

            for (int valueIndex = 0; valueIndex < partialOrder.length; ++valueIndex) {
                Duration duration1 = df.newDuration(partialOrder[valueIndex][0]);
                Duration duration2 = df.newDuration(partialOrder[valueIndex][2]);
                int cmp = duration1.compare(duration2);
                int expected = ">".equals(partialOrder[valueIndex][1])
                        ? DatatypeConstants.GREATER
                        : "<".equals(partialOrder[valueIndex][1])
                        ? DatatypeConstants.LESSER
                        : "==".equals(partialOrder[valueIndex][1])
                        ? DatatypeConstants.EQUAL
                        : DatatypeConstants.INDETERMINATE;
                if (cmp != expected) {
                    status = "Failed";
                    System.out.println("returned " + cmp2str(cmp)
                            + " for durations \'" + duration1 + "\' and "
                            + duration2 + "\', but expected " + cmp2str(expected));

                }
            }
            System.out.println(status + ".");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    String cmp2str(int cmp) {
        return cmp == DatatypeConstants.LESSER ? "LESSER"
                : cmp == DatatypeConstants.GREATER ? "GREATER"
                : cmp == DatatypeConstants.EQUAL ? "EQUAL"
                : cmp == DatatypeConstants.INDETERMINATE ? "INDETERMINATE"
                : "UNDEFINED";
    }
}
