/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package bug6518733;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * Unit test for CR 6760982. This is to verify that the issue was fixed by the
 * patch for 6518733
 *
 * @author Joe.Wang@sun.com
 */
public class Bug6760982 extends TestCase
{
    public static void main(String [] args){
        TestRunner.run(Bug6760982.class);
    }

    public Bug6760982() {
    }

    public void test() {
                        try {
                                Document xmlDoc = _Parse (new File (getClass().getResource("bug6760982.xml").getFile()));
                                Node     node   = xmlDoc.getDocumentElement ();

                                _ProcessNode (node, 0);
                                _Flush ();
                        }
                        catch (Exception e) {
                                _ErrPrintln ("Exception: " + e.toString ());
                                e.printStackTrace ();
                        }
        }
private static void _Flush ()
        {
                System.out.flush ();
                System.err.flush ();
        }

        private static void _Println (String str, int level)
        {
                for (int i = 0; i < level; i++)
                        System.out.print ("    ");

                System.out.println (str);
                System.out.flush ();
        }

        private static void _ErrPrintln (String aStr)
        {
                System.out.flush ();
                System.err.println (aStr);
                System.err.flush ();
        }

        private static Document _Parse (File f)
        throws Exception
        {
                FileReader rd = new FileReader (f);
                Document doc = _Parse (rd);

                rd.close ();

                return doc;
        }

        private static Document _Parse (Reader src)
        throws Exception
        {
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance ();

                dbf.setValidating (false);      // to improve performance

                DocumentBuilder xmlParser = dbf.newDocumentBuilder ();
                InputSource is = new InputSource (src);

                return xmlParser.parse (is);
        }

        private static void _PrintAttributes (Node n, int level)
        {
                NamedNodeMap nnmap = n.getAttributes ();

                if (nnmap != null && nnmap.getLength () > 0) {
                        _Println ("<attribs> (" + nnmap.getClass () + "):", level + 1);

                        for (int i = 0; i < nnmap.getLength (); i++) {
                                Node an = nnmap.item (i);

                                String nameStr  = an.getNodeName ();
                                String valueStr = an.getNodeValue ();

                                if (valueStr != "")
                                        nameStr += " = " + valueStr;

                                _Println (nameStr, level + 2);
                        }
                }
        }

        private static void _ProcessChildren (Node n, int level)
        throws Exception
        {
                NodeList nlist = n.getChildNodes ();

                if (nlist != null)
                        for (int i = 0; i < nlist.getLength (); i++)
                                _ProcessNode (nlist.item (i), level + 1);
        }

        private static void _ProcessNode (Node n, int level)
        throws Exception
        {
                n.getAttributes ();
                n.getChildNodes ();

                // At this point, for JVM 1.6 and Xerces <= 1.3.1, Test-XML.xml::mytest:Y's attribute is (already) bad.

                switch (n.getNodeType()) {

                        case Node.TEXT_NODE:
                                String str = n.getNodeValue ().trim ();

                                /*...Only print non-empty strings...*/
                                if (str.length () > 0) {
                                        String valStr = n.getNodeValue ();

                                        _Println (valStr, level);
                                }
                                break;

                        case Node.COMMENT_NODE:
                                break;

                        default: {
                                String  nodeNameStr = n.getNodeName ();

                                _Println (nodeNameStr + " (" + n.getClass () + "):", level);

                                /*...Print children...*/
                                _ProcessChildren (n, level);

                                /*...Print optional node attributes...*/
                                _PrintAttributes (n, level);
                        }
                }
        }
}
