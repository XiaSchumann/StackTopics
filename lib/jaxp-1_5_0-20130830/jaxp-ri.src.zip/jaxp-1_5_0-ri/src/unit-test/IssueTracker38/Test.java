/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package IssueTracker38;

import java.io.StringBufferInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.sax.SAXSource;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import org.w3c.dom.Document;

/**
 * Unit Test for SJSXP Issue 38
 * https://sjsxp.dev.java.net/issues/show_bug.cgi?id=38
 * Creating an XMLStreamReader or an XMLEventReader from a Source is
 * not supported, so the proper exception must be thrown. This unit test
 * should be removed once this funcionality is implemented. See,
 * https://sjsxp.dev.java.net/issues/show_bug.cgi?id=39
 *
 * @author Santiago.PericasGeertsen@sun.com
 *
 * Refer to CR 6909759 -- restoring support for StreamSource
 * @author joe.wang@sun.com
 */
public class Test extends TestCase {

    public static void main(String [] args){
        TestRunner.run(Test.class);
    }

    public void testXMLEventReaderFromDOMSource() throws Exception {
        XMLInputFactory xIF = XMLInputFactory.newInstance();
        Source source = new DOMSource();
        try {
            XMLEventReader xer = xIF.createXMLEventReader(source);
        }
        catch (UnsupportedOperationException e) {
            // e.printStackTrace();
            try {
                XMLStreamReader xsr = xIF.createXMLStreamReader(source);
            }
            catch (UnsupportedOperationException oe) {
                // e.printStackTrace();
                return;
            }
        }
        fail("Expected UnsupportedOperationException not thrown");
    }

    /**
     * Refer to CR 6909759 -- support for StreamSource restored
     *
    public void testXMLEventReaderFromStreamSource() throws Exception {
        XMLInputFactory xIF = XMLInputFactory.newInstance();
        Source source = new StreamSource();
        try {
            XMLEventReader xer = xIF.createXMLEventReader(source);
        }
        catch (UnsupportedOperationException e) {
            // e.printStackTrace();
            try {
                XMLStreamReader xsr = xIF.createXMLStreamReader(source);
            }
            catch (UnsupportedOperationException oe) {
                // e.printStackTrace();
                return;
            }
        }
        fail("Expected UnsupportedOperationException not thrown");
    }
    */

    public void testXMLEventReaderFromSAXSource() throws Exception {
        XMLInputFactory xIF = XMLInputFactory.newInstance();
        Source source = new SAXSource();
        try {
            XMLEventReader xer = xIF.createXMLEventReader(source);
        }
        catch (UnsupportedOperationException e) {
            // e.printStackTrace();
            try {
                XMLStreamReader xsr = xIF.createXMLStreamReader(source);
            }
            catch (UnsupportedOperationException oe) {
                // e.printStackTrace();
                return;
            }
        }
        fail("Expected UnsupportedOperationException not thrown");
    }
}
