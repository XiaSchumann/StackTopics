/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

/*
 * Bug.java
 *
 * Created on November 11, 2005, 12:05 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package bug6348377;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.regex.Pattern;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 *
 * @author Sunitha Reddy
 */
public class Bug extends TestCase{

    String fileName = "TypeMapper.xml";
    final String REGEX_STR = "textRegularExpression";

    /** Creates a new instance of Bug */
    public Bug(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(Bug.class);
    }

    public void testWithOneThread(){
        try{
            InputStream fis = this.getClass().getResourceAsStream(fileName);
            RunnableTwo r2 = new RunnableTwo(fis);
            Thread t2 = new Thread(r2);
            t2.start();
            t2.join();
        }catch ( Exception ex ) {
            ex.printStackTrace(System.err);
            fail("Exception occured: "+ex.getMessage());
        }
    }

    /* This test takes longer time to execute.
     */
    public void testWithTwoThreads(){
        try{
            PipedOutputStream pos = new PipedOutputStream();
            PipedInputStream pis = new PipedInputStream(pos);
            RunnableOne r1 = new RunnableOne(fileName, pos);
            RunnableTwo r2 = new RunnableTwo(pis);
            Thread t1 = new Thread(r1);
            Thread t2 = new Thread(r2);
            t1.start();
            t2.start();
            t2.join();
        }catch ( Exception ex ) {
            ex.printStackTrace(System.err);
            fail("Exception occured: "+ex.getMessage());
        }
    }

    public class RunnableOne implements Runnable {
      private OutputStream os;
      InputStream fis;
      public RunnableOne(String fileName, OutputStream os) {
         try {
            fis = this.getClass().getResourceAsStream(fileName);
         } catch ( Exception e ) {
            e.printStackTrace(System.err);
         }
         this.os = os;
      }

      public void run() {
         try {
            int c;
            while ( (c = fis.read()) != -1 )
                os.write(c);
            fis.close();
            os.flush();
            os.close();

         } catch ( Exception e ) {
            e.printStackTrace(System.err);
         }
      }
   }

   public class RunnableTwo implements Runnable {
      private InputStream is;
      public RunnableTwo(InputStream is) {
         this.is = is;
      }

      public void run() {
        int cnt = 0;
        String regex = null;
         try {

            XMLInputFactory staxFactory = XMLInputFactory.newInstance();
            staxFactory.setProperty(XMLInputFactory.IS_COALESCING , Boolean.TRUE);
            Package pkg = staxFactory.getClass().getPackage();
            XMLStreamReader staxReader = staxFactory.createXMLStreamReader(is);

            while ( staxReader.hasNext()  ) {
               int event = staxReader.next();
               if ( event == XMLStreamConstants.END_DOCUMENT )
                  break;
               else if ( event == XMLStreamConstants.START_ELEMENT ) {
                  String localName = staxReader.getLocalName();
                  if ( localName.equals(REGEX_STR) ) {
                     event = staxReader.next();
                     assertTrue("expected XMLStreamConstants.CHARACTERS event", event == XMLStreamConstants.CHARACTERS);
                     regex = staxReader.getText();
                     ++cnt;
                     Pattern pattern = Pattern.compile(regex);
                  }
               }
            }
         } catch ( Exception ex ) {
            System.out.println("regex: "+regex);
            fail("Exception: "+ex.getMessage());
            ex.printStackTrace(System.err);
         }
      }
   }
}
