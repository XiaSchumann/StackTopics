/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package bug6493687;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class XMLDocBuilder {

    private DocumentBuilderFactory factory = null;
    private DocumentBuilder builder = null;
    private Document doc = null;
    private Reader reader = null;
    private Reader schema = null;
    private String encoding = null;
    private String entityPath = null;

    public XMLDocBuilder(String file, String encoding, String schema) {
        this.encoding = encoding;
        reader = getReaderFromSystemResource(file, encoding);
        this.schema = getReaderFromSystemResource(schema, encoding);
    }

    public Document getDocument() {
        if (reader == null)
            return null;

        try {
            factory = DocumentBuilderFactory.newInstance();

            builder = factory.newDocumentBuilder();
            builder.setErrorHandler(new myErrorHandler());
            builder.setEntityResolver(new myEntityResolver());

            InputSource source = new InputSource(reader);
            source.setEncoding(encoding);

            try {
                doc = builder.parse(source);
                new XMLSchemaValidator(doc, schema).validate();

            } catch (SAXException e) {
                System.err.println(getClass() + " SAXException: "
                        + e.getMessage());
                return null;
            } catch (IOException e) {
                System.err.println(getClass() + " IOException: "
                        + e.getMessage());
                return null;
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
                System.err.println(e.getCause().getLocalizedMessage());
                return null;
            }

        } catch (ParserConfigurationException e) {
            System.err.println(getClass() + " ParserConfigurationException: "
                    + e.getMessage());
            return null;
        }
        return doc;
    }

    public Reader getReaderFromSystemResource(String file, String encoding) {
        URL url = null;

        try {
            url = new URL("file:" + file);
        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        }

        if (url == null) {
            url = ClassLoader.getSystemResource(file);
        }

        if (url != null)
            try {
                return new InputStreamReader(url.openStream(), encoding);
            } catch (UnsupportedEncodingException e) {
                System.err.println(getClass()
                        + " UnsupportedEncodingException: " + e.getMessage());
            } catch (IOException e) {
                System.err.println(getClass() + " IOException: "
                        + e.getMessage());
            }
        return null;
    }

    public void setEntityPath(String entityPath) {
        this.entityPath = entityPath;
    }

    private class myErrorHandler implements ErrorHandler {

        public void warning(SAXParseException e) {
            showErrorMessage(e);
        }

        public void error(SAXParseException e) {
            showErrorMessage(e);
        }

        public void fatalError(SAXParseException e) {
            showErrorMessage(e);
        }

        private void showErrorMessage(SAXParseException e) {
            System.err.println(getClass() + " SAXParseException"
                    + e.getMessage());
            System.err.println("Line: " + e.getLineNumber() + " Column: "
                    + e.getColumnNumber());
        }
    }

    private class myEntityResolver implements EntityResolver {
        public InputSource resolveEntity(String publicId, String systemId) {
            if (entityPath == null)
                return null;

            systemId = entityPath
                    + systemId.subSequence(systemId.lastIndexOf("/"), systemId
                            .length());

            return new InputSource(systemId);
        }
    }
}
